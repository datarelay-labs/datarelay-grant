export { dataRelayTokens } from "./generated";
export type { DataRelayTokens } from "./generated";
