import fs from "node:fs";
import path from "node:path";

export const FOUNDATION_PACKAGE_FAMILY = Object.freeze([
  "@datarelay-labs/tokens",
  "@datarelay-labs/icons",
  "@datarelay-labs/ui",
  "@datarelay-labs/product-shell",
  "@datarelay-labs/auth-ui",
  "@datarelay-labs/system-contracts",
  "@datarelay-labs/system-admin-ui",
  "@datarelay-labs/testkit",
  "@datarelay-labs/foundation",
  "@datarelay-labs/foundation-cli"
]);

const FOUNDATION_PACKAGE_SET = new Set(FOUNDATION_PACKAGE_FAMILY);
const LEGACY_FOUNDATION_PACKAGE_SET = new Set(
  FOUNDATION_PACKAGE_FAMILY.map((name) =>
    name.replace("@datarelay-labs/", "@datarelay/")
  )
);
const EXACT_SEMVER = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/;
const PRODUCT_ID = /^[a-z][a-z0-9-]{1,63}$/;
const ITEM_ID = /^[a-z][a-z0-9._-]{0,79}$/;
const CAPABILITY_ID = /^[a-z][a-z0-9._-]{1,119}$/;
const AVAILABILITY = new Set(["supported", "read_only", "unavailable"]);

function fail(reason) {
  throw new Error(`FOUNDATION_DOCTOR_INVALID=${reason}`);
}

function readJson(file, label) {
  let text;
  try {
    const stat = fs.lstatSync(file);
    if (stat.isSymbolicLink() || !stat.isFile()) fail(`${label}-unsafe:${file}`);
    text = fs.readFileSync(file, "utf8");
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("FOUNDATION_DOCTOR_INVALID=")) {
      throw error;
    }
    fail(`${label}-missing:${file}`);
  }
  try {
    return JSON.parse(text);
  } catch {
    fail(`${label}-json:${file}`);
  }
}

function object(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail(label);
  return value;
}

function nonEmpty(value, label) {
  if (typeof value !== "string" || value.trim().length === 0) fail(label);
  return value;
}

function route(value, label) {
  nonEmpty(value, label);
  if (!value.startsWith("/")) fail(label);
  return value;
}

export function inspectFoundationVersions(packageManifest) {
  const found = new Map();
  for (const section of ["dependencies", "devDependencies", "optionalDependencies", "peerDependencies"]) {
    const values = packageManifest[section];
    if (!values || typeof values !== "object" || Array.isArray(values)) continue;
    for (const [name, spec] of Object.entries(values)) {
      if (LEGACY_FOUNDATION_PACKAGE_SET.has(name)) {
        fail(`legacy-package-scope:${name}`);
      }
      if (!FOUNDATION_PACKAGE_SET.has(name)) continue;
      if (typeof spec !== "string") fail(`dependency-spec:${name}`);
      const prior = found.get(name);
      if (prior && prior !== spec) fail(`conflicting-dependency-spec:${name}`);
      found.set(name, spec);
    }
  }
  if (!found.has("@datarelay-labs/foundation")) fail("umbrella-sdk-not-installed");
  for (const [name, spec] of found) {
    if (!EXACT_SEMVER.test(spec)) fail(`non-exact-version:${name}:${spec}`);
  }
  const versions = new Set(found.values());
  if (versions.size !== 1) {
    fail(`mixed-foundation-versions:${[...versions].sort().join(",")}`);
  }
  return { version: [...versions][0], packages: [...found.keys()].sort() };
}

export function validateProductManifest(manifest) {
  object(manifest, "manifest-object");
  if (manifest.contract_version !== 1) fail("contract-version");

  const product = object(manifest.product, "product-object");
  if (!PRODUCT_ID.test(nonEmpty(product.id, "product-id"))) fail("product-id");
  nonEmpty(product.name, "product-name");
  nonEmpty(product.short_name, "product-short-name");
  nonEmpty(product.version, "product-version");
  route(product.home_route, "product-home-route");

  if (!Array.isArray(manifest.capabilities)) fail("capabilities-array");
  const capabilityIds = new Set();
  for (const capability of manifest.capabilities) {
    object(capability, "capability-object");
    const id = nonEmpty(capability.id, "capability-id");
    if (!CAPABILITY_ID.test(id)) fail(`capability-id:${id}`);
    if (capabilityIds.has(id)) fail(`duplicate-capability-id:${id}`);
    capabilityIds.add(id);
    if (!AVAILABILITY.has(capability.availability)) fail(`capability-availability:${id}`);
  }

  if (!Array.isArray(manifest.navigation)) fail("navigation-array");
  const navigationIds = new Set();
  const navigationPaths = new Set();
  for (const item of manifest.navigation) {
    object(item, "navigation-object");
    const id = nonEmpty(item.id, "navigation-id");
    if (!ITEM_ID.test(id)) fail(`navigation-id:${id}`);
    if (navigationIds.has(id)) fail(`duplicate-navigation-id:${id}`);
    navigationIds.add(id);
    nonEmpty(item.label, `navigation-label:${id}`);
    const itemPath = route(item.path, `navigation-path:${id}`);
    if (navigationPaths.has(itemPath)) fail(`duplicate-navigation-path:${itemPath}`);
    navigationPaths.add(itemPath);
    if (item.required_capability !== undefined) {
      const required = nonEmpty(item.required_capability, `required-capability:${id}`);
      if (!capabilityIds.has(required)) fail(`unknown-required-capability:${id}:${required}`);
    }
  }

  return {
    productId: product.id,
    navigationCount: manifest.navigation.length,
    capabilityCount: manifest.capabilities.length
  };
}

function validateLockfile(root, expectedVersion, packageNames) {
  const lockFile = path.join(root, "package-lock.json");
  if (!fs.existsSync(lockFile)) return { present: false, packages: [] };

  const lock = readJson(lockFile, "lock");
  if (!lock || typeof lock !== "object" || Array.isArray(lock)) {
    fail("lock-object");
  }
  const packageMap = lock.packages;
  if (!packageMap || typeof packageMap !== "object" || Array.isArray(packageMap)) {
    fail("lock-packages");
  }

  const rootEntry = packageMap[""] ?? {};
  const rootFound = new Set();
  for (const section of [
    "dependencies",
    "devDependencies",
    "optionalDependencies",
    "peerDependencies"
  ]) {
    const values = rootEntry[section];
    if (!values || typeof values !== "object" || Array.isArray(values)) continue;
    for (const name of packageNames) {
      if (!Object.hasOwn(values, name)) continue;
      rootFound.add(name);
      if (values[name] !== expectedVersion) {
        fail(`lock-root-version:${name}:${values[name]}`);
      }
    }
  }
  for (const name of packageNames) {
    if (!rootFound.has(name)) fail(`lock-root-missing:${name}`);
    const directEntry = packageMap[`node_modules/${name}`];
    if (!directEntry) fail(`lock-package-missing:${name}`);
  }

  const locked = [];
  for (const name of FOUNDATION_PACKAGE_FAMILY) {
    const entry = packageMap[`node_modules/${name}`];
    if (!entry) continue;
    if (entry.version !== expectedVersion) {
      fail(`lock-package-version:${name}:${entry.version ?? "missing"}`);
    }
    locked.push(name);
  }
  return { present: true, packages: locked.sort() };
}

export function doctorProject({ root, manifestPath } = {}) {
  const resolvedRoot = path.resolve(root ?? process.cwd());
  const packageFile = path.join(resolvedRoot, "package.json");
  const packageManifest = readJson(packageFile, "package");
  const versions = inspectFoundationVersions(packageManifest);
  const lock = validateLockfile(
    resolvedRoot,
    versions.version,
    versions.packages
  );
  const resolvedManifest = path.resolve(
    manifestPath ?? path.join(resolvedRoot, "foundation.manifest.json")
  );
  const product = validateProductManifest(readJson(resolvedManifest, "manifest"));
  return {
    root: resolvedRoot,
    manifest: resolvedManifest,
    foundationVersion: versions.version,
    foundationPackages: versions.packages,
    lockfilePresent: lock.present,
    lockedFoundationPackages: lock.packages,
    ...product
  };
}
