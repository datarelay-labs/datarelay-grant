import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import {
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readlinkSync,
  readdirSync,
  realpathSync,
  rmSync,
  statSync,
  writeFileSync
} from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname, isAbsolute, join, relative, resolve } from "node:path";

const EXACT_SEMVER =
  /^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/;
const SHA40 = /^[0-9a-f]{40}$/;
const REPOSITORY = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
const STEP_GROUPS = [
  "static_type_build",
  "foundation_conformance",
  "product_regression"
];
const MAX_STEPS_PER_GROUP = 8;
const MAX_TIMEOUT_SECONDS = 1800;
const NPM_SCRIPT = /^[A-Za-z0-9][A-Za-z0-9:._-]{0,79}$/;
const FOUNDATION_PACKAGE_NAMES = [
  "@datarelay-labs/tokens",
  "@datarelay-labs/icons",
  "@datarelay-labs/ui",
  "@datarelay-labs/product-shell",
  "@datarelay-labs/auth-ui",
  "@datarelay-labs/system-contracts",
  "@datarelay-labs/system-admin-ui",
  "@datarelay-labs/testkit",
  "@datarelay-labs/foundation",
  "@datarelay-labs/foundation-cli"
];
const RESERVED_INHERITED_ENV = new Set([
  "HOME",
  "TMPDIR",
  "TMP",
  "TEMP",
  "NPM_CONFIG_CACHE",
  "DATARELAY_FOUNDATION_REPOSITORY",
  "DATARELAY_FOUNDATION_REVISION",
  "DATARELAY_FOUNDATION_VERSION",
  "DATARELAY_FOUNDATION_ROOT",
  "DATARELAY_CONSUMER_REPOSITORY",
  "DATARELAY_CONSUMER_REVISION",
  "DATARELAY_COMPATIBILITY_CONTRACT"
]);

function fail(reason) {
  throw new Error(reason);
}

function requireObject(value, name) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("invalid-object:" + name);
  }
  return value;
}

function requireString(value, name) {
  if (typeof value !== "string" || value.length === 0) {
    fail("invalid-string:" + name);
  }
  return value;
}

function rejectUnknownKeys(object, allowed, name) {
  for (const key of Object.keys(object)) {
    if (!allowed.has(key)) fail("unknown-field:" + name + "." + key);
  }
}

function resolveInputPath(baseDir, value, name) {
  const input = requireString(value, name);
  return isAbsolute(input) ? input : resolve(baseDir, input);
}

function hashFile(path) {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

function directoryTreeHash(root, prefix = "") {
  const files = [];
  const walk = (directory, currentPrefix) => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const relativePath = currentPrefix ? currentPrefix + "/" + entry.name : entry.name;
      const absolutePath = join(directory, entry.name);
      if (entry.isDirectory()) walk(absolutePath, relativePath);
      else if (entry.isFile()) files.push([relativePath, absolutePath]);
      else if (entry.isSymbolicLink()) {
        const target = realpathSync(absolutePath);
        if (statSync(target).isDirectory()) walk(target, relativePath);
        else files.push([relativePath, target]);
      }
    }
  };
  walk(root, prefix);
  files.sort((left, right) => (left[0] < right[0] ? -1 : left[0] > right[0] ? 1 : 0));
  const hash = createHash("sha256");
  for (const [relativePath, absolutePath] of files) {
    hash.update(relativePath);
    hash.update("\0");
    hash.update(readFileSync(absolutePath));
    hash.update("\0");
  }
  return hash.digest("hex");
}

function readJson(path, name) {
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch {
    fail("invalid-json:" + name);
  }
}

function run(argv, options = {}) {
  const result = spawnSync(argv[0], argv.slice(1), {
    cwd: options.cwd,
    env: options.env ?? process.env,
    encoding: "utf8",
    shell: false,
    timeout: (options.timeoutSeconds ?? 120) * 1000,
    maxBuffer: 4 * 1024 * 1024
  });

  if (result.error) {
    const code = result.error.code === "ETIMEDOUT" ? "timeout" : "spawn-error";
    return {
      ok: false,
      exitCode: null,
      reason: code + ":" + result.error.message
    };
  }

  if (result.signal) {
    return {
      ok: false,
      exitCode: result.status,
      reason: "signal:" + result.signal
    };
  }

  return {
    ok: result.status === 0,
    exitCode: result.status,
    reason: result.status === 0 ? null : "exit-code:" + String(result.status)
  };
}

function runGit(cwd, args, options = {}) {
  const result = run(["git", ...args], {
    cwd,
    timeoutSeconds: options.timeoutSeconds ?? 120
  });
  if (!result.ok && !options.allowFailure) {
    fail("git-failed:" + args.join(":") + ":" + result.reason);
  }
  return result;
}

function gitOutput(cwd, args) {
  const result = spawnSync("git", args, {
    cwd,
    encoding: "utf8",
    shell: false,
    timeout: 120000,
    maxBuffer: 1024 * 1024
  });
  if (result.status !== 0) {
    fail("git-failed:" + args.join(":"));
  }
  return result.stdout.trim();
}

function normalizeRepositoryRemote(remote) {
  const value = remote.trim().replace(/\.git$/, "");
  const https = value.match(/^https:\/\/github\.com\/([^/]+\/[^/]+)$/i);
  if (https) return https[1];
  const ssh = value.match(/^git@github\.com:([^/]+\/[^/]+)$/i);
  if (ssh) return ssh[1];
  const sshUrl = value.match(/^ssh:\/\/git@github\.com\/([^/]+\/[^/]+)$/i);
  if (sshUrl) return sshUrl[1];
  return null;
}

function verifyRepositoryBinding(source, repository, revision, options = {}) {
  if (!REPOSITORY.test(repository)) fail("invalid-repository:" + repository);
  if (!SHA40.test(revision)) fail("revision-must-be-exact-sha:" + revision);
  if (!existsSync(source) || !statSync(source).isDirectory()) {
    fail("source-not-directory:" + source);
  }

  const remote = gitOutput(source, ["remote", "get-url", "origin"]);
  const observedRepository = normalizeRepositoryRemote(remote);
  if (observedRepository !== repository) {
    fail("repository-origin-mismatch:" + repository);
  }

  runGit(source, ["cat-file", "-e", revision + "^{commit}"]);

  if (options.requireHead) {
    const head = gitOutput(source, ["rev-parse", "HEAD"]);
    if (head !== revision) fail("source-head-mismatch:" + revision);
  }
}

function foundationRelativeFile(source, file, revision, name) {
  if (!existsSync(file) || !statSync(file).isFile()) fail("file-not-found:" + name);
  const rootReal = realpathSync(source);
  const fileReal = realpathSync(file);
  const rel = relative(rootReal, fileReal);
  if (rel === ".." || rel.startsWith("../") || isAbsolute(rel)) {
    fail(name + "-outside-foundation-source");
  }

  const gitPath = rel.split("\\").join("/");
  const committed = spawnSync("git", ["show", revision + ":" + gitPath], {
    cwd: source,
    encoding: null,
    shell: false,
    timeout: 120000,
    maxBuffer: 4 * 1024 * 1024
  });
  if (committed.status !== 0) fail(name + "-not-at-foundation-revision");
  if (!Buffer.from(committed.stdout).equals(readFileSync(fileReal))) {
    fail(name + "-differs-from-foundation-revision");
  }
  return gitPath;
}

function repositoryFileFingerprint(source) {
  const listed = spawnSync(
    "git",
    ["ls-files", "-z", "--cached", "--others", "--exclude-standard"],
    {
      cwd: source,
      encoding: null,
      shell: false,
      timeout: 120000,
      maxBuffer: 16 * 1024 * 1024
    }
  );
  if (listed.status !== 0) fail("git-failed:ls-files");
  const paths = listed.stdout
    .toString("utf8")
    .split("\0")
    .filter(Boolean)
    .sort();

  const digest = createHash("sha256");
  for (const relativePath of paths) {
    digest.update(relativePath);
    digest.update("\0");
    const absolutePath = join(source, relativePath);
    try {
      const metadata = lstatSync(absolutePath);
      digest.update(String(metadata.mode & 0o7777));
      digest.update("\0");
      if (metadata.isSymbolicLink()) {
        digest.update("symlink\0");
        digest.update(readlinkSync(absolutePath));
      } else if (metadata.isFile()) {
        digest.update("file\0");
        digest.update(createHash("sha256").update(readFileSync(absolutePath)).digest());
      } else if (metadata.isDirectory()) {
        digest.update("directory\0");
      } else {
        digest.update("other\0");
      }
    } catch (error) {
      if (error && typeof error === "object" && error.code === "ENOENT") {
        digest.update("missing\0");
      } else {
        throw error;
      }
    }
    digest.update("\0");
  }
  return digest.digest("hex");
}

function snapshotRepository(source) {
  return {
    head: gitOutput(source, ["rev-parse", "HEAD"]),
    status: gitOutput(source, ["status", "--porcelain=v1", "--untracked-files=all"]),
    filesSha256: repositoryFileFingerprint(source)
  };
}

function sameSnapshot(left, right) {
  return (
    left.head === right.head &&
    left.status === right.status &&
    left.filesSha256 === right.filesSha256
  );
}

function safeStepCwd(workspace, step) {
  if (!step.cwd) return workspace;
  if (typeof step.cwd !== "string" || step.cwd.length === 0 || isAbsolute(step.cwd)) {
    fail("invalid-step-cwd:" + step.id);
  }
  const target = resolve(workspace, step.cwd);
  if (!existsSync(target) || !statSync(target).isDirectory()) {
    fail("step-cwd-missing:" + step.id);
  }
  const workspaceReal = realpathSync(workspace);
  const targetReal = realpathSync(target);
  const rel = relative(workspaceReal, targetReal);
  if (rel === ".." || rel.startsWith("../") || isAbsolute(rel)) {
    fail("step-cwd-outside-workspace:" + step.id);
  }
  return targetReal;
}

function validateCommands(commands) {
  const object = requireObject(commands, "commands");
  rejectUnknownKeys(object, new Set(STEP_GROUPS), "commands");
  const ids = new Set();
  for (const group of STEP_GROUPS) {
    const steps = object[group];
    if (!Array.isArray(steps) || steps.length === 0 || steps.length > MAX_STEPS_PER_GROUP) {
      fail("invalid-command-group:" + group);
    }
    for (const stepValue of steps) {
      const step = requireObject(stepValue, "step");
      rejectUnknownKeys(
        step,
        new Set(["id", "profile", "script", "cwd", "timeout_seconds"]),
        "step"
      );
      const id = requireString(step.id, "step.id");
      if (!/^[a-z0-9][a-z0-9._-]{0,79}$/.test(id)) fail("invalid-step-id:" + id);
      if (ids.has(id)) fail("duplicate-step-id:" + id);
      ids.add(id);
      if (step.profile !== "npm-script") fail("unsupported-command-profile:" + id);
      const script = requireString(step.script, "step.script");
      if (!NPM_SCRIPT.test(script)) fail("invalid-npm-script:" + id);
      if (
        step.timeout_seconds !== undefined &&
        (!Number.isInteger(step.timeout_seconds) ||
          step.timeout_seconds < 1 ||
          step.timeout_seconds > MAX_TIMEOUT_SECONDS)
      ) {
        fail("invalid-step-timeout:" + id);
      }
    }
  }
}

function validateUniqueStrings(value, name, { minItems = 0, pattern = null } = {}) {
  if (!Array.isArray(value) || value.length < minItems) {
    fail("invalid-string-list:" + name);
  }
  const seen = new Set();
  for (const item of value) {
    if (typeof item !== "string" || item.length === 0) {
      fail("invalid-string-list-item:" + name);
    }
    if (pattern && !pattern.test(item)) fail("invalid-string-list-item:" + name);
    if (seen.has(item)) fail("duplicate-string-list-item:" + name);
    seen.add(item);
  }
}

function validateContractSlice(value, name) {
  const slice = requireObject(value, name);
  rejectUnknownKeys(
    slice,
    new Set([
      "id",
      "surface",
      "foundation_packages",
      "required_capabilities",
      "parity_evidence"
    ]),
    name
  );
  if (!/^[a-z0-9][a-z0-9-]*$/.test(requireString(slice.id, name + ".id"))) {
    fail("invalid-contract-slice-id:" + name);
  }
  requireString(slice.surface, name + ".surface");
  validateUniqueStrings(slice.foundation_packages, name + ".foundation_packages", {
    minItems: 1,
    pattern: /^@datarelay-labs\/[a-z0-9-]+$/
  });
  validateUniqueStrings(
    slice.required_capabilities,
    name + ".required_capabilities"
  );
  validateUniqueStrings(slice.parity_evidence, name + ".parity_evidence", {
    minItems: 1
  });
  return slice;
}

function validateContract(contract, request) {
  const object = requireObject(contract, "compatibility-contract");
  rejectUnknownKeys(
    object,
    new Set([
      "contract_version",
      "consumer",
      "foundation",
      "initial_slice",
      "migration_sequence",
      "authority_boundaries",
      "prohibited_regressions"
    ]),
    "compatibility-contract"
  );
  if (object.contract_version !== 1) fail("unsupported-compatibility-contract-version");
  const consumer = requireObject(object.consumer, "contract.consumer");
  const foundation = requireObject(object.foundation, "contract.foundation");
  rejectUnknownKeys(
    consumer,
    new Set(["repository", "product_id", "evidence_revision"]),
    "contract.consumer"
  );
  rejectUnknownKeys(
    foundation,
    new Set(["repository", "baseline_revision"]),
    "contract.foundation"
  );

  if (consumer.repository !== request.consumer.repository) {
    fail("contract-consumer-repository-mismatch");
  }
  if (!/^[a-z][a-z0-9-]*$/.test(requireString(consumer.product_id, "contract.consumer.product_id"))) {
    fail("invalid-contract-product-id");
  }
  if (consumer.evidence_revision !== request.consumer.revision) {
    fail("contract-consumer-revision-mismatch");
  }
  if (foundation.repository !== request.foundation.repository) {
    fail("contract-foundation-repository-mismatch");
  }
  if (!SHA40.test(foundation.baseline_revision ?? "")) {
    fail("invalid-contract-foundation-baseline");
  }

  const initialSlice = validateContractSlice(
    object.initial_slice,
    "contract.initial_slice"
  );
  if (
    !Array.isArray(object.migration_sequence) ||
    object.migration_sequence.length === 0
  ) {
    fail("invalid-contract-migration-sequence");
  }
  const sequence = object.migration_sequence.map((slice, index) =>
    validateContractSlice(slice, "contract.migration_sequence[" + index + "]")
  );
  if (initialSlice.id !== sequence[0].id) {
    fail("invalid-contract-migration-sequence");
  }
  validateUniqueStrings(
    object.authority_boundaries,
    "contract.authority_boundaries",
    { minItems: 1 }
  );
  validateUniqueStrings(
    object.prohibited_regressions,
    "contract.prohibited_regressions",
    { minItems: 1 }
  );

  const ancestry = run(
    ["git", "merge-base", "--is-ancestor", foundation.baseline_revision, request.foundation.revision],
    { cwd: request.foundation.source, timeoutSeconds: 120 }
  );
  if (!ancestry.ok) fail("foundation-candidate-not-descended-from-contract-baseline");
}

function validateDelegatedEvidence(evidence, request) {
  const object = requireObject(evidence, "browser-user-gate-evidence");
  rejectUnknownKeys(
    object,
    new Set(["schema_version", "gate", "status", "foundation", "consumer", "evidence_ref"]),
    "browser-user-gate-evidence"
  );
  if (object.schema_version !== 1 || object.gate !== "browser_user_gate") {
    fail("invalid-browser-user-gate-evidence");
  }
  if (!["PASS", "FAIL", "BLOCKED"].includes(object.status)) {
    fail("invalid-browser-user-gate-status");
  }

  const foundation = requireObject(object.foundation, "gate.foundation");
  const consumer = requireObject(object.consumer, "gate.consumer");
  rejectUnknownKeys(
    foundation,
    new Set(["repository", "revision", "version"]),
    "gate.foundation"
  );
  rejectUnknownKeys(
    consumer,
    new Set(["repository", "revision"]),
    "gate.consumer"
  );
  if (
    foundation.repository !== request.foundation.repository ||
    foundation.revision !== request.foundation.revision ||
    foundation.version !== request.foundation.version ||
    consumer.repository !== request.consumer.repository ||
    consumer.revision !== request.consumer.revision
  ) {
    fail("browser-user-gate-evidence-binding-mismatch");
  }
  requireString(object.evidence_ref, "gate.evidence_ref");
  return object;
}

function validateRequest(rawRequest, baseDir) {
  const request = requireObject(rawRequest, "request");
  rejectUnknownKeys(
    request,
    new Set([
      "schema_version",
      "foundation",
      "consumer",
      "compatibility_contract",
      "commands",
      "browser_user_gate",
      "inherit_env"
    ]),
    "request"
  );
  if (request.schema_version !== 1) fail("unsupported-request-version");

  const foundation = requireObject(request.foundation, "foundation");
  const consumer = requireObject(request.consumer, "consumer");
  rejectUnknownKeys(
    foundation,
    new Set(["repository", "source", "revision", "version"]),
    "foundation"
  );
  rejectUnknownKeys(
    consumer,
    new Set(["repository", "source", "revision"]),
    "consumer"
  );

  requireString(foundation.repository, "foundation.repository");
  requireString(foundation.revision, "foundation.revision");
  requireString(foundation.version, "foundation.version");
  requireString(consumer.repository, "consumer.repository");
  requireString(consumer.revision, "consumer.revision");

  if (!EXACT_SEMVER.test(foundation.version)) {
    fail("foundation-version-must-be-exact-semver");
  }

  foundation.source = resolveInputPath(baseDir, foundation.source, "foundation.source");
  consumer.source = resolveInputPath(baseDir, consumer.source, "consumer.source");
  request.compatibility_contract = resolveInputPath(
    baseDir,
    request.compatibility_contract,
    "compatibility_contract"
  );

  const gate = requireObject(request.browser_user_gate, "browser_user_gate");
  rejectUnknownKeys(
    gate,
    new Set(["mode", "evidence_file"]),
    "browser_user_gate"
  );
  if (gate.mode !== "delegated") fail("browser-user-gate-must-be-delegated");
  if (gate.evidence_file !== undefined && gate.evidence_file !== null) {
    gate.evidence_file = resolveInputPath(baseDir, gate.evidence_file, "browser_user_gate.evidence_file");
  }

  if (request.inherit_env !== undefined) {
    if (!Array.isArray(request.inherit_env) || request.inherit_env.length > 32) {
      fail("invalid-inherit-env");
    }
    const seenEnv = new Set();
    for (const name of request.inherit_env) {
      if (typeof name !== "string" || !/^[A-Z_][A-Z0-9_]*$/.test(name)) {
        fail("invalid-inherit-env-name");
      }
      if (seenEnv.has(name)) fail("duplicate-inherit-env-name:" + name);
      if (RESERVED_INHERITED_ENV.has(name)) fail("reserved-inherit-env-name:" + name);
      seenEnv.add(name);
    }
  }

  validateCommands(request.commands);
  verifyRepositoryBinding(
    foundation.source,
    foundation.repository,
    foundation.revision,
    { requireHead: true }
  );
  verifyRepositoryBinding(
    consumer.source,
    consumer.repository,
    consumer.revision,
    { requireHead: true }
  );

  request.compatibility_contract_relative = foundationRelativeFile(
    foundation.source,
    request.compatibility_contract,
    foundation.revision,
    "compatibility-contract"
  );
  const contract = readJson(request.compatibility_contract, "compatibility-contract");
  validateContract(contract, request);

  return { request, contract };
}

function recordBlockedRemaining(receipt, commands, startGroupIndex, startStepIndex, reason) {
  for (let groupIndex = startGroupIndex; groupIndex < STEP_GROUPS.length; groupIndex += 1) {
    const group = STEP_GROUPS[groupIndex];
    const steps = commands[group];
    const from = groupIndex === startGroupIndex ? startStepIndex : 0;
    for (let stepIndex = from; stepIndex < steps.length; stepIndex += 1) {
      receipt.steps.push({
        group,
        id: steps[stepIndex].id,
        status: "BLOCKED",
        reason
      });
    }
  }
}

function buildCommandEnv(request, foundationWorkspace, runtimeHome) {
  const env = {};
  for (const name of ["PATH", "CI", "NO_COLOR"]) {
    if (process.env[name] !== undefined) env[name] = process.env[name];
  }
  for (const name of request.inherit_env ?? []) {
    if (process.env[name] !== undefined) env[name] = process.env[name];
  }
  const runtimeTmp = join(runtimeHome, "tmp");
  const npmCache = join(runtimeHome, ".npm");
  return {
    ...env,
    HOME: runtimeHome,
    TMPDIR: runtimeTmp,
    TMP: runtimeTmp,
    TEMP: runtimeTmp,
    NPM_CONFIG_CACHE: npmCache,
    DATARELAY_FOUNDATION_REPOSITORY: request.foundation.repository,
    DATARELAY_FOUNDATION_REVISION: request.foundation.revision,
    DATARELAY_FOUNDATION_VERSION: request.foundation.version,
    DATARELAY_FOUNDATION_ROOT: foundationWorkspace,
    DATARELAY_CONSUMER_REPOSITORY: request.consumer.repository,
    DATARELAY_CONSUMER_REVISION: request.consumer.revision,
    DATARELAY_COMPATIBILITY_CONTRACT: join(
      foundationWorkspace,
      request.compatibility_contract_relative
    )
  };
}

function prepareCandidateOverlay(
  request,
  consumerWorkspace,
  foundationWorkspace,
  tempRoot,
  runtimeHome,
  receipt
) {
  const env = buildCommandEnv(request, foundationWorkspace, runtimeHome);
  const packageLock = join(consumerWorkspace, "package-lock.json");
  if (!existsSync(packageLock) || !statSync(packageLock).isFile()) {
    fail("consumer-package-lock-required");
  }

  const foundationInstall = run(
    ["npm", "ci", "--ignore-scripts", "--no-audit", "--no-fund"],
    { cwd: foundationWorkspace, env, timeoutSeconds: 600 }
  );
  if (!foundationInstall.ok) fail("foundation-install-failed:" + foundationInstall.reason);

  const stageRoot = join(tempRoot, "foundation-candidate");
  const install = run(["npm", "ci", "--ignore-scripts", "--no-audit", "--no-fund"], {
    cwd: foundationWorkspace,
    env,
    timeoutSeconds: 300
  });
  if (!install.ok) fail("foundation-candidate-install-failed:" + install.reason);

  const stage = run(
    [
      process.execPath,
      join(foundationWorkspace, "tools", "stage-release.mjs"),
      "--version",
      request.foundation.version,
      "--out",
      stageRoot
    ],
    { cwd: foundationWorkspace, env, timeoutSeconds: 300 }
  );
  if (!stage.ok) fail("foundation-candidate-stage-failed:" + stage.reason);

  const releaseManifestPath = join(stageRoot, "release-manifest.json");
  const releaseManifest = readJson(releaseManifestPath, "foundation-release-manifest");
  if (
    releaseManifest.schema_version !== 1 ||
    releaseManifest.version !== request.foundation.version ||
    !Array.isArray(releaseManifest.packages)
  ) {
    fail("invalid-foundation-release-manifest");
  }

  const packagesByName = new Map();
  for (const packageValue of releaseManifest.packages) {
    const packageResult = requireObject(packageValue, "foundation-release-package");
    rejectUnknownKeys(
      packageResult,
      new Set(["name", "path", "sha256"]),
      "foundation-release-package"
    );
    const name = requireString(packageResult.name, "foundation-release-package.name");
    const packagePath = requireString(packageResult.path, "foundation-release-package.path");
    const sha256 = requireString(packageResult.sha256, "foundation-release-package.sha256");
    if (!FOUNDATION_PACKAGE_NAMES.includes(name) || packagesByName.has(name)) {
      fail("invalid-foundation-release-package:" + name);
    }
    if (!/^[a-z0-9-]+$/.test(packagePath) || !/^[0-9a-f]{64}$/.test(sha256)) {
      fail("invalid-foundation-release-package:" + name);
    }
    const stagedPackageRoot = join(stageRoot, packagePath);
    if (!existsSync(stagedPackageRoot) || !statSync(stagedPackageRoot).isDirectory()) {
      fail("missing-foundation-release-package:" + name);
    }
    if (directoryTreeHash(stagedPackageRoot) !== sha256) {
      fail("foundation-release-package-hash-mismatch:" + name);
    }
    packagesByName.set(name, { path: stagedPackageRoot, sha256 });
  }
  if (
    packagesByName.size !== FOUNDATION_PACKAGE_NAMES.length ||
    FOUNDATION_PACKAGE_NAMES.some((name) => !packagesByName.has(name))
  ) {
    fail("foundation-release-package-family-incomplete");
  }

  const consumerInstall = run(
    ["npm", "ci", "--ignore-scripts", "--no-audit", "--no-fund"],
    { cwd: consumerWorkspace, env, timeoutSeconds: 600 }
  );
  if (!consumerInstall.ok) fail("consumer-install-failed:" + consumerInstall.reason);

  const overlay = run(
    [
      "npm",
      "install",
      "--no-save",
      "--package-lock=false",
      "--ignore-scripts",
      "--no-audit",
      "--no-fund",
      "--legacy-peer-deps",
      "--install-links=true",
      ...FOUNDATION_PACKAGE_NAMES.map((name) => packagesByName.get(name).path)
    ],
    { cwd: consumerWorkspace, env, timeoutSeconds: 600 }
  );
  if (!overlay.ok) fail("foundation-candidate-overlay-failed:" + overlay.reason);

  for (const name of FOUNDATION_PACKAGE_NAMES) {
    const installedRoot = join(consumerWorkspace, "node_modules", ...name.split("/"));
    if (!existsSync(installedRoot) || !statSync(installedRoot).isDirectory()) {
      fail("foundation-candidate-package-missing:" + name);
    }
    const installedManifest = readJson(
      join(installedRoot, "package.json"),
      "installed-foundation-package"
    );
    if (installedManifest.name !== name || installedManifest.version !== request.foundation.version) {
      fail("foundation-candidate-version-mismatch:" + name);
    }
    if (directoryTreeHash(installedRoot) !== packagesByName.get(name).sha256) {
      fail("foundation-candidate-content-mismatch:" + name);
    }
  }

  receipt.steps.push({
    group: "runner",
    id: "foundation-candidate-overlay",
    status: "PASS",
    reason: null,
    evidence_ref: "sha256:" + hashFile(releaseManifestPath)
  });
}

function executeCommands(request, workspace, foundationWorkspace, runtimeHome, receipt) {
  const env = buildCommandEnv(request, foundationWorkspace, runtimeHome);

  for (let groupIndex = 0; groupIndex < STEP_GROUPS.length; groupIndex += 1) {
    const group = STEP_GROUPS[groupIndex];
    const steps = request.commands[group];
    for (let stepIndex = 0; stepIndex < steps.length; stepIndex += 1) {
      const step = steps[stepIndex];
      const cwd = safeStepCwd(workspace, step);
      const result = run(["npm", "run", "--silent", step.script], {
        cwd,
        env,
        timeoutSeconds: step.timeout_seconds ?? 300
      });
      receipt.steps.push({
        group,
        id: step.id,
        status: result.ok ? "PASS" : "FAIL",
        exit_code: result.exitCode,
        reason: result.reason
      });
      if (!result.ok) {
        recordBlockedRemaining(
          receipt,
          request.commands,
          groupIndex,
          stepIndex + 1,
          "prior-step-failed:" + step.id
        );
        return false;
      }
    }
  }
  return true;
}

function isWithinSource(source, candidate) {
  const rel = relative(realpathSync(source), candidate);
  return rel === "" || (!rel.startsWith("../") && rel !== ".." && !isAbsolute(rel));
}

function safeOutputPath(pathValue, sources) {
  const target = resolve(pathValue);
  const parent = dirname(target);
  if (!existsSync(parent) || !statSync(parent).isDirectory()) {
    fail("output-parent-not-directory");
  }
  const parentReal = realpathSync(parent);
  const candidate = existsSync(target)
    ? realpathSync(target)
    : join(parentReal, basename(target));
  for (const source of sources) {
    if (isWithinSource(source, candidate)) {
      fail("output-path-inside-canonical-source");
    }
  }
  return target;
}

function atomicWriteJson(path, value) {
  const target = resolve(path);
  const temp = target + ".tmp";
  writeFileSync(temp, JSON.stringify(value, null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
  writeFileSync(target, readFileSync(temp));
  rmSync(temp, { force: true });
}

export function runCompatibilityLab(rawRequest, options = {}) {
  const baseDir = options.baseDir ? resolve(options.baseDir) : process.cwd();
  const { request } = validateRequest(rawRequest, baseDir);
  const consumerSourceSnapshot = snapshotRepository(request.consumer.source);
  const foundationSourceSnapshot = snapshotRepository(request.foundation.source);
  const contractSha256 = hashFile(request.compatibility_contract);

  const receipt = {
    schema_version: 1,
    status: "BLOCKED",
    foundation: {
      repository: request.foundation.repository,
      revision: request.foundation.revision,
      version: request.foundation.version
    },
    consumer: {
      repository: request.consumer.repository,
      revision: request.consumer.revision
    },
    compatibility_contract_sha256: contractSha256,
    workspace_mode: "isolated_clones",
    canonical_foundation_source_unchanged: "UNKNOWN",
    canonical_consumer_source_unchanged: "UNKNOWN",
    cleanup: "PENDING",
    steps: []
  };

  let tempRoot = null;
  let commandPass = false;
  let cleanupPass = false;

  try {
    tempRoot = mkdtempSync(join(tmpdir(), "datarelay-foundation-lab-"));
    const foundationWorkspace = join(tempRoot, "foundation");
    const consumerWorkspace = join(tempRoot, "consumer");
    const runtimeHome = join(tempRoot, "home");
    mkdirSync(join(runtimeHome, "tmp"), { recursive: true, mode: 0o700 });
    mkdirSync(join(runtimeHome, ".npm"), { recursive: true, mode: 0o700 });

    const foundationClone = run(
      ["git", "clone", "--quiet", "--no-checkout", "--no-hardlinks", request.foundation.source, foundationWorkspace],
      { timeoutSeconds: 300 }
    );
    if (!foundationClone.ok) fail("foundation-clone-failed:" + foundationClone.reason);
    runGit(foundationWorkspace, ["checkout", "--quiet", "--detach", request.foundation.revision]);
    if (gitOutput(foundationWorkspace, ["rev-parse", "HEAD"]) !== request.foundation.revision) {
      fail("isolated-foundation-head-mismatch");
    }

    const consumerClone = run(
      ["git", "clone", "--quiet", "--no-checkout", "--no-hardlinks", request.consumer.source, consumerWorkspace],
      { timeoutSeconds: 300 }
    );
    if (!consumerClone.ok) fail("consumer-clone-failed:" + consumerClone.reason);
    runGit(consumerWorkspace, ["checkout", "--quiet", "--detach", request.consumer.revision]);
    if (gitOutput(consumerWorkspace, ["rev-parse", "HEAD"]) !== request.consumer.revision) {
      fail("isolated-consumer-head-mismatch");
    }

    prepareCandidateOverlay(
      request,
      consumerWorkspace,
      foundationWorkspace,
      tempRoot,
      runtimeHome,
      receipt
    );

    commandPass = executeCommands(
      request,
      consumerWorkspace,
      foundationWorkspace,
      runtimeHome,
      receipt
    );

    if (commandPass) {
      const evidenceFile = request.browser_user_gate.evidence_file;
      if (evidenceFile) {
        const gateEvidence = validateDelegatedEvidence(
          readJson(evidenceFile, "browser-user-gate-evidence"),
          request
        );
        const delegatedStatus = gateEvidence.status === "FAIL" ? "FAIL" : "BLOCKED";
        receipt.steps.push({
          group: "browser_user_gate",
          id: "delegated-browser-user-gate",
          status: delegatedStatus,
          reason:
            gateEvidence.status === "PASS"
              ? "delegated-pass-requires-authoritative-boundary"
              : "delegated-evidence:" + gateEvidence.status,
          evidence_ref: gateEvidence.evidence_ref
        });
        receipt.status = delegatedStatus;
      } else {
        receipt.steps.push({
          group: "browser_user_gate",
          id: "delegated-browser-user-gate",
          status: "BLOCKED",
          reason: "delegated-evidence-required"
        });
        receipt.status = "BLOCKED";
      }
    } else {
      receipt.steps.push({
        group: "browser_user_gate",
        id: "delegated-browser-user-gate",
        status: "BLOCKED",
        reason: "prior-step-failed"
      });
      receipt.status = "FAIL";
    }
  } catch (error) {
    receipt.status = "FAIL";
    receipt.steps.push({
      group: "runner",
      id: "runner-validation",
      status: "FAIL",
      reason: error instanceof Error ? error.message : "unknown"
    });
  } finally {
    if (tempRoot) {
      try {
        rmSync(tempRoot, { recursive: true, force: true });
        cleanupPass = !existsSync(tempRoot);
      } catch {
        cleanupPass = false;
      }
    } else {
      cleanupPass = true;
    }
    receipt.cleanup = cleanupPass ? "PASS" : "FAIL";

    try {
      const foundationAfter = snapshotRepository(request.foundation.source);
      receipt.canonical_foundation_source_unchanged = sameSnapshot(
        foundationSourceSnapshot,
        foundationAfter
      )
        ? "PASS"
        : "FAIL";
    } catch {
      receipt.canonical_foundation_source_unchanged = "FAIL";
    }

    try {
      const consumerAfter = snapshotRepository(request.consumer.source);
      receipt.canonical_consumer_source_unchanged = sameSnapshot(
        consumerSourceSnapshot,
        consumerAfter
      )
        ? "PASS"
        : "FAIL";
    } catch {
      receipt.canonical_consumer_source_unchanged = "FAIL";
    }

    if (
      receipt.cleanup !== "PASS" ||
      receipt.canonical_foundation_source_unchanged !== "PASS" ||
      receipt.canonical_consumer_source_unchanged !== "PASS"
    ) {
      receipt.status = "FAIL";
    }
  }

  return receipt;
}

export function runCompatibilityLabFromFile(requestPath, options = {}) {
  const absolute = resolve(requestPath);
  const request = readJson(absolute, "compatibility-request");
  const requestBase = dirname(absolute);
  let outputPath = null;
  if (options.outputPath) {
    const foundationSource = resolveInputPath(
      requestBase,
      requireObject(request.foundation, "foundation").source,
      "foundation.source"
    );
    const consumerSource = resolveInputPath(
      requestBase,
      requireObject(request.consumer, "consumer").source,
      "consumer.source"
    );
    outputPath = safeOutputPath(options.outputPath, [
      foundationSource,
      consumerSource
    ]);
  }
  const receipt = runCompatibilityLab(request, {
    baseDir: requestBase
  });
  if (outputPath) atomicWriteJson(outputPath, receipt);
  return receipt;
}
