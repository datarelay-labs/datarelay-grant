export declare const COMMON_ERROR_CATEGORIES: readonly ["validation", "unauthenticated", "forbidden", "conflict", "stale_state", "unavailable", "interrupted", "failed"];
export type CommonErrorCategory = (typeof COMMON_ERROR_CATEGORIES)[number];
export type AdapterError = {
    category: CommonErrorCategory;
    message: string;
    code?: string;
    detail?: unknown;
};
export declare const OPERATION_EFFECTS: readonly ["long_running", "reconnect_required", "restart_required", "destructive", "security_sensitive"];
export type OperationEffect = (typeof OPERATION_EFFECTS)[number];
export type CapabilityAvailability = "supported" | "read_only" | "unavailable";
export type CapabilityProjection = {
    id: string;
    label: string;
    availability: CapabilityAvailability;
    effects?: readonly OperationEffect[];
    permission?: string;
    notes?: string;
};
export declare const JOB_STATES: readonly ["QUEUED", "RUNNING", "SUCCEEDED", "FAILED", "CANCELLED"];
export type JobState = (typeof JOB_STATES)[number];
export type JobProjection<Result = unknown> = {
    id: string;
    state: JobState;
    label?: string;
    progressPercent?: number;
    statusMessage?: string;
    result?: Result;
    error?: AdapterError;
    cancellable?: boolean;
    auditReference?: string;
};
export type AuditReference = {
    id: string;
    label?: string;
};
export type ReadBack<State> = {
    effective: State;
    revision?: string;
    readAt?: string;
    audit?: AuditReference;
};
export type PreviewChange = {
    field: string;
    before?: string;
    after?: string;
    note?: string;
};
export type OperationPreview<Detail = unknown> = {
    supported: boolean;
    summary?: string;
    effects?: readonly OperationEffect[];
    changes?: readonly PreviewChange[];
    detail?: Detail;
};
export type MutationOutcome<State = unknown, Result = unknown> = {
    effective?: ReadBack<State>;
    job?: JobProjection<Result>;
    audit?: AuditReference;
    reconnectTargets?: readonly string[];
};
export type OpaqueChoice<Value = string> = {
    value: Value;
    label: string;
    description?: string;
};
export type AccountProjection<RoleValue = string> = {
    id: string;
    displayName: string;
    status?: string;
    role?: OpaqueChoice<RoleValue>;
    capabilities?: readonly string[];
    detail?: string;
};
export type HealthStatus = "healthy" | "degraded" | "unhealthy" | "unknown";
export type HealthProjection = {
    status: HealthStatus;
    checks?: readonly {
        id: string;
        label: string;
        status: HealthStatus;
        detail?: string;
    }[];
};
export type SystemInfoProjection = {
    facts: readonly {
        id: string;
        label: string;
        value: string;
    }[];
};
export type AuditEventProjection = {
    id: string;
    timestamp: string;
    action: string;
    actor?: string;
    outcome?: string;
    summary?: string;
    reference?: string;
};
export type RevisionProjection = {
    id: string;
    timestamp: string;
    label?: string;
    actor?: string;
    summary?: string;
    current?: boolean;
    audit?: AuditReference;
};
export type ArtifactReference = {
    id: string;
    label: string;
    sizeBytes?: number;
};
export type UpgradeCandidate = {
    currentVersion: string;
    targetVersion?: string;
    available: boolean;
    notes?: readonly string[];
};
