import type { CapabilityAvailability, JobState, OperationPreview } from "./types";
export declare function capabilityInteractive(availability: CapabilityAvailability): boolean;
export declare function capabilityVisible(availability: CapabilityAvailability): boolean;
export declare function jobTerminal(state: JobState): boolean;
export declare function previewNeedsExplicitConfirmation(preview: OperationPreview | undefined): boolean;
