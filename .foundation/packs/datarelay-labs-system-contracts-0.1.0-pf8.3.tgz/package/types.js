export const COMMON_ERROR_CATEGORIES = [
    "validation",
    "unauthenticated",
    "forbidden",
    "conflict",
    "stale_state",
    "unavailable",
    "interrupted",
    "failed"
];
export const OPERATION_EFFECTS = [
    "long_running",
    "reconnect_required",
    "restart_required",
    "destructive",
    "security_sensitive"
];
export const JOB_STATES = [
    "QUEUED",
    "RUNNING",
    "SUCCEEDED",
    "FAILED",
    "CANCELLED"
];
