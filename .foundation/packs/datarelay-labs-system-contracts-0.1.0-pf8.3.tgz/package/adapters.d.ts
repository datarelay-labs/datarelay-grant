import type { AccountProjection, ArtifactReference, AuditEventProjection, HealthProjection, JobProjection, MutationOutcome, OperationPreview, ReadBack, RevisionProjection, SystemInfoProjection, UpgradeCandidate } from "./types";
export type AccountsAdapter<Account = AccountProjection, Draft = unknown> = {
    list: () => Promise<readonly Account[]>;
    get?: (id: string) => Promise<Account>;
    create?: (draft: Draft) => Promise<Account>;
    update?: (id: string, draft: Draft) => Promise<Account>;
    disable?: (id: string) => Promise<Account>;
};
export type NetworkAdapter<State, Draft, PreviewDetail = unknown> = {
    read: () => Promise<ReadBack<State>>;
    validate?: (draft: Draft) => Promise<void>;
    preview?: (draft: Draft) => Promise<OperationPreview<PreviewDetail>>;
    saveDesired: (draft: Draft) => Promise<ReadBack<State>>;
    apply: () => Promise<MutationOutcome<State>>;
};
export type TlsAdapter<State, Draft, PreviewDetail = unknown> = {
    read: () => Promise<ReadBack<State>>;
    preview?: (draft: Draft) => Promise<OperationPreview<PreviewDetail>>;
    apply: (draft: Draft) => Promise<MutationOutcome<State>>;
};
export type ConfigTransferAdapter<ImportDraft = unknown, PreviewDetail = unknown> = {
    exportConfiguration: () => Promise<ArtifactReference | JobProjection<ArtifactReference>>;
    previewImport: (draft: ImportDraft) => Promise<OperationPreview<PreviewDetail>>;
    applyImport: (draft: ImportDraft) => Promise<MutationOutcome>;
};
export type DisasterRecoveryAdapter<RestoreTarget = string, PreviewDetail = unknown> = {
    createBackup: () => Promise<JobProjection<ArtifactReference>>;
    previewRestore?: (target: RestoreTarget) => Promise<OperationPreview<PreviewDetail>>;
    restoreBackup: (target: RestoreTarget) => Promise<JobProjection>;
};
export type ProductUpgradeAdapter<PreviewDetail = unknown> = {
    check: () => Promise<UpgradeCandidate>;
    preview?: (targetVersion: string) => Promise<OperationPreview<PreviewDetail>>;
    apply: (targetVersion: string) => Promise<JobProjection>;
    rollback?: (targetVersion?: string) => Promise<JobProjection>;
};
export type JobsAdapter<Result = unknown> = {
    read: (jobId: string) => Promise<JobProjection<Result>>;
    cancel?: (jobId: string) => Promise<JobProjection<Result>>;
};
export type OperationsAdapter<AuditQuery = unknown, RevisionQuery = unknown> = {
    readHealth: () => Promise<HealthProjection>;
    readSystemInfo: () => Promise<SystemInfoProjection>;
    generateSupportBundle?: () => Promise<JobProjection<ArtifactReference>>;
    listAudit?: (query?: AuditQuery) => Promise<readonly AuditEventProjection[]>;
    listRevisions?: (query?: RevisionQuery) => Promise<readonly RevisionProjection[]>;
};
export type RetentionAdapter<State, Draft> = {
    read: () => Promise<ReadBack<State>>;
    configure?: (draft: Draft) => Promise<MutationOutcome<State>>;
    run?: () => Promise<JobProjection>;
};
export type TimezoneAdapter<State, Draft> = {
    read: () => Promise<ReadBack<State>>;
    configure?: (draft: Draft) => Promise<MutationOutcome<State>>;
};
