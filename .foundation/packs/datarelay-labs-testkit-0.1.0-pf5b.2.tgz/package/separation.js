import { SYSTEM_ADMIN_CAPABILITIES } from "@datarelay-labs/system-contracts";
import { report } from "./types.js";
export function verifyLifecycleCapabilitySeparation() {
    const findings = [];
    const config = [
        SYSTEM_ADMIN_CAPABILITIES.configTransferExport,
        SYSTEM_ADMIN_CAPABILITIES.configTransferImportPreview,
        SYSTEM_ADMIN_CAPABILITIES.configTransferImportApply
    ];
    const disasterRecovery = [
        SYSTEM_ADMIN_CAPABILITIES.disasterRecoveryCreate,
        SYSTEM_ADMIN_CAPABILITIES.disasterRecoveryRestore
    ];
    const upgrade = [
        SYSTEM_ADMIN_CAPABILITIES.productUpgradeCheck,
        SYSTEM_ADMIN_CAPABILITIES.productUpgradePreview,
        SYSTEM_ADMIN_CAPABILITIES.productUpgradeApply,
        SYSTEM_ADMIN_CAPABILITIES.productUpgradeRollback
    ];
    const all = [...config, ...disasterRecovery, ...upgrade];
    if (new Set(all).size !== all.length) {
        findings.push({
            id: "LIFECYCLE_CAPABILITY_COLLISION",
            message: "Configuration transfer, disaster recovery, and product upgrade IDs must remain distinct."
        });
    }
    return report(findings);
}
