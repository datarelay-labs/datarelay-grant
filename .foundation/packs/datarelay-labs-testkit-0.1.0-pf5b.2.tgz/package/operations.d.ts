import { type JobProjection, type MutationOutcome, type OperationPreview } from "@datarelay-labs/system-contracts";
import { type ConformanceReport } from "./types";
export declare function verifyJobProjection(job: JobProjection): ConformanceReport;
export declare function verifyMutationEvidence(preview: OperationPreview | undefined, outcome: MutationOutcome): ConformanceReport;
