import { type ConformanceReport } from "./types";
export declare function verifyLifecycleCapabilitySeparation(): ConformanceReport;
