import type { AuthAdapter } from "@datarelay-labs/auth-ui";
import { type ConformanceReport } from "./types";
export declare function verifySessionRevocationDelegation(adapter: AuthAdapter, expectedSessionId: string): Promise<ConformanceReport>;
