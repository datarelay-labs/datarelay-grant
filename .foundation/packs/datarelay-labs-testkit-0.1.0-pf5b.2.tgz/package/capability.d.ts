import { type CapabilityProjection } from "@datarelay-labs/system-contracts";
import { type ConformanceReport } from "./types";
export type CapabilityExpectation = {
    id: string;
    visible: boolean;
    interactive: boolean;
};
export declare function verifyCapabilityProjection(capabilities: readonly CapabilityProjection[], expectations: readonly CapabilityExpectation[]): ConformanceReport;
