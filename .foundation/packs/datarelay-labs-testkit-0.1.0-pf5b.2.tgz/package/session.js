import { report } from "./types.js";
export async function verifySessionRevocationDelegation(adapter, expectedSessionId) {
    const findings = [];
    if (!adapter.listSessions || !adapter.revokeSession) {
        return report([
            {
                id: "SESSION_ADAPTER_UNAVAILABLE",
                message: "Session conformance requires listSessions and revokeSession."
            }
        ]);
    }
    const sessions = await adapter.listSessions();
    const target = sessions.find((session) => session.id === expectedSessionId);
    if (!target) {
        findings.push({
            id: "SESSION_TARGET_MISSING",
            message: `Session ${expectedSessionId} was not returned by the adapter.`
        });
        return report(findings);
    }
    if (target.revocable !== true) {
        findings.push({
            id: "SESSION_TARGET_NOT_REVOCABLE",
            message: `Session ${expectedSessionId} is not marked revocable.`
        });
        return report(findings);
    }
    await adapter.revokeSession(expectedSessionId);
    return report(findings);
}
