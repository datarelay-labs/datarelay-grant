import { report } from "./types.js";
const validMethods = new Set(["totp", "recovery_code"]);
function validateFlowResult(result) {
    if (result.state !== "mfa_required")
        return [];
    const findings = [];
    if (result.methods.length === 0) {
        findings.push({
            id: "AUTH_MFA_METHODS_EMPTY",
            message: "mfa_required must expose at least one verification method."
        });
    }
    for (const method of result.methods) {
        if (!validMethods.has(method)) {
            findings.push({
                id: "AUTH_MFA_METHOD_UNKNOWN",
                message: `Unsupported MFA method: ${String(method)}.`
            });
        }
    }
    return findings;
}
export async function verifyAuthAdapter(adapter, fixture) {
    const findings = [];
    const result = await adapter.signIn({
        username: fixture.username,
        password: fixture.password
    });
    findings.push(...validateFlowResult(result));
    if (adapter.getCapabilities) {
        const capabilities = await adapter.getCapabilities();
        if (new Set(capabilities).size !== capabilities.length) {
            findings.push({
                id: "AUTH_CAPABILITIES_DUPLICATED",
                message: "Auth capability IDs must not be duplicated."
            });
        }
    }
    return report(findings);
}
