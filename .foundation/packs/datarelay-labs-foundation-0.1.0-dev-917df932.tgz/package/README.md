Private, unpublished Control-source DataRelay Foundation facade. See repository docs/CONTROL_FIRST_FOUNDATION_HANDOFF_2026-10-16.md.
