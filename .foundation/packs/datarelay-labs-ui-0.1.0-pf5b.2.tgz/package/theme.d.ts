import type { HTMLAttributes, ReactNode } from "react";
export type DataRelayThemeName = "light" | "dark";
export type ThemeRootProps = HTMLAttributes<HTMLDivElement> & {
    theme: DataRelayThemeName;
    children: ReactNode;
};
export declare function ThemeRoot({ theme, className, children, ...props }: ThemeRootProps): import("react").JSX.Element;
