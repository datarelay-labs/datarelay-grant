import type { ButtonHTMLAttributes } from "react";
export type ButtonVariant = "primary" | "secondary" | "danger" | "ghost";
export type ButtonSize = "sm" | "md";
export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: ButtonVariant;
    size?: ButtonSize;
};
export declare function Button({ variant, size, className, type, ...props }: ButtonProps): import("react").JSX.Element;
