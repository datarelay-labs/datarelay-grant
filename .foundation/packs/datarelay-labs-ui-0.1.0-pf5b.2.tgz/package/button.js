import { jsx as _jsx } from "react/jsx-runtime";
import { cx } from "./utils.js";
export function Button({ variant = "primary", size = "md", className, type = "button", ...props }) {
    return (_jsx("button", { ...props, type: type, className: cx("dr-button", `dr-button--${variant}`, `dr-button--${size}`, className) }));
}
