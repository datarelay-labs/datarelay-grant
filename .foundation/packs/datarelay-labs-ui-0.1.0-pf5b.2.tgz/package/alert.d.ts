import type { HTMLAttributes, ReactNode } from "react";
import type { StatusTone } from "./status-badge";
export type AlertProps = HTMLAttributes<HTMLDivElement> & {
    tone?: Exclude<StatusTone, "neutral">;
    title?: ReactNode;
};
export declare function Alert({ tone, title, className, children, ...props }: AlertProps): import("react").JSX.Element;
