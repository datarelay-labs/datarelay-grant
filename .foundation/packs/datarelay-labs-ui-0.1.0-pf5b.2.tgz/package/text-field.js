import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useId } from "react";
import { cx } from "./utils.js";
export function TextField({ id: suppliedId, label, hint, error, className, "aria-describedby": callerDescribedBy, "aria-invalid": callerInvalid, ...props }) {
    const generatedId = useId().replace(/:/g, "");
    const id = suppliedId ?? `dr-field-${generatedId}`;
    const hintId = `${id}-hint`;
    const errorId = `${id}-error`;
    const describedBy = [callerDescribedBy, hint ? hintId : "", error ? errorId : ""]
        .filter(Boolean)
        .join(" ") || undefined;
    const invalid = error ? true : callerInvalid;
    return (_jsxs("div", { className: "dr-field", children: [_jsx("label", { className: "dr-field__label", htmlFor: id, children: label }), _jsx("input", { ...props, id: id, className: cx("dr-input", error && "dr-input--error", className), "aria-invalid": invalid, "aria-describedby": describedBy }), hint ? (_jsx("div", { className: "dr-field__hint", id: hintId, children: hint })) : null, error ? (_jsx("div", { className: "dr-field__error", id: errorId, role: "alert", children: error })) : null] }));
}
