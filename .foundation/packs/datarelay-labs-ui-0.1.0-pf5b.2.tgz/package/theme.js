import { jsx as _jsx } from "react/jsx-runtime";
import { cx } from "./utils.js";
export function ThemeRoot({ theme, className, children, ...props }) {
    return (_jsx("div", { ...props, "data-dr-theme": theme, className: cx("dr-theme", className), children: children }));
}
