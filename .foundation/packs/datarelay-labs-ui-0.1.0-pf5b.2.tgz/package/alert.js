import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { DataRelayIcon } from "@datarelay-labs/icons";
import { cx } from "./utils.js";
const iconForTone = {
    info: "info",
    success: "check",
    warning: "alert",
    critical: "critical"
};
export function Alert({ tone = "info", title, className, children, ...props }) {
    return (_jsxs("div", { ...props, className: cx("dr-alert", `dr-alert--${tone}`, className), role: tone === "critical" ? "alert" : "status", children: [_jsx(DataRelayIcon, { className: "dr-alert__icon", name: iconForTone[tone] }), _jsxs("div", { children: [title ? _jsx("div", { className: "dr-alert__title", children: title }) : null, _jsx("div", { className: "dr-alert__content", children: children })] })] }));
}
