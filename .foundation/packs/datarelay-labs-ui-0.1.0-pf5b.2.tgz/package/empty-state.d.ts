import type { ReactNode } from "react";
export type EmptyStateProps = {
    title: ReactNode;
    description?: ReactNode;
    action?: ReactNode;
};
export declare function EmptyState({ title, description, action }: EmptyStateProps): import("react").JSX.Element;
