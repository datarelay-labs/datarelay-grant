import type { HTMLAttributes } from "react";
export type StatusTone = "neutral" | "info" | "success" | "warning" | "critical";
export type StatusBadgeProps = HTMLAttributes<HTMLSpanElement> & {
    tone?: StatusTone;
};
export declare function StatusBadge({ tone, className, ...props }: StatusBadgeProps): import("react").JSX.Element;
