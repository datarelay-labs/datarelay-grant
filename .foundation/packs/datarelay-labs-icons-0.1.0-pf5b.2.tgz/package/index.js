import { jsx as _jsx } from "react/jsx-runtime";
import { Activity, AlertTriangle, ArchiveRestore, CheckCircle2, ChevronDown, CircleHelp, Download, FileClock, HardDrive, Home, Info, KeyRound, Lock, LogOut, Menu, Network, PanelLeftClose, PanelLeftOpen, RefreshCw, Search, Settings, Shield, Upload, User, Users, X, XCircle } from "lucide-react";
const icons = {
    activity: Activity,
    alert: AlertTriangle,
    audit: FileClock,
    backup: HardDrive,
    check: CheckCircle2,
    chevronDown: ChevronDown,
    close: X,
    critical: XCircle,
    download: Download,
    help: CircleHelp,
    home: Home,
    info: Info,
    key: KeyRound,
    lock: Lock,
    logOut: LogOut,
    menu: Menu,
    network: Network,
    panelClose: PanelLeftClose,
    panelOpen: PanelLeftOpen,
    refresh: RefreshCw,
    restore: ArchiveRestore,
    search: Search,
    settings: Settings,
    shield: Shield,
    upload: Upload,
    user: User,
    users: Users
};
export function DataRelayIcon({ name, label, ...props }) {
    const Icon = icons[name];
    return (_jsx(Icon, { ...props, ...(label ? { "aria-label": label, role: "img" } : { "aria-hidden": true }) }));
}
export { icons as dataRelayIcons };
