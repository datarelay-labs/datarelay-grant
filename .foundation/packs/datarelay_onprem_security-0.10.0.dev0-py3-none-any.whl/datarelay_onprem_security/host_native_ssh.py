"""Explicit opt-in privileged Linux SSH ACL authority with reboot and timer recovery.

The helper is a ROOT-ONLY command-line executable. The user-facing ASGI server
must invoke it through a separately provisioned narrowly scoped privileged
launcher; it must never run as root or accept raw nft/systemd command strings.
No network rule is changed merely by importing this module.
"""
from __future__ import annotations

import argparse
import fcntl
import ipaddress
import json
import os
import re
import secrets
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from .host_ssh_nft import _write_json
from .acl import canonical_network

TABLE = "drf_foundation_ssh"
CHAIN = "ssh_input"
_ID = re.compile(r"op-[0-9a-f]{20}\Z")
_DEFAULT_UNIT = "drf-foundation-ssh-restore.service"


class HostSshError(RuntimeError):
    pass


def _run(argv: list[str], *, data: str | None = None, timeout: int = 12):
    result = subprocess.run(argv, input=data, capture_output=True, text=True,
                            timeout=timeout, check=False)
    if result.returncode:
        raise HostSshError("Native host command failed: " + result.stderr[-280:])
    return result.stdout


def _root_only():
    if os.geteuid() != 0:
        raise HostSshError("A root-owned helper is required; no unprivileged fallback.")


def _sources(values: list[str]) -> list[str]:
    if not isinstance(values, list) or not 1 <= len(values) <= 64:
        raise HostSshError("SSH access requires 1–64 IP CIDRs.")
    result = []
    for value in values:
        if not isinstance(value, str):
            raise HostSshError("SSH CIDR must be text.")
        cidr = canonical_network(value)
        if ipaddress.ip_network(cidr).prefixlen == 0:
            raise HostSshError("Unrestricted SSH access is forbidden.")
        if cidr in result:
            raise HostSshError("Duplicate SSH source.")
        result.append(cidr)
    return result


def _read(path: Path) -> dict:
    if path.is_symlink() or not path.is_file() or path.stat().st_mode & 0o077:
        raise HostSshError("Native journal is missing or has insecure permissions.")
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise HostSshError("Native journal must be a JSON object.")
    return value


class NativeHostSsh:
    """Own ONLY the dedicated drf_foundation_ssh inet table, never Docker rules."""

    def __init__(self, state_root: str | Path):
        _root_only()
        root = Path(state_root)
        if not root.is_absolute() or root.is_symlink() or (
            root.exists() and (not root.is_dir() or root.stat().st_mode & 0o077)
        ):
            raise HostSshError("Use a private absolute root-owned state directory.")
        if root.exists() and root.stat().st_uid != 0:
            raise HostSshError("State directory must be owned by root.")
        self.root = root
        self.saved = root / "confirmed.json"
        self.pending = root / "pending.json"
        self.lock = root / "lock"

    @contextmanager
    def guard(self):
        if not self.root.is_dir():
            raise HostSshError("Run explicit native install first.")
        fd = os.open(self.lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    @staticmethod
    def _nft(command: list[str], script: str | None = None):
        return _run(["/usr/sbin/nft", *command], data=script)

    def _table_exists(self) -> bool:
        return subprocess.run(
            ["/usr/sbin/nft", "list", "table", "inet", TABLE],
            capture_output=True, timeout=7, check=False
        ).returncode == 0

    def _install_kernel(self):
        if not self._table_exists():
            self._nft(["-f", "-"], (
                f"add table inet {TABLE}\n"
                f"add chain inet {TABLE} {CHAIN} "
                "{ type filter hook input priority -175; policy accept; }\n"
            ))

    def _rules(self, sources: list[str], port: int):
        if sources:
            sources = _sources(sources)
        lines = [f"flush chain inet {TABLE} {CHAIN}"]
        for network in sources:
            family = "ip6" if ipaddress.ip_network(network).version == 6 else "ip"
            lines.append(
                f"add rule inet {TABLE} {CHAIN} tcp dport {port} "
                f"{family} saddr {network} accept"
            )
        if sources:
            lines.append(f"add rule inet {TABLE} {CHAIN} tcp dport {port} drop")
        script = "\n".join(lines) + "\n"
        self._nft(["--check", "-f", "-"], script)
        self._nft(["-f", "-"], script)

    def _observe(self, sources: list[str], port: int) -> bool:
        """Exact ordered nft JSON comparison, including CIDR prefix and port."""
        try:
            nft = json.loads(self._nft(["-j", "list", "chain", "inet", TABLE, CHAIN]))
            entries = nft["nftables"]
            chain = [row["chain"] for row in entries if "chain" in row]
            rules = [row["rule"] for row in entries if "rule" in row]
            if len(chain) != 1:
                return False
            if any(chain[0].get(k) != v for k, v in {
                "family": "inet", "table": TABLE, "name": CHAIN,
                "type": "filter", "hook": "input", "prio": -175,
                "policy": "accept"
            }.items()):
                return False
            expected = []
            portexpr = {"match": {"op": "==", "left": {
                "payload": {"protocol": "tcp", "field": "dport"}}, "right": port}}
            for cidr in sources:
                network = ipaddress.ip_network(cidr, strict=True)
                addr: object = str(network.network_address)
                if network.prefixlen != network.max_prefixlen:
                    addr = {"prefix": {"addr": addr, "len": network.prefixlen}}
                expected.append([
                    portexpr,
                    {"match": {"op": "==", "left": {"payload": {
                        "protocol": "ip6" if network.version == 6 else "ip",
                        "field": "saddr"}}, "right": addr}},
                    {"accept": None},
                ])
            if sources:
                expected.append([portexpr, {"drop": None}])
            if len(rules) != len(expected):
                return False
            for actual, expr in zip(rules, expected):
                if (actual.get("family"), actual.get("table"), actual.get("chain")) != (
                    "inet", TABLE, CHAIN
                ) or actual.get("expr") != expr:
                    return False
            return True
        except (ValueError, TypeError, KeyError, OSError):
            return False

    def install(self, *, port: int, rescue: str, enable_boot: bool = False):
        if type(port) is not int or not (1024 <= port <= 65535):
            raise HostSshError("Require an explicit non-system SSH port.")
        rescues = _sources([rescue])
        if self.root.exists():
            raise HostSshError("Refusing to overwrite installed SSH ACL authority.")
        self.root.mkdir(mode=0o700, parents=True)
        try:
            with self.guard():
                if self._table_exists():
                    raise HostSshError("Refusing to overwrite a foreign native table.")
                self._install_kernel()
                if not self._observe([], port):
                    raise HostSshError("Newly created native table differs.")
                _write_json(self.saved, dict(port=port, rescue=rescues[0], sources=[]))
            if enable_boot:
                self.install_boot_service()
        except Exception:
            # A failed install never deletes an unknown existing nft table.
            raise
        return self.status()

    def install_boot_service(self):
        """Explicit, root-owned systemd service, enabled only after installation."""
        state = _read(self.saved)
        module_python = Path(sys.executable)
        if not module_python.is_file():
            raise HostSshError("Installed host Python executable is missing.")
        unit = Path("/etc/systemd/system") / _DEFAULT_UNIT
        if unit.exists() or unit.is_symlink():
            raise HostSshError("Native boot service exists; refusing overwrite.")
        payload = (
            "[Unit]\nDescription=DataRelay Foundation SSH native ACL restore\n"
            "DefaultDependencies=no\nAfter=local-fs.target\n"
            "Before=ssh.service ssh.socket\n"
            "ConditionPathExists=" + str(self.saved) + "\n"
            "[Service]\nType=oneshot\nUser=root\n"
            "ExecStart=" + str(module_python) + " -m "
            "datarelay_onprem_security.host_native_ssh boot --state-root "
            + str(self.root) + "\n"
            "RemainAfterExit=yes\n"
            "[Install]\nWantedBy=sysinit.target\n"
        )
        fd = os.open(unit, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
        with os.fdopen(fd, "w") as stream:
            stream.write(payload)
        _run(["/usr/bin/systemctl", "daemon-reload"])
        _run(["/usr/bin/systemctl", "enable", _DEFAULT_UNIT])
        return dict(bootService=_DEFAULT_UNIT, enabled=True, port=state["port"])

    def status(self):
        with self.guard():
            confirmed = _read(self.saved)
            pending = _read(self.pending) if self.pending.exists() else None
            expected = pending["target"] if pending else confirmed["sources"]
            if not self._observe(expected, confirmed["port"]):
                raise HostSshError("Kernel SSH ACL readback differs from expected policy.")
            return dict(sources=list(expected), confirmedSources=confirmed["sources"],
                        pending=pending is not None,
                        operation=pending["operation"] if pending else None,
                        expiresAt=pending["expiresAt"] if pending else None,
                        port=confirmed["port"], rescue=confirmed["rescue"], bootService=_DEFAULT_UNIT)

    def stage(self, operation: str, sources: list[str], *, seconds: int = 60):
        if not isinstance(operation, str) or not _ID.fullmatch(operation):
            raise HostSshError("Invalid owner operation.")
        if type(seconds) is not int or not (20 <= seconds <= 600):
            raise HostSshError("Rollback window must be 20–600 seconds.")
        target = _sources(sources)
        with self.guard():
            state = _read(self.saved)
            if self.pending.exists():
                raise HostSshError("Another SSH policy is awaiting confirmation.")
            if state["rescue"] not in target:
                raise HostSshError("The immutable rescue SSH CIDR cannot be removed.")
            if not self._observe(state["sources"], state["port"]):
                raise HostSshError("Host kernel diverged before SSH apply.")
            new_pending = dict(operation=operation, target=target,
                previous=state["sources"], expiresAt=time.time()+seconds)
            _write_json(self.pending, new_pending)
            unit = "drf-native-ssh-" + operation.removeprefix("op-")
            try:
                _run(["/usr/bin/systemd-run", "--unit="+unit,
                      "--on-active="+str(seconds)+"s",
                      "--timer-property=AccuracySec=100ms",
                      str(Path(sys.executable)), "-m",
                      "datarelay_onprem_security.host_native_ssh", "rollback",
                      "--state-root", str(self.root), "--operation", operation])
                active = _run(["/usr/bin/systemctl", "is-active", unit+".timer"]).strip()
                if active != "active":
                    raise HostSshError("Independent systemd rescue timer is not active.")
                self._rules(target, state["port"])
                if not self._observe(target, state["port"]):
                    raise HostSshError("Native kernel did not match requested SSH ACL.")
            except Exception:
                self._rules(state["sources"], state["port"])
                self.pending.unlink(missing_ok=True)
                raise
            return dict(operation=operation, expiresAt=new_pending["expiresAt"], sources=target)

    def confirm(self, operation: str):
        with self.guard():
            pending = _read(self.pending)
            if pending["operation"] != operation or time.time() >= pending["expiresAt"]:
                raise HostSshError("SSH confirmation is invalid or expired.")
            state = _read(self.saved)
            if not self._observe(pending["target"], state["port"]):
                raise HostSshError("SSH kernel ACL is no longer the expected policy.")
            # Journal commit precedes expiry cleanup. Pending remains until the
            # durable state and timer are reconciled, fail-safe after process death.
            _write_json(self.saved, dict(state, sources=pending["target"]))
            self.pending.unlink()
            _run(["/usr/bin/systemctl", "stop",
                  "drf-native-ssh-"+operation.removeprefix("op-")+".timer"])
            if not self._observe(pending["target"], state["port"]):
                raise HostSshError("SSH kernel policy diverged after confirmation.")
            return self.status_unlocked()

    def status_unlocked(self):
        state = _read(self.saved)
        pending = _read(self.pending) if self.pending.exists() else None
        desired = pending["target"] if pending else state["sources"]
        return dict(sources=desired, confirmedSources=state["sources"],
                    pending=bool(pending), operation=pending["operation"] if pending else None,
                    port=state["port"], rescue=state["rescue"])

    def rollback(self, operation: str | None = None):
        with self.guard():
            if not self.pending.exists():
                return self.status_unlocked()
            pending = _read(self.pending)
            if operation is not None and pending["operation"] != operation:
                return self.status_unlocked()
            state = _read(self.saved)
            self._install_kernel()
            self._rules(state["sources"], state["port"])
            if not self._observe(state["sources"], state["port"]):
                raise HostSshError("Native rescue failed kernel readback.")
            self.pending.unlink()
            return self.status_unlocked()

    def boot(self):
        """Fail closed on incomplete mutation, then restore committed allowlist."""
        with self.guard():
            state = _read(self.saved)
            self._install_kernel()
            self._rules(state["sources"], state["port"])
            if not self._observe(state["sources"], state["port"]):
                raise HostSshError("Boot-time SSH ACL restore did not match kernel.")
            self.pending.unlink(missing_ok=True)
            return self.status_unlocked()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("install", "enable-boot", "status",
                                           "stage", "confirm", "rollback", "boot"))
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--port", type=int)
    parser.add_argument("--rescue")
    parser.add_argument("--operation")
    parser.add_argument("--seconds", type=int, default=60)
    args = parser.parse_args()
    svc = NativeHostSsh(args.state_root)
    if args.action == "install":
        result = svc.install(port=args.port, rescue=args.rescue)
    elif args.action == "enable-boot":
        result = svc.install_boot_service()
    elif args.action == "status":
        result = svc.status()
    elif args.action == "stage":
        request = json.load(sys.stdin)
        if not isinstance(request, dict):
            raise HostSshError("JSON object required.")
        result = svc.stage(args.operation, request["sshCidrs"], seconds=args.seconds)
    elif args.action == "confirm":
        result = svc.confirm(args.operation)
    elif args.action == "rollback":
        result = svc.rollback(args.operation)
    else:
        result = svc.boot()
    print(json.dumps(result, separators=(",", ":"), sort_keys=True))


if __name__ == "__main__":
    main()
