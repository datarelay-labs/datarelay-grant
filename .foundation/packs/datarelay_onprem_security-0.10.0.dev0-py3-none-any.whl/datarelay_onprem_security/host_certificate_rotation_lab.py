"""Bounded lab-only, operator-provisioned TLS leaf certificate rotation.

Never exposes private keys to HTTP/Web, never creates a CA, and refuses the
initial host network namespace. A detached worker restores the previous
verified leaf/key if its owner crashes before explicit confirmation.
This is NOT a production certificate issuer or renewal service.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import socket
import ssl
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .host_native_ingress import NativeIngressError, NativeNginxIngress, _guard_file, _json, _write
from .host_ssh_nft import IsolatedNftError, _namespace

_CERT_OP = re.compile(r"cert-[0-9a-f]{20}\Z")


class CertificateRotationLab:
    """Only explicit, private, rootless Linux user+netns laboratory effects."""

    def __init__(self, ingress: NativeNginxIngress):
        if not isinstance(ingress, NativeNginxIngress) or not ingress.lab:
            raise NativeIngressError("Certificate rotation is only qualified in an isolated lab.")
        try:
            _namespace()
        except IsolatedNftError as exc:
            raise NativeIngressError("A kernel-owned rootless network namespace is required.") from exc
        self.driver = ingress
        self.root = ingress.root
        self.cert = self.root / "server.pem"
        self.key = self.root / "server.key"
        self.ca = self.root / "ca.pem"
        self.previous_cert = self.root / "cert-previous.pem"
        self.previous_key = self.root / "cert-previous.key"
        self.confirmed = self.root / "cert-confirmed.json"
        self.pending = self.root / "cert-pending.json"
        self.workers: dict[int, subprocess.Popen] = {}

    def _live_fingerprint(self) -> str:
        active = _json(self.driver.confirmed)
        context = ssl.create_default_context(cafile=str(self.ca))
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        try:
            with socket.create_connection(("127.0.0.1", active["https_port"]), timeout=0.7) as raw:
                with context.wrap_socket(raw, server_hostname="127.0.0.1") as tls:
                    certificate = tls.getpeercert(binary_form=True)
                    if not certificate:
                        raise NativeIngressError("TLS peer certificate is unavailable.")
                    return hashlib.sha256(certificate).hexdigest()
        except (OSError, ssl.SSLError) as exc:
            raise NativeIngressError("Pinned-CA live TLS identity could not be observed.") from exc

    def _candidate(self, cert_path: Path, key_path: Path) -> str:
        """Verify issuer, signed SAN identity, lifetime and private-key match."""
        _guard_file(cert_path)
        _guard_file(key_path, private=True)
        _guard_file(self.ca)
        if (not 128 <= cert_path.stat().st_size <= 131072
                or not 128 <= key_path.stat().st_size <= 16384
                or not 128 <= self.ca.stat().st_size <= 131072):
            raise NativeIngressError("TLS certificate, key or CA exceeds private bounded input limits.")
        try:
            import ipaddress
            from cryptography import x509
            from cryptography.hazmat.primitives import hashes
            root = x509.load_pem_x509_certificate(self.ca.read_bytes())
            leaf = x509.load_pem_x509_certificate(cert_path.read_bytes())
            now = datetime.now(timezone.utc)
            if (root.not_valid_before_utc > now or root.not_valid_after_utc <= now
                    or leaf.not_valid_before_utc > now
                    or leaf.not_valid_after_utc <= now + timedelta(minutes=15)
                    or leaf.not_valid_after_utc > root.not_valid_after_utc):
                raise NativeIngressError("Candidate or issuer certificate is outside trusted validity bounds.")
            constraints = root.extensions.get_extension_for_class(x509.BasicConstraints).value
            if not constraints.ca:
                raise NativeIngressError("Pinned issuer is not a certificate authority.")
            names = leaf.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            if ipaddress.ip_address("127.0.0.1") not in names.get_values_for_type(x509.IPAddress):
                raise NativeIngressError("A verified loopback IP SAN is mandatory.")
            leaf.verify_directly_issued_by(root)
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(str(cert_path), str(key_path))
            return leaf.fingerprint(hashes.SHA256()).hex()
        except NativeIngressError:
            raise
        except Exception as exc:
            raise NativeIngressError("Candidate certificate, private key or pinned issuer is invalid.") from exc

    def _current(self) -> str:
        active = self._candidate(self.cert, self.key)
        # A graceful Nginx reload may leave a previous worker briefly serving
        # the prior certificate; bound its convergence before declaring drift.
        self._observed(active)
        if self.confirmed.exists():
            confirmed = _json(self.confirmed)
            pending = _json(self.pending) if self.pending.exists() else None
            if pending and pending.get("phase") == "staged":
                if (active != pending.get("target")
                        or confirmed != {"fingerprint": pending.get("previous")}):
                    raise NativeIngressError("Staged TLS identity conflicts with its durable previous state.")
            elif confirmed != {"fingerprint": active}:
                raise NativeIngressError("Live TLS identity differs from the durable confirmed record.")
        else:
            if self.pending.exists():
                raise NativeIngressError("Missing confirmed certificate under active recovery.")
            _write(self.confirmed, json.dumps({"fingerprint": active}))
        return active

    def _check_operation(self, operation: str):
        if not isinstance(operation, str) or not _CERT_OP.fullmatch(operation):
            raise NativeIngressError("Invalid bounded certificate operation ID.")

    def _observed(self, fingerprint: str):
        for _ in range(8):
            try:
                if self._live_fingerprint() == fingerprint:
                    return
            except NativeIngressError:
                pass
            time.sleep(0.14)
        raise NativeIngressError("Live pinned TLS leaf fingerprint was not independently verified.")

    def stage(self, operation: str, candidate_cert: str | Path,
              candidate_key: str | Path, *, seconds: int = 12):
        self._check_operation(operation)
        if type(seconds) is not int or not 10 <= seconds <= 120:
            raise NativeIngressError("Certificate recovery must be armed for 10–120 seconds.")
        certificate, key = Path(candidate_cert), Path(candidate_key)
        with self.driver.guard():
            if self.driver.pending.exists() or self.pending.exists():
                raise NativeIngressError("A privileged ingress/certificate operation already owns recovery.")
            previous = self._current()
            new = self._candidate(certificate, key)
            if previous == new:
                raise NativeIngressError("Certificate is identical to the confirmed live identity.")
            _write(self.previous_cert, self.cert.read_text())
            _write(self.previous_key, self.key.read_text())
            state = dict(operation=operation, previous=previous, target=new,
                         expires_at=time.time()+seconds, phase="staged", watchdog=None)
            _write(self.pending, json.dumps(state))
            try:
                child = subprocess.Popen([
                    sys.executable, "-m", "datarelay_onprem_security.host_certificate_rotation_lab",
                    "watchdog", "--root", str(self.root), "--operation", operation,
                    "--delay", str(seconds),
                ], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL, start_new_session=True, close_fds=True)
                if child.poll() is not None:
                    raise NativeIngressError("Independent certificate recovery worker was not started.")
                self.workers[child.pid] = child
                state["watchdog"] = child.pid
                _write(self.pending, json.dumps(state))
                _write(self.cert, certificate.read_text())
                _write(self.key, key.read_text())
                self.driver._nginx("-t")
                self.driver._nginx("-s", "reload")
                self._observed(new)
            except Exception:
                # A failed or interrupted change retains durable recovery state.
                raise
            return dict(operation=operation, pending=True, fingerprint=new)

    def confirm(self, operation: str):
        self._check_operation(operation)
        with self.driver.guard():
            pending = _json(self.pending)
            if (pending["operation"] != operation or pending["phase"] != "staged"
                    or time.time() >= pending["expires_at"]):
                raise NativeIngressError("Certificate confirmation is expired or not owned.")
            self._observed(pending["target"])
            _write(self.confirmed, json.dumps({"fingerprint": pending["target"]}))
            pending["phase"] = "committed"
            _write(self.pending, json.dumps(pending))
            self.previous_cert.unlink()
            self.previous_key.unlink()
            self.pending.unlink()
            pid = pending.get("watchdog")
            if type(pid) is int and pid in self.workers:
                child = self.workers.pop(pid)
                child.terminate()
                child.wait(timeout=2)
            return dict(confirmed=True, fingerprint=pending["target"], pending=False)

    def rollback(self, operation: str):
        self._check_operation(operation)
        with self.driver.guard():
            if not self.pending.exists():
                value = self._current()
                return dict(recovered=True, fingerprint=value, pending=False)
            pending = _json(self.pending)
            if pending["operation"] != operation:
                raise NativeIngressError("Foreign certificate operation must not be rolled back.")
            if pending["phase"] == "committed":
                self._observed(pending["target"])
                _write(self.confirmed, json.dumps({"fingerprint": pending["target"]}))
                self.previous_cert.unlink(missing_ok=True)
                self.previous_key.unlink(missing_ok=True)
                self.pending.unlink()
                return dict(recovered=True, committed=True, fingerprint=pending["target"])
            _guard_file(self.previous_cert)
            _guard_file(self.previous_key, private=True)
            _write(self.cert, self.previous_cert.read_text())
            _write(self.key, self.previous_key.read_text())
            self.driver._nginx("-t")
            self.driver._nginx("-s", "reload")
            self._observed(pending["previous"])
            _write(self.confirmed, json.dumps({"fingerprint": pending["previous"]}))
            self.previous_cert.unlink()
            self.previous_key.unlink()
            self.pending.unlink()
            return dict(recovered=True, committed=False, fingerprint=pending["previous"])

    def status(self):
        # Reap a finished independent worker after its own recovery has run.
        if not self.pending.exists():
            for pid, child in list(self.workers.items()):
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired as exc:
                    raise NativeIngressError("Independent certificate watchdog did not terminate.") from exc
                self.workers.pop(pid, None)
        with self.driver.guard():
            fact = self._current()
            pending = _json(self.pending) if self.pending.exists() else None
            return dict(fingerprint=fact, pending=bool(pending),
                        operation=pending["operation"] if pending else None)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("watchdog", "rotate-lab", "status-lab"))
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--operation")
    parser.add_argument("--delay", type=int, default=0)
    parser.add_argument("--certificate", type=Path)
    parser.add_argument("--key", type=Path)
    args = parser.parse_args()
    if args.action == "watchdog":
        if (not args.operation or args.certificate or args.key
                or not 10 <= args.delay <= 120):
            parser.error("A timed watchdog permits an operation reference and bounded delay only.")
    elif args.action == "rotate-lab":
        if (args.operation is not None or args.delay != 0
                or not args.certificate or not args.key):
            parser.error("Lab certificate rotation requires a preprovisioned leaf/key only.")
    elif args.operation is not None or args.delay or args.certificate or args.key:
        parser.error("Lab certificate status has no mutation inputs.")
    driver = NativeNginxIngress(args.root, isolated_lab=True)
    rotation = CertificateRotationLab(driver)
    if args.action == "watchdog":
        time.sleep(args.delay)
        result = rotation.rollback(args.operation)
    elif args.action == "rotate-lab":
        import secrets
        reference = "cert-" + secrets.token_hex(10)
        rotation.stage(reference, args.certificate, args.key, seconds=20)
        result = rotation.confirm(reference)
    else:
        result = rotation.status()
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
