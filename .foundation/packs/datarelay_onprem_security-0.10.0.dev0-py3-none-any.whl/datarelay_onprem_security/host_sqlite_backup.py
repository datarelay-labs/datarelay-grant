"""Encrypted, offline-verifiable SQLite backup and isolated restore-drill host driver.

A real physical file effect scoped to an explicitly private installation root.
No product database is replaced: restore always targets an absent, isolated path.
No live host restore, scheduler, or key distribution is implied by this module.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import argparse
import fcntl
import sys
from contextlib import contextmanager
from dataclasses import asdict
import json
import os
import re
import secrets
import sqlite3
import tempfile
import time
from pathlib import Path

from .backup_recovery import BackupEvidence, BackupKind, BackupState

_NAME = re.compile(r"[a-z][a-z0-9-]{4,63}\Z", re.ASCII)
_MAGIC = b"DRF-SQLITE-AES256-GCM-V1\n"
_BUFFER = 1024 * 1024


class NativeBackupError(RuntimeError):
    """No verified host snapshot was available; never assume recovery."""


@dataclass(frozen=True)
class BackupSnapshot:
    reference: str
    created_at: int
    size: int
    sha256: str
    sqlite_sha256: str
    encrypted: bool = True


@dataclass(frozen=True)
class BackupPrunePreview:
    """Confirmed, revision-pinned cleanup restricted to backup artifacts."""
    revision: str
    keep_last: int
    remove: tuple[str, ...]
    retain: tuple[str, ...]


def _private(path: Path, *, directory: bool = False) -> None:
    if path.is_symlink() or not path.exists():
        raise NativeBackupError("Native backup path does not exist or is a symbolic link.")
    stat = path.stat()
    if bool(stat.st_mode & 0o077) or not (path.is_dir() if directory else path.is_file()):
        raise NativeBackupError("Native backup files and directories require owner-only permissions.")


def _write_atomic(path: Path, payload: bytes) -> None:
    candidate = path.with_name("." + path.name + "." + secrets.token_hex(8))
    descriptor = os.open(candidate, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as file:
            file.write(payload)
            file.flush()
            os.fsync(file.fileno())
        if path.exists() or path.is_symlink():
            raise NativeBackupError("Immutable backup reference already exists.")
        os.replace(candidate, path)
        descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        candidate.unlink(missing_ok=True)


def _digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(_BUFFER), b""):
            sha.update(chunk)
    return sha.hexdigest()


def _cipher():
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.exceptions import InvalidTag
    except ImportError as exc:
        raise NativeBackupError(
            "AES-GCM host backup dependency is not installed; no plaintext fallback."
        ) from exc
    return Cipher, algorithms, modes, InvalidTag


class EncryptedSQLiteBackup:
    """Private root + application database + externally provisioned AES-256 key.

    The root and backup keys are supplied by an operator and must have 0700/0600
    permissions. The source database and key must be distinct direct children
    of that root (no path traversal or caller-selected archive destinations).
    The key is not included in any archive, receipt, JSON or service response.
    """

    def __init__(self, root: str | Path, *, database: str = "security.sqlite",
                 key_file: str = "backup.key"):
        self.root = Path(root)
        if not self.root.is_absolute() or self.root.is_symlink():
            raise NativeBackupError("An absolute, non-symlink private root is required.")
        _private(self.root, directory=True)
        for name in (database, key_file):
            if name in (".", "..") or "/" in name or "\\" in name or not name or name.startswith("."):
                raise NativeBackupError("Only direct private filenames are permitted.")
        if database == key_file:
            raise NativeBackupError("Database and encryption key must be distinct.")
        self.source = self.root / database
        self.key_file = self.root / key_file
        self.backups = self.root / "backups"
        _private(self.source)
        _private(self.key_file)
        if self.backups.exists() or self.backups.is_symlink():
            _private(self.backups, directory=True)
        else:
            self.backups.mkdir(mode=0o700)
            _private(self.backups, directory=True)

    def _key(self) -> bytes:
        _private(self.key_file)
        key = self.key_file.read_bytes()
        if len(key) != 32:
            raise NativeBackupError("Backup encryption key must be exactly 32 secret bytes.")
        return key

    def _files(self, reference: str) -> tuple[Path, Path]:
        if not isinstance(reference, str) or not _NAME.fullmatch(reference):
            raise ValueError("Invalid immutable backup reference.")
        return self.backups / (reference + ".drbackup"), self.backups / (reference + ".json")

    @staticmethod
    def _check_sqlite(path: Path) -> None:
        if path.is_symlink():
            raise NativeBackupError("Symlinked SQLite database forbidden.")
        try:
            connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
            try:
                result = connection.execute("PRAGMA quick_check").fetchone()[0]
                if result != "ok":
                    raise NativeBackupError("SQLite snapshot integrity failed.")
                connection.execute("SELECT COUNT(*) FROM sqlite_master").fetchone()
            finally:
                connection.close()
        except sqlite3.DatabaseError as exc:
            raise NativeBackupError("SQLite native snapshot is corrupt.") from exc

    def _encrypt(self, plain: Path, target: Path, reference: str) -> None:
        Cipher, algorithms, modes, _ = _cipher()
        nonce = secrets.token_bytes(12)
        encryptor = Cipher(algorithms.AES(self._key()), modes.GCM(nonce)).encryptor()
        encryptor.authenticate_additional_data(_MAGIC + reference.encode("ascii"))
        with target.open("xb") as encoded, plain.open("rb") as origin:
            os.chmod(target, 0o600)
            encoded.write(_MAGIC + nonce)
            for chunk in iter(lambda: origin.read(_BUFFER), b""):
                encoded.write(encryptor.update(chunk))
            encoded.write(encryptor.finalize())
            encoded.write(encryptor.tag)
            encoded.flush()
            os.fsync(encoded.fileno())

    @contextmanager
    def _exclusive(self):
        # The immutable-publish and confirmed retention paths share a durable
        # OS file lock. A second process cannot change inventory between
        # plan readback and a confirmed cleanup.
        lock = self.backups / ".native-backup.lock"
        fd = os.open(lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            if os.fstat(fd).st_mode & 0o077:
                raise NativeBackupError("Backup lock permissions are unsafe.")
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def create(self, reference: str) -> BackupSnapshot:
        with self._exclusive():
            return self._create_locked(reference)

    def _create_locked(self, reference: str) -> BackupSnapshot:
        self._key()  # fail before any disk effect when encryption is unconfigured
        _private(self.source)
        self._check_sqlite(self.source)
        archive, manifest = self._files(reference)
        if archive.exists() or manifest.exists() or archive.is_symlink() or manifest.is_symlink():
            raise NativeBackupError("Backup references are immutable; choose a new reference.")
        with tempfile.TemporaryDirectory(dir=self.backups, prefix=".snapshot-") as directory:
            scratch = Path(directory) / "snapshot.sqlite"
            fd = os.open(scratch, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            os.close(fd)
            source_conn = sqlite3.connect(self.source.as_uri() + "?mode=ro", uri=True)
            target_conn = sqlite3.connect(scratch)
            try:
                source_conn.backup(target_conn)
            finally:
                target_conn.close()
                source_conn.close()
            self._check_sqlite(scratch)
            plain_sha = _digest(scratch)
            pending = Path(directory) / "artifact.drbackup"
            self._encrypt(scratch, pending, reference)
            snapshot = BackupSnapshot(
                reference, int(time.time()), pending.stat().st_size,
                _digest(pending), plain_sha,
            )
            # Hard link on the same filesystem atomically publishes the
            # encrypted stream without reading unbounded backup bytes to RAM,
            # and refuses any prior artifact rather than overwriting it.
            try:
                os.link(pending, archive, follow_symlinks=False)
            except FileExistsError as exc:
                raise NativeBackupError("Immutable backup was concurrently created.") from exc
            directory_fd = os.open(self.backups, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
            _write_atomic(manifest, json.dumps(snapshot.__dict__,
                sort_keys=True, separators=(",", ":")).encode("ascii"))
        return self.verify(reference)

    def _metadata(self, reference: str) -> BackupSnapshot:
        archive, manifest = self._files(reference)
        _private(archive)
        _private(manifest)
        try:
            fields = json.loads(manifest.read_text("ascii"))
            receipt = BackupSnapshot(**fields)
            if receipt.reference != reference or receipt.encrypted is not True:
                raise ValueError("Bad backup identity")
            if archive.stat().st_size != receipt.size or _digest(archive) != receipt.sha256:
                raise ValueError("Modified archive")
            return receipt
        except (TypeError, ValueError, KeyError, json.JSONDecodeError) as exc:
            raise NativeBackupError("Native encrypted backup manifest is unverified.") from exc

    def _restore(self, reference: str, target: Path) -> BackupSnapshot:
        Cipher, algorithms, modes, InvalidTag = _cipher()
        receipt = self._metadata(reference)
        archive, _ = self._files(reference)
        if target.exists() or target.is_symlink() or not target.parent.is_dir() or target.parent.is_symlink():
            raise NativeBackupError("Restore may target a new isolated file only.")
        _private(target.parent, directory=True)
        header_size = len(_MAGIC) + 12
        if receipt.size < header_size + 16:
            raise NativeBackupError("Truncated encrypted SQLite archive.")
        with archive.open("rb") as sealed:
            if sealed.read(len(_MAGIC)) != _MAGIC:
                raise NativeBackupError("Encrypted SQLite archive format mismatch.")
            nonce = sealed.read(12)
            sealed.seek(-16, 2)
            tag = sealed.read(16)
            sealed.seek(header_size)
            decryptor = Cipher(algorithms.AES(self._key()), modes.GCM(nonce, tag)).decryptor()
            decryptor.authenticate_additional_data(_MAGIC + reference.encode("ascii"))
            try:
                with target.open("xb") as extracted:
                    os.chmod(target, 0o600)
                    remaining = receipt.size - header_size - 16
                    while remaining:
                        chunk = sealed.read(min(_BUFFER, remaining))
                        if not chunk:
                            raise NativeBackupError("Truncated encrypted backup.")
                        extracted.write(decryptor.update(chunk))
                        remaining -= len(chunk)
                    extracted.write(decryptor.finalize())
                    extracted.flush()
                    os.fsync(extracted.fileno())
                if _digest(target) != receipt.sqlite_sha256:
                    raise NativeBackupError("Decrypted SQLite hash mismatch.")
                self._check_sqlite(target)
                return receipt
            except (InvalidTag, NativeBackupError):
                target.unlink(missing_ok=True)
                raise NativeBackupError("Encrypted SQLite restore authenticity failed.") from None
            except BaseException:
                target.unlink(missing_ok=True)
                raise

    def verify(self, reference: str) -> BackupSnapshot:
        with tempfile.TemporaryDirectory(dir=self.backups, prefix=".verify-") as directory:
            return self._restore(reference, Path(directory) / "verify.sqlite")

    def restore_drill(self, reference: str, isolated_dir: str | Path) -> BackupSnapshot:
        """Restore to an *absent* dedicated child under the private root.

        Never replaces the live database. Application owner must separately
        qualify durable offline restore, rollback and post-restart E2E.
        """
        isolated = Path(isolated_dir)
        if not isolated.is_absolute() or isolated.parent != self.root or isolated.name in (
            "backups", self.source.name, self.key_file.name
        ) or isolated.exists() or isolated.is_symlink():
            raise NativeBackupError("Restore drill target must be a fresh private root child.")
        isolated.mkdir(mode=0o700)
        target = isolated / "restored.sqlite"
        try:
            return self._restore(reference, target)
        except BaseException:
            target.unlink(missing_ok=True)
            isolated.rmdir()
            raise

    def preview_retention(self, keep_last: int) -> BackupPrunePreview:
        """Inspect real archive+hash readback; never infer from directory names."""
        if type(keep_last) is not int or not 1 <= keep_last <= 365:
            raise ValueError("Retention must preserve 1–365 latest encrypted backups.")
        _private(self.backups, directory=True)
        found = []
        for candidate in self.backups.glob("*.json"):
            reference = candidate.stem
            receipt = self._metadata(reference)
            found.append(receipt)
        found.sort(key=lambda item: (item.created_at, item.reference), reverse=True)
        fingerprint = json.dumps(
            [(r.reference, r.created_at, r.sha256) for r in found],
            separators=(",", ":"),
        ).encode()
        return BackupPrunePreview(
            revision=hashlib.sha256(fingerprint).hexdigest(),
            keep_last=keep_last,
            remove=tuple(r.reference for r in found[keep_last:]),
            retain=tuple(r.reference for r in found[:keep_last]),
        )

    def apply_retention(self, plan: BackupPrunePreview, *, confirmed: bool = False) -> int:
        with self._exclusive():
            return self._apply_retention_locked(plan, confirmed=confirmed)

    def _apply_retention_locked(self, plan: BackupPrunePreview, *, confirmed: bool = False) -> int:
        """Delete only previously reviewed encrypted backup pairs under root.

        Explicit confirmation and unchanged listing/sha256 are both required.
        This is NOT an automatic host scheduler or deletion of live data.
        """
        if not isinstance(plan, BackupPrunePreview) or confirmed is not True:
            raise NativeBackupError("Explicit exact retention preview confirmation required.")
        if self.preview_retention(plan.keep_last) != plan:
            raise NativeBackupError("Backup archive inventory changed since preview.")
        for reference in plan.remove:
            archive, manifest = self._files(reference)
            self._metadata(reference)
            # The source DB, encryption key and latest kept backups are
            # provably outside these generated, reviewed artifact paths.
            archive.unlink()
            manifest.unlink()
        fd = os.open(self.backups, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        return len(plan.remove)

    def backup_evidence(self, reference: str, *, product: str, revision: str) -> BackupEvidence:
        snapshot = self.verify(reference)
        return BackupEvidence(
            product_ref=product, backup_ref=reference, revision_ref=revision,
            kind=BackupKind.DISASTER_RECOVERY, state=BackupState.SUCCEEDED,
            created_at=snapshot.created_at, artifact_bytes=snapshot.size,
            archive_sha256=snapshot.sha256, encrypted_at_rest=True,
            restore_drill_verified_at=None,
        )


def main() -> None:
    """Operator-only CLI; no daemon/scheduled privileged effects are installed."""
    parser = argparse.ArgumentParser(description="Private native encrypted SQLite backup")
    parser.add_argument("operation", choices=(
        "backup", "verify", "restore-drill", "retention-plan", "retention-apply",
    ))
    parser.add_argument("--root", required=True, help="Private application root (0700)")
    parser.add_argument("--database", default="security.sqlite")
    parser.add_argument("--key-file", default="backup.key")
    parser.add_argument("--reference")
    parser.add_argument("--isolated-target")
    parser.add_argument("--keep-last", type=int)
    parser.add_argument("--confirm-revision")
    args = parser.parse_args()
    try:
        driver = EncryptedSQLiteBackup(
            args.root, database=args.database, key_file=args.key_file
        )
        if args.operation in ("backup", "verify", "restore-drill"):
            if not args.reference:
                parser.error("--reference is required")
            if args.operation == "backup":
                result = asdict(driver.create(args.reference))
            elif args.operation == "verify":
                result = asdict(driver.verify(args.reference))
            else:
                if not args.isolated_target:
                    parser.error("--isolated-target is required")
                result = asdict(driver.restore_drill(args.reference, args.isolated_target))
        else:
            if args.keep_last is None:
                parser.error("--keep-last is required")
            preview = driver.preview_retention(args.keep_last)
            if args.operation == "retention-plan":
                result = asdict(preview)
            else:
                if args.confirm_revision != preview.revision:
                    raise NativeBackupError("Re-run retention-plan and confirm its exact revision.")
                count = driver.apply_retention(preview, confirmed=True)
                result = {"deleted_encrypted_snapshots": count, "verified": True}
        print(json.dumps(result, sort_keys=True))
    except (NativeBackupError, ValueError) as exc:
        parser.exit(2, "NATIVE_BACKUP=REFUSED: " + str(exc) + "\n")


if __name__ == "__main__":
    main()
