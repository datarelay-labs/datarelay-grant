"""Fixed privileged ingress gateway: no generic shell or installer controls."""
from __future__ import annotations

import argparse
import json
import sys

from .host_native_ingress import NativeIngressError, NativeNginxIngress

FIXED_STATE_ROOT = "/var/lib/datarelay-foundation/native-ingress"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("status", "stage", "confirm", "rollback"))
    parser.add_argument("--operation")
    args = parser.parse_args()
    if args.action != "status" and not args.operation:
        parser.error("Exact scoped operation required.")
    service = NativeNginxIngress(FIXED_STATE_ROOT)
    if args.action == "status":
        output = service.status()
    elif args.action == "stage":
        payload = sys.stdin.buffer.read(2049)
        if len(payload) > 2048:
            raise NativeIngressError("Ingress request exceeds 2 KiB.")
        value = json.loads(payload)
        if not isinstance(value, dict) or set(value) != {"http_port", "https_port", "redirect"}:
            raise NativeIngressError("Only fixed network ingress settings are permitted.")
        output = service.stage(args.operation, value)
    elif args.action == "confirm":
        output = service.confirm(args.operation)
    else:
        output = service.rollback(args.operation)
    print(json.dumps(output, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
