"""Opt-in, loopback-only HTTPS entrypoint for the standalone Foundation ASGI app.

This runs real TLS with an operator-provisioned certificate and private key.
It does NOT edit systemd, Nginx, host network interfaces, firewall or trust.
The service runs in the foreground and uses the existing Web ACL on all routes.
"""
from __future__ import annotations

import argparse
import ipaddress
import os
import socket
import ssl
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse


class HostTlsUnavailable(RuntimeError):
    """Refuse to start an unverified or unsafe HTTPS listener."""


def _path(path: str | Path, *, private: bool = False) -> Path:
    value = Path(path)
    if not value.is_absolute() or value.is_symlink() or not value.is_file():
        raise HostTlsUnavailable("TLS files must be existing regular absolute paths.")
    if private and value.stat().st_mode & 0o077:
        raise HostTlsUnavailable("TLS key must be private (0600).")
    if not value.stat().st_size:
        raise HostTlsUnavailable("Empty TLS identity.")
    return value


def _loopback(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def tls_preflight(*, cert: str | Path, key: str | Path,
                  host: str, port: int, origin: str) -> dict[str, str | int]:
    """Inspect actual certificate SAN/validity/key and intended listener."""
    if not isinstance(host, str) or not _loopback(host):
        raise HostTlsUnavailable("Only verified loopback TLS is supported by this host profile.")
    if type(port) is not int or not 1024 <= port <= 65535:
        raise HostTlsUnavailable("Use an unprivileged explicit HTTPS port.")
    parsed = urlparse(origin)
    if (parsed.scheme != "https" or parsed.hostname != host or parsed.port != port
            or parsed.path not in ("", "/") or parsed.username or parsed.password
            or parsed.query or parsed.fragment):
        raise HostTlsUnavailable("HTTPS origin must exactly match bound host and port.")
    if os.environ.get("DATARELAY_FOUNDATION_LOCAL_HTTP") == "1":
        raise HostTlsUnavailable("Loopback development HTTP mode is forbidden for TLS.")
    certificate = _path(cert)
    private_key = _path(key, private=True)
    try:
        from cryptography import x509
        from cryptography.x509.oid import ExtensionOID
        content = x509.load_pem_x509_certificate(certificate.read_bytes())
        now = datetime.now(timezone.utc)
        # Avoid eagerly accessing deprecated naïve-date properties when the
        # pinned cryptography runtime supplies aware UTC datetimes.
        if hasattr(content, "not_valid_before_utc"):
            starts, ends = content.not_valid_before_utc, content.not_valid_after_utc
        else:
            starts = content.not_valid_before.replace(tzinfo=timezone.utc)
            ends = content.not_valid_after.replace(tzinfo=timezone.utc)
        if not (starts <= now < ends):
            raise HostTlsUnavailable("TLS certificate has expired or is not yet valid.")
        san = content.extensions.get_extension_for_oid(
            ExtensionOID.SUBJECT_ALTERNATIVE_NAME
        ).value
        if host == "localhost":
            names = san.get_values_for_type(x509.DNSName)
            if host not in names:
                raise HostTlsUnavailable("TLS SAN does not match the listener hostname.")
        else:
            addresses = san.get_values_for_type(x509.IPAddress)
            if ipaddress.ip_address(host) not in addresses:
                raise HostTlsUnavailable("TLS SAN does not contain listener IP.")
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(str(certificate), str(private_key))
    except HostTlsUnavailable:
        raise
    except Exception as exc:
        raise HostTlsUnavailable("TLS certificate/key chain verification failed.") from exc
    return {
        "host": host, "port": port, "origin": origin, "cert_sha256":
        __import__("hashlib").sha256(certificate.read_bytes()).hexdigest(),
        "minimum_tls": "TLSv1.2",
    }


def serve(*, cert: str | Path, key: str | Path, host: str, port: int) -> None:
    origin = os.environ.get("DATARELAY_FOUNDATION_ORIGIN", "")
    tls_preflight(cert=cert, key=key, host=host, port=port, origin=origin)
    if not os.environ.get("DATARELAY_FOUNDATION_DB") or not os.environ.get(
        "DATARELAY_FOUNDATION_STATIC_DIST"
    ):
        raise HostTlsUnavailable("Private SQLite database and compiled UI are required.")
    try:
        import uvicorn
    except ImportError as exc:
        raise HostTlsUnavailable("Install pinned host-transport extra for HTTPS.") from exc
    # Native HTTPS is supplied by Uvicorn's standard SSL stack. Never follow
    # untrusted proxy headers; only EmbeddedControlWebApp's explicit trusted
    # proxy chain can change authoritative client-source IP.
    uvicorn.run(
        "datarelay_onprem_security.embedded_runtime:app_from_environment",
        factory=True, host=host, port=port, ssl_certfile=str(cert),
        ssl_keyfile=str(key), proxy_headers=False, access_log=False,
        workers=1,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Private loopback Foundation HTTPS ingress")
    parser.add_argument("mode", choices=("check", "serve"))
    parser.add_argument("--cert", required=True)
    parser.add_argument("--key", required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", required=True, type=int)
    args = parser.parse_args()
    if args.mode == "check":
        import json
        print(json.dumps(tls_preflight(
            cert=args.cert, key=args.key, host=args.host, port=args.port,
            origin=os.environ.get("DATARELAY_FOUNDATION_ORIGIN", ""),
        )))
    else:
        serve(cert=args.cert, key=args.key, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
