"""Isolated-network-namespace nftables SSH ACL with external rollback worker.

This is an F-31 *LAB* host-effect driver. Every entry point refuses the initial
host network namespace, regardless of user privileges. No production installer
or embedded runtime endpoint exposes these operations. Rootless user+network
namespaces provide real kernel packet enforcement without touching host SSH.
"""
from __future__ import annotations

import fcntl
import ipaddress
import json
import os
import re
import secrets
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .acl import canonical_network

_TABLE = re.compile(r"drf_lab_[a-z0-9]{6,20}\Z")
_OPERATION = re.compile(r"[a-z][a-z0-9_-]{5,80}\Z")


class IsolatedNftError(RuntimeError):
    """Kernel enforcement, current ownership or rollback proof is unavailable."""


# Linux nsfs.h: NS_GET_USERNS = _IO(NSIO, 0x1), NSIO = 0xb7.
_NS_GET_USERNS = 0xB701


def _namespace() -> str:
    """Require a newly owned user AND network namespace, not just mapped UID.

    A rootless UID mapping alone can exist while the process still references
    the original HOST network namespace. On Linux, NS_GET_USERNS on the
    network namespace FD reports its owning user namespace. Require that
    owner to be the CURRENT rootless user namespace. EPERM/ENOTTY/missing
    procfs provenance are all fail-closed. No production authority follows.
    """
    try:
        current = os.readlink("/proc/self/ns/net")
        rows = Path("/proc/self/uid_map").read_text().strip().splitlines()
        mapping = [int(x) for x in rows[0].split()] if len(rows) == 1 else []
    except (OSError, ValueError, IndexError) as exc:
        raise IsolatedNftError("Cannot prove a rootless isolated namespace.") from exc
    if len(mapping) != 3 or mapping[0] != 0 or mapping[1] <= 0 or mapping[2] != 1:
        raise IsolatedNftError("Refusing host/root user namespace.")

    try:
        network_fd = os.open("/proc/self/ns/net", os.O_RDONLY | os.O_CLOEXEC)
        try:
            owning_user_fd = fcntl.ioctl(network_fd, _NS_GET_USERNS)
            try:
                owner_stat = os.fstat(owning_user_fd)
                current_user_stat = os.stat("/proc/self/ns/user")
            finally:
                os.close(owning_user_fd)
        finally:
            os.close(network_fd)
    except (OSError, ValueError) as exc:
        raise IsolatedNftError(
            "Cannot prove the network namespace belongs to the rootless user namespace."
        ) from exc
    if (owner_stat.st_dev, owner_stat.st_ino) != (
        current_user_stat.st_dev, current_user_stat.st_ino
    ):
        raise IsolatedNftError(
            "Refusing network namespace not owned by the current rootless user namespace."
        )
    return current


def _sources(values: tuple[str, ...]) -> tuple[str, ...]:
    if not isinstance(values, tuple) or not 1 <= len(values) <= 64:
        raise ValueError("An SSH allowlist must contain 1-64 CIDRs.")
    result = []
    for value in values:
        if not isinstance(value, str):
            raise ValueError("CIDRs must be strings.")
        network = canonical_network(value)
        if network in result:
            raise ValueError("Duplicate management source.")
        result.append(network)
    return tuple(result)


def _write_json(path: Path, value: dict) -> None:
    temp = path.with_name("." + path.name + "." + secrets.token_hex(8))
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(value, file, separators=(",", ":"), sort_keys=True)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temp, path)
        dir_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        temp.unlink(missing_ok=True)


def _read_json(path: Path) -> dict:
    if path.is_symlink() or not path.is_file() or path.stat().st_mode & 0o077:
        raise IsolatedNftError("Private native ACL journal is missing or insecure.")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise IsolatedNftError("Invalid native ACL journal.")
    return data


class IsolatedNftSshAcl:
    """Real nftables effect, but ONLY inside a distinct unshared network namespace.

    Ownership is limited to a new randomly named inet table/ssh_input chain;
    no existing chain or daemon is modified. A separate process watches a
    fsync'ed rollback journal so parent-process exit cannot strand an apply.
    No claim is made for reboot-persistent, privileged production recovery.
    """

    def __init__(self, state_dir: Path | str, *, table: str, ssh_port: int):
        self.namespace = _namespace()
        if not _TABLE.fullmatch(table):
            raise ValueError("Only a dedicated drf_lab_ table is permitted.")
        if type(ssh_port) is not int or not 1024 <= ssh_port <= 65535:
            raise ValueError("Use an unprivileged lab SSH port.")
        self.table = table
        self.ssh_port = ssh_port
        self.root = Path(state_dir)
        if not self.root.is_absolute() or self.root.is_symlink() or (
            self.root.exists() and (not self.root.is_dir() or self.root.stat().st_mode & 0o077)
        ):
            raise IsolatedNftError("State directory must be private, absolute and not a symlink.")
        self.state = self.root / "state.json"
        self.pending = self.root / "pending.json"
        self.lock = self.root / "lock"

    def _assert_namespace(self) -> None:
        if _namespace() != self.namespace:
            raise IsolatedNftError("Namespace ownership has changed.")

    def _nft(self, *args: str, script: str | None = None) -> str:
        self._assert_namespace()
        command = ["nft", *args]
        completed = subprocess.run(
            command, input=script, text=True, capture_output=True, timeout=5,
            check=False,
        )
        if completed.returncode:
            raise IsolatedNftError("nftables operation or independent readback failed.")
        return completed.stdout

    @contextmanager
    def _exclusive(self) -> Iterator[None]:
        self._assert_namespace()
        if not self.root.is_dir() or self.root.is_symlink() or self.root.stat().st_mode & 0o077:
            raise IsolatedNftError("Private state directory missing or insecure.")
        descriptor = os.open(self.lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
            os.close(descriptor)

    def install(self) -> None:
        """Explicitly create only our own table; refuse collision or reinstallation."""
        self._assert_namespace()
        if self.root.exists():
            raise IsolatedNftError("Refusing to overwrite pre-existing lab state.")
        self.root.mkdir(mode=0o700)
        with self._exclusive():
            result = subprocess.run(
                ["nft", "list", "table", "inet", self.table],
                capture_output=True, timeout=5, check=False,
            )
            if result.returncode == 0:
                raise IsolatedNftError("Refusing to replace another nftables table.")
            self._nft("-f", "-", script=(
                f"add table inet {self.table}\n"
                f"add chain inet {self.table} ssh_input "
                "{ type filter hook input priority -175; policy accept; }\n"
            ))
            _write_json(self.state, {
                "table": self.table, "port": self.ssh_port,
                "namespace": self.namespace, "sources": [], "enabled": False,
            })

    def _current(self) -> dict:
        state = _read_json(self.state)
        if (state.get("table"), state.get("port"), state.get("namespace")) != (
            self.table, self.ssh_port, self.namespace
        ):
            raise IsolatedNftError("Operation ownership does not match installed table.")
        self._nft("list", "chain", "inet", self.table, "ssh_input")
        return state

    def _rules(self, sources: tuple[str, ...], enabled: bool) -> None:
        if type(enabled) is not bool:
            raise ValueError("enabled must be a native Boolean.")
        if enabled:
            sources = _sources(sources)
        elif sources:
            raise ValueError("Disabled policy cannot contain active allowlist entries.")
        lines = [f"flush chain inet {self.table} ssh_input"]
        if enabled:
            for source in sources:
                network = ipaddress.ip_network(source)
                family = "ip6" if network.version == 6 else "ip"
                lines.append(
                    f"add rule inet {self.table} ssh_input "
                    f"tcp dport {self.ssh_port} {family} saddr {source} accept"
                )
            lines.append(f"add rule inet {self.table} ssh_input tcp dport {self.ssh_port} drop")
        script = "\n".join(lines) + "\n"
        self._nft("--check", "-f", "-", script=script)
        self._nft("-f", "-", script=script)

    def _observe(self, value: dict) -> bool:
        """Compare full ordered kernel nft JSON, not approximate substrings.

        Verifying only an address string and verdict count would silently
        accept a widened CIDR prefix, wrong port or an early DROP/ACCEPT.
        Exact match of chain ownership, hook, port, family, network and
        prefix length is mandatory before any apply/confirm/rollback success.
        """
        try:
            data = json.loads(
                self._nft("-j", "list", "chain", "inet", self.table, "ssh_input")
            )
            entries = data["nftables"]
            if not isinstance(entries, list) or any(
                not isinstance(row, dict) or len(row) != 1
                or next(iter(row)) not in ("metainfo", "chain", "rule")
                for row in entries
            ):
                return False
            chains = [row["chain"] for row in entries if "chain" in row]
            rules = [row["rule"] for row in entries if "rule" in row]
            if len(chains) != 1:
                return False
            if any(chains[0].get(key) != expected for key, expected in {
                "family": "inet",
                "table": self.table,
                "name": "ssh_input",
                "type": "filter",
                "hook": "input",
                "prio": -175,
                "policy": "accept",
            }.items()):
                return False
            if not isinstance(value["enabled"], bool) or not isinstance(
                value["sources"], list
            ):
                return False
            if len(rules) != (
                len(value["sources"]) + 1 if value["enabled"] else 0
            ):
                return False

            port_match = {"match": {"op": "==", "left": {"payload": {
                "protocol": "tcp", "field": "dport"
            }}, "right": self.ssh_port}}
            expected_rules = []
            if value["enabled"]:
                for source in value["sources"]:
                    network = ipaddress.ip_network(source, strict=True)
                    right = str(network.network_address)
                    if network.prefixlen != network.max_prefixlen:
                        right = {"prefix": {
                            "addr": right, "len": network.prefixlen
                        }}
                    source_match = {"match": {"op": "==", "left": {
                        "payload": {
                            "protocol": "ip" if network.version == 4 else "ip6",
                            "field": "saddr",
                        }
                    }, "right": right}}
                    expected_rules.append([port_match, source_match, {
                        "accept": None
                    }])
                expected_rules.append([port_match, {"drop": None}])

            for actual, expected in zip(rules, expected_rules):
                if (not isinstance(actual, dict)
                        or any(actual.get(k) != v for k, v in {
                            "family": "inet",
                            "table": self.table,
                            "chain": "ssh_input",
                        }.items())
                        or actual.get("expr") != expected):
                    return False
            return True
        except (ValueError, TypeError, KeyError, AttributeError):
            return False

    def observe(self) -> dict:
        with self._exclusive():
            value = self._current()
            if not self._observe(value):
                raise IsolatedNftError("Kernel ACL differs from the durable native policy.")
            return value.copy()

    def arm(self, operation: str, *, seconds: int = 60) -> None:
        if not isinstance(operation, str) or not _OPERATION.fullmatch(operation):
            raise ValueError("Invalid operation identifier.")
        if type(seconds) is not int or not 2 <= seconds <= 3600:
            raise ValueError("Rollback deadline must be 2-3600 seconds.")
        with self._exclusive():
            if self.pending.exists():
                raise IsolatedNftError("An unreconciled operation already owns SSH ACL.")
            state = self._current()
            if not self._observe(state):
                raise IsolatedNftError("Cannot arm rollback with mismatched actual policy.")
            _write_json(self.pending, {
                "operation": operation, "deadline": time.time() + seconds,
                "previous": state, "target": None, "namespace": self.namespace,
            })
            worker = subprocess.Popen(
                [sys.executable, "-m", "datarelay_onprem_security.host_ssh_nft",
                 "watch", str(self.root), self.table, str(self.ssh_port)],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, close_fds=True, start_new_session=True,
            )
            time.sleep(0.08)
            if worker.poll() is not None:
                self.pending.unlink(missing_ok=True)
                raise IsolatedNftError("External rollback watchdog did not start.")

    def apply(self, operation: str, sources: tuple[str, ...], *, enabled: bool = True) -> None:
        if type(enabled) is not bool or not isinstance(sources, tuple):
            raise ValueError("Explicit native Boolean and CIDR tuple required.")
        if not enabled and sources:
            raise ValueError("Disabled native policy cannot silently discard CIDRs.")
        checked = _sources(sources) if enabled else ()
        with self._exclusive():
            pending = _read_json(self.pending)
            if pending.get("operation") != operation or pending.get("namespace") != self.namespace:
                raise IsolatedNftError("This ACL operation is not the current native owner.")
            if time.time() >= pending["deadline"]:
                raise IsolatedNftError("Rollback timer already expired.")
            state = self._current()
            if state != pending["previous"] or not self._observe(state):
                raise IsolatedNftError("Stale ACL baseline; refusing native apply.")
            target = {**state, "sources": list(checked), "enabled": enabled}
            self._rules(checked, enabled)
            _write_json(self.state, target)
            _write_json(self.pending, {**pending, "target": target})
            if not self._observe(target):
                raise IsolatedNftError("Native nftables enforcement differs from requested policy.")

    def confirm(self, operation: str) -> bool:
        with self._exclusive():
            if not self.pending.exists():
                return False
            pending = _read_json(self.pending)
            if pending.get("operation") != operation or time.time() >= pending["deadline"]:
                return False
            target = pending.get("target")
            if target is None or self._current() != target or not self._observe(target):
                return False
            self.pending.unlink()
            return True

    def rollback(self, operation: str) -> bool:
        with self._exclusive():
            pending = _read_json(self.pending)
            if pending.get("operation") != operation:
                return False
            before = pending["previous"]
            self._rules(tuple(before["sources"]), before["enabled"])
            _write_json(self.state, before)
            if not self._observe(before):
                raise IsolatedNftError("Rollback did not restore prior kernel ACL state.")
            self.pending.unlink()
            return True

    def uninstall(self) -> None:
        """Available only after a confirmed clean state, inside lab namespace."""
        with self._exclusive():
            if self.pending.exists():
                raise IsolatedNftError("Cannot remove lab policy while rollback is pending.")
            current = self._current()
            if not self._observe(current):
                raise IsolatedNftError("Refusing to remove a foreign-mutated native chain.")
            self._nft("delete", "table", "inet", self.table)
        self.state.unlink(missing_ok=True)
        self.lock.unlink(missing_ok=True)
        self.root.rmdir()


def _watch(root: Path, table: str, port: int) -> None:
    driver = IsolatedNftSshAcl(root, table=table, ssh_port=port)
    while True:
        try:
            pending = _read_json(driver.pending)
        except IsolatedNftError:
            return
        if pending.get("namespace") != driver.namespace:
            return
        until = float(pending["deadline"])
        if time.time() < until:
            time.sleep(min(0.2, max(0.02, until - time.time())))
            continue
        with driver._exclusive():
            if not driver.pending.exists():
                return
            latest = _read_json(driver.pending)
            if latest.get("operation") != pending.get("operation"):
                return
            if time.time() < latest["deadline"]:
                continue
            baseline = latest["previous"]
            driver._rules(tuple(baseline["sources"]), baseline["enabled"])
            _write_json(driver.state, baseline)
            if driver._observe(baseline):
                driver.pending.unlink()
                return
        # Persistent journal deliberately remains when kernel readback fails.
        # A separate recovery operator must reconcile it; do not fake PASS.
        return


if __name__ == "__main__":
    if len(sys.argv) != 5 or sys.argv[1] != "watch":
        raise SystemExit("watchdog invocation only")
    _watch(Path(sys.argv[2]), sys.argv[3], int(sys.argv[4]))
