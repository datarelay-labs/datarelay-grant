"""Reusable opt-in native SQLite recovery and immutable encrypted retention.

Operations are confined to the application's private SQLite root, never to
other products' data. The AES-256-GCM key is provisioned out of band and is
never returned through the administrative API.
"""
from __future__ import annotations

import json
import secrets
import sqlite3
import time
from dataclasses import asdict
from pathlib import Path

from .host_sqlite_backup import EncryptedSQLiteBackup

POLICY_KEY = "host_backup_retention"
DEFAULT_KEEP_LAST = 7


class EmbeddedLifecycle:
    def __init__(self, database: str | Path, root: str | Path, *, default_keep_last: int = DEFAULT_KEEP_LAST):
        if type(default_keep_last) is not int or not 1 <= default_keep_last <= 365:
            raise ValueError("Default encrypted retention policy must preserve 1-365 snapshots.")
        self.default_keep_last = default_keep_last
        self.database = Path(database)
        self.root = Path(root)
        if (not self.database.is_absolute() or not self.root.is_absolute()
                or self.root.is_symlink() or self.database.is_symlink()
                or self.database.parent != self.root or not self.database.is_file()):
            raise ValueError("Native lifecycle must own the application's private SQLite root.")
        if self.database.name == "backup.key":
            raise ValueError("SQLite file and backup encryption key must be distinct.")

    def _driver(self):
        return EncryptedSQLiteBackup(self.root, database=self.database.name)

    def read(self, keep_last: int):
        driver = self._driver()
        plan = driver.preview_retention(keep_last)
        return {
            "keepLast": keep_last,
            "revision": plan.revision,
            "retain": list(plan.retain),
            "remove": list(plan.remove),
            "configured": True,
        }

    def create(self):
        driver = self._driver()
        # Lexical tie-break is chronological even for two snapshots in one second.
        ref = ("snap-" + time.strftime("%Y%m%d-%H%M%S", time.gmtime())
               + "-" + str(time.time_ns()) + "-" + secrets.token_hex(3))
        result = driver.create(ref)
        return dict(asdict(result), encrypted=True)

    def verify(self, reference: str):
        return dict(asdict(self._driver().verify(reference)), verified=True)

    def restore_drill(self, reference: str):
        target = self.root / ("drill-" + secrets.token_hex(8))
        return dict(asdict(self._driver().restore_drill(reference, target)),
                    restoredToIsolatedDirectory=True)

    def preview(self, keep_last: int):
        plan = self._driver().preview_retention(keep_last)
        return dict(revision=plan.revision, keepLast=plan.keep_last,
                    retain=list(plan.retain), remove=list(plan.remove))

    def apply(self, keep_last: int, expected_revision: str):
        driver = self._driver()
        plan = driver.preview_retention(keep_last)
        if expected_revision != plan.revision:
            raise ValueError("Encrypted archive inventory changed; regenerate preview.")
        count = driver.apply_retention(plan, confirmed=True)
        return dict(deletedEncryptedSnapshots=count, retained=list(plan.retain),
                    verified=True)

    @staticmethod
    def keep_last(database: Path) -> int:
        with sqlite3.connect(str(database)) as db:
            row = db.execute("SELECT value FROM policies WHERE key=?", (POLICY_KEY,)).fetchone()
        if row is None:
            return DEFAULT_KEEP_LAST
        config = json.loads(row[0])
        value = config.get("keepLast")
        if type(value) is not int or not 1 <= value <= 365:
            raise ValueError("Unsafe backup retention policy.")
        return value

    def tick(self):
        """Idempotent one-shot job for a root-owned systemd timer running as app user."""
        keep_last = self.keep_last(self.database)
        snapshot = self.create()
        plan = self.preview(keep_last)
        result = self.apply(keep_last, plan["revision"])
        return dict(created=snapshot["reference"], keepLast=keep_last, **result)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("tick",))
    parser.add_argument("--database", required=True)
    parser.add_argument("--private-root", required=True)
    args = parser.parse_args()
    lifecycle = EmbeddedLifecycle(args.database, args.private_root)
    print(json.dumps(lifecycle.tick(), sort_keys=True))


if __name__ == "__main__":
    main()
