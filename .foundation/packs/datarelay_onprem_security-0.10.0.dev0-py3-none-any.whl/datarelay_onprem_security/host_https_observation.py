"""Fail-closed external TLS listener readback for Control-cloned Administration.

This observer is *not* a certificate installer or a reverse-proxy mutator.
Actual socket TLS SAN/chain verification is required; responses cannot claim
a certificate or listener merely from stored configuration.
"""
from __future__ import annotations

import ipaddress
import math
import socket
import ssl
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit


class HostHttpsObservationError(RuntimeError):
    pass


@dataclass(frozen=True)
class HostHttpsObservation:
    origin: str
    certificate_ip_addresses: tuple[str, ...]
    certificate_dns_names: tuple[str, ...]
    certificate_not_after: str


class HostHttpsObserver:
    def __init__(self, *, origin: str, ca_file: str | Path,
                 http_port: int | None = None, timeout_seconds: float = 3.0):
        parsed = urlsplit(origin)
        if (parsed.scheme != "https" or not parsed.hostname
                or parsed.username is not None or parsed.password is not None
                or parsed.query or parsed.fragment or parsed.path not in ("", "/")):
            raise ValueError("Only an explicit HTTPS origin can be observed.")
        if parsed.port is None or not 1024 <= parsed.port <= 65535:
            raise ValueError("Specify an unprivileged external TLS port.")
        try:
            ipaddress.ip_address(parsed.hostname)
        except ValueError:
            if len(parsed.hostname) > 253 or any(ch.isspace() for ch in parsed.hostname):
                raise ValueError("Invalid HTTPS observation hostname.") from None
        authority = Path(ca_file)
        if not authority.is_absolute() or authority.is_symlink() or not authority.is_file():
            raise ValueError("Explicit pinned trusted CA file is required.")
        if authority.stat().st_mode & 0o022:
            raise ValueError("The TLS trust bundle must not be writable by untrusted users.")
        if http_port is not None and (
                type(http_port) is not int or not 1024 <= http_port <= 65535
                or http_port == parsed.port):
            raise ValueError("Invalid observed HTTP peer port.")
        if type(timeout_seconds) not in (float, int) or not 0.2 <= timeout_seconds <= 3.0:
            raise ValueError("TLS observation timeout must be bounded.")
        self.timeout_seconds = float(timeout_seconds)
        self.origin = origin.rstrip("/")
        self.host = parsed.hostname
        self.port = parsed.port
        self.ca_file = str(authority)
        self.http_port = http_port

    def observe(self) -> HostHttpsObservation:
        try:
            context = ssl.create_default_context(cafile=self.ca_file)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            with socket.create_connection((self.host, self.port), timeout=self.timeout_seconds) as socket_peer:
                with context.wrap_socket(socket_peer, server_hostname=self.host) as peer:
                    certificate = peer.getpeercert()
                    protocol = peer.version()
                    if protocol not in ("TLSv1.2", "TLSv1.3"):
                        raise HostHttpsObservationError("Unqualified TLS protocol.")
                    names = certificate.get("subjectAltName") or []
                    ips = tuple(v for k,v in names if k == "IP Address")
                    dns = tuple(v for k,v in names if k == "DNS")
                    # Python/OpenSSL may accept a CN when SAN is absent for DNS.
                    # Control must never call a legacy CN-only identity verified.
                    if not names or not any(kind in ("IP Address", "DNS") for kind, _ in names):
                        raise HostHttpsObservationError("A certificate SAN identity is required.")
                    expiry = certificate.get("notAfter")
                    if not isinstance(expiry, str):
                        raise HostHttpsObservationError("TLS certificate expiration unverified.")
                    expires = ssl.cert_time_to_seconds(expiry)
                    if expires <= time.time():
                        raise HostHttpsObservationError("TLS certificate has expired.")
                    after = datetime.fromtimestamp(expires, timezone.utc).isoformat().replace("+00:00", "Z")
                    return HostHttpsObservation(
                        self.origin, ips, dns, after
                    )
        except HostHttpsObservationError:
            raise
        except (OSError, ValueError, ssl.SSLError) as exc:
            raise HostHttpsObservationError("External TLS handshake, name or trust verification failed.") from exc

    def settings(self) -> dict:
        fact = self.observe()
        expiry = datetime.fromisoformat(fact.certificate_not_after.replace("Z", "+00:00")).timestamp()
        return {
            "enabled": True,
            "certificate_ip_addresses": list(fact.certificate_ip_addresses),
            "certificate_dns_names": list(fact.certificate_dns_names),
            "redirect_http_to_https": False,
            "certificate_valid_days": max(1, min(3650, math.ceil((expiry-time.time())/86400))),
            "current_access_url": fact.origin,
            "https_active": True,
            "certificate_not_after": fact.certificate_not_after,
            "restart_required_after_save": False,
            "http_listener_active": False,
            "https_listener_active": True,
            "redirect_http_to_https_effective": False,
            "proxy_status": "unknown",
            "proxy_health_ok": None,
            "proxy_last_reload_at": None,
            "proxy_last_reload_ok": None,
            "proxy_last_reload_detail": "TLS listener observed; product proxy mutation driver not installed.",
            "proxy_fallback_to_http_last": False,
            "browser_http_url": ("http://"+self.host+":"+str(self.http_port)
                                 if self.http_port is not None else
                                 "http://"+self.host+":80"),
            "browser_https_url": fact.origin,
        }

    def network(self) -> dict:
        self.observe()  # Kernel/TLS live readback; no report from configuration alone.
        if self.http_port is None:
            raise HostHttpsObservationError("No independent HTTP listener port was configured.")
        return {
            "http_port": self.http_port,
            "https_port": self.port,
            "env_example": {
                "GDC_HTTP_PORT": str(self.http_port),
                "GDC_HTTPS_PORT": str(self.port),
            },
            "restart_required": False,
            "restart_command": "Not installed: host port mutation requires a qualified native driver.",
        }
