"""Restricted root command gateway: no installer, shell, path, or port arguments.

Used by the unprivileged Foundation ASGI service via a *root-owned* executable.
The sudoers allowlist grants only this gateway, not a Python interpreter.
"""
from __future__ import annotations

import argparse
import json
import sys
from .host_native_ssh import NativeHostSsh, HostSshError

FIXED_ROOT = "/var/lib/datarelay-foundation/native-ssh"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("status", "stage", "confirm", "rollback"))
    parser.add_argument("--operation")
    args = parser.parse_args()
    if args.action in ("stage", "confirm", "rollback") and not args.operation:
        parser.error("A scoped operation identifier is required.")
    service = NativeHostSsh(FIXED_ROOT)
    if args.action == "status":
        value = service.status()
    elif args.action == "stage":
        payload = sys.stdin.buffer.read(16385)
        if len(payload) > 16384:
            raise HostSshError("SSH operation exceeds bounded JSON input.")
        request = json.loads(payload)
        if not isinstance(request, dict) or set(request) != {"sshCidrs"}:
            raise HostSshError("Only canonical SSH allowlist data is permitted.")
        value = service.stage(args.operation, request["sshCidrs"], seconds=90)
    elif args.action == "confirm":
        value = service.confirm(args.operation)
    else:
        value = service.rollback(args.operation)
    print(json.dumps(value, separators=(",", ":"), sort_keys=True))


if __name__ == "__main__":
    main()
