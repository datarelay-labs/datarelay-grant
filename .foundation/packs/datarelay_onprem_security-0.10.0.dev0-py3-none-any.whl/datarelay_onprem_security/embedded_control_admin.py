"""Concrete native compatibility routes for Control's reusable account/system settings.

This is not a simulation of host operations. User creation, password changes,
timezone settings, and audit are backed by SQLite and enforced server-side.
Host TLS/proxy/network/retention/backup operations deliberately return 503
unless a real privileged host driver is qualified separately.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import platform
import re
import secrets
import sqlite3
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .embedded_runtime import EmbeddedFoundationRuntime, HttpFailure, _password_hash, _utc


def _admin(svc: EmbeddedFoundationRuntime, c: sqlite3.Connection, session: sqlite3.Row | None) -> str:
    if session is None:
        raise HttpFailure(401, "Authentication is required.")
    user = svc._user(c, session["user_name"])
    if user["role"] != "ADMINISTRATOR" or user["status"] != "ACTIVE":
        raise HttpFailure(403, "Administrator access is required.")
    return user["name"]


def _profile(svc: EmbeddedFoundationRuntime, c: sqlite3.Connection,
             session: sqlite3.Row | None):
    if session is None:
        raise HttpFailure(401, "Authentication is required.")
    user = svc._user(c, session["user_name"])
    role = user["role"]
    permissions = (list(svc._roles(c)["availablePermissions"]) if role == "ADMINISTRATOR"
                   else json.loads(svc._policy(c, "role:"+role)["value"])["permissions"])
    return dict(username=user["name"], role=role, authenticated=True,
                must_change_password=False, token_expires_at=_utc(session["expires"]),
                capabilities={p: p in permissions for p in svc._roles(c)["availablePermissions"]},
                timezone=user["timezone"],
                platform_default_timezone=json.loads(svc._policy(c, "display")["value"])["default_timezone"])


def _row_user(row: sqlite3.Row):
    return dict(id=row["rowid"], username=row["name"], role=row["role"],
                status=row["status"], timezone=row["timezone"],
                created_at=_utc(row["created_at"]),
                last_login_at=_utc(row["last_login"]) if row["last_login"] else None)


def _lookup_user(c: sqlite3.Connection, user_id: int):
    value = c.execute("SELECT rowid, * FROM users WHERE rowid=?", (user_id,)).fetchone()
    if value is None:
        raise HttpFailure(404, "User not found.")
    return value


def _password(password: Any):
    if not isinstance(password, str) or len(password) < 12 or len(password) > 256:
        raise HttpFailure(400, "Password must contain 12–256 characters.")
    return password


def _timezone(tz: Any, *, empty: bool = False):
    if empty and tz is None:
        return None
    if not isinstance(tz, str) or not (1 <= len(tz) <= 128):
        raise HttpFailure(400, "Invalid display timezone.")
    try:
        ZoneInfo(tz)
    except (ZoneInfoNotFoundError, ValueError, KeyError) as exc:
        raise HttpFailure(400, "Timezone is not an IANA identifier.") from exc
    return tz


def _last_admin(c: sqlite3.Connection, selected: sqlite3.Row):
    if selected["role"] == "ADMINISTRATOR" and selected["status"] == "ACTIVE":
        active = c.execute("SELECT COUNT(*) FROM users WHERE role='ADMINISTRATOR' AND status='ACTIVE'").fetchone()[0]
        if active <= 1:
            raise HttpFailure(409, "The last active administrator cannot be deleted or disabled.")


def dispatch_control_admin(svc: EmbeddedFoundationRuntime, c: sqlite3.Connection,
                           method: str, path: str, body: dict[str, Any],
                           headers: dict[str, str], session: sqlite3.Row | None, now: int):
    suffix = path.removeprefix("/api/v1/")
    if method in ("POST", "PUT", "PATCH", "DELETE"):
        svc._csrf(session, headers)
    if suffix == "auth/whoami" and method == "GET":
        return 200, _profile(svc, c, session), None
    if suffix == "auth/profile" and method == "PATCH":
        if session is None:
            raise HttpFailure(401, "Authentication is required.")
        timezone = _timezone(body.get("timezone"), empty=True)
        c.execute("UPDATE users SET timezone=? WHERE name=?", (timezone, session["user_name"]))
        svc._audit(c, session["user_name"], "auth.timezone", dict(timezone=timezone))
        return 200, _profile(svc, c, session), None
    if suffix == "admin/display-settings" and method == "GET":
        _admin(svc, c, session)
        value = json.loads(svc._policy(c, "display")["value"])
        return 200, dict(**value, updated_at=None), None
    if suffix == "admin/display-settings" and method == "PUT":
        name = _admin(svc, c, session)
        tz = _timezone(body.get("default_timezone"))
        c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key='display'",
                  (json.dumps(dict(default_timezone=tz)),))
        svc._audit(c, name, "system.display_timezone", dict(timezone=tz))
        return 200, dict(default_timezone=tz), None
    if suffix == "admin/system" and method == "GET":
        _admin(svc, c, session)
        c.execute("SELECT 1").fetchone()
        return 200, dict(
            app_name="DataRelay Product Foundation",
            app_version="embedded-runtime",
            app_env="embedded",
            python_version=platform.python_version(),
            database_reachable=True,
            database_url_masked="SQLite (private embedded database)",
            platform=platform.system(),
            server_time_utc=_utc(now), timezone="UTC",
            database_version=sqlite3.sqlite_version,
            uptime_seconds=int(now-svc.started_at),
        ), None
    if suffix in ("admin/https-settings", "admin/network-settings", "admin/network-settings/apply"):
        actor = _admin(svc, c, session)
        if svc.native_ingress is not None:
            from .embedded_ingress_api import dispatch_ingress
            return dispatch_ingress(svc, c, method, suffix, body, actor, session, now)
        if method == "GET" and suffix in ("admin/https-settings", "admin/network-settings"):
            if svc.native_https is None:
                raise HttpFailure(503, "An external TLS observer is not installed.")
            from .host_https_observation import HostHttpsObservationError
            try:
                observed = (svc.native_https.settings() if suffix == "admin/https-settings"
                            else svc.native_https.network())
            except HostHttpsObservationError as exc:
                raise HttpFailure(503, "External TLS readback could not be verified.") from exc
            return 200, observed, None
        raise HttpFailure(503, "No qualified native HTTPS/Network mutation gateway is installed.")
    if suffix == "admin/users" and method == "GET":
        _admin(svc, c, session)
        rows = c.execute("SELECT rowid, * FROM users ORDER BY name LIMIT 300").fetchall()
        return 200, [_row_user(row) for row in rows], None
    if suffix == "admin/users" and method == "POST":
        actor = _admin(svc, c, session)
        name, role = body.get("username"), body.get("role")
        password = _password(body.get("password"))
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{1,63}", name):
            raise HttpFailure(400, "Invalid username.")
        if role not in ("ADMINISTRATOR", "OPERATOR", "VIEWER"):
            raise HttpFailure(400, "Invalid account role.")
        salt = secrets.token_bytes(24)
        try:
            c.execute("""INSERT INTO users(name,salt,password_hash,role,created_at)
                         VALUES(?,?,?,?,?)""",
                      (name, salt.hex(), _password_hash(password, salt), role, now))
        except sqlite3.IntegrityError as exc:
            raise HttpFailure(409, "Username already exists.") from exc
        svc._audit(c, actor, "user.created", dict(username=name, role=role))
        return 200, _row_user(c.execute("SELECT rowid,* FROM users WHERE name=?",(name,)).fetchone()), None
    if suffix.startswith("admin/users/") and method in ("PATCH", "DELETE"):
        actor = _admin(svc, c, session)
        fragment = suffix.removeprefix("admin/users/")
        if not fragment.isdigit() or len(fragment) > 12:
            raise HttpFailure(404, "Invalid account reference.")
        user = _lookup_user(c, int(fragment))
        if method == "DELETE":
            if user["name"] == actor:
                raise HttpFailure(403, "You cannot delete your current account.")
            _last_admin(c, user)
            c.execute("DELETE FROM sessions WHERE user_name=?", (user["name"],))
            c.execute("DELETE FROM challenges WHERE user_name=?", (user["name"],))
            c.execute("DELETE FROM users WHERE rowid=?", (user["rowid"],))
            svc._audit(c, actor, "user.deleted", dict(username=user["name"]))
            return 200, dict(ok=True), None
        if not any(key in body for key in ("password", "role", "status")):
            raise HttpFailure(400, "No account changes provided.")
        if "role" in body and body["role"] not in ("ADMINISTRATOR", "OPERATOR", "VIEWER"):
            raise HttpFailure(400, "Invalid role.")
        if "status" in body and body["status"] not in ("ACTIVE", "DISABLED"):
            raise HttpFailure(400, "Invalid status.")
        if ((body.get("role",user["role"]) != "ADMINISTRATOR" or
             body.get("status",user["status"]) != "ACTIVE") and
            user["role"] == "ADMINISTRATOR" and user["status"] == "ACTIVE"):
            _last_admin(c, user)
        if "password" in body:
            pw = _password(body["password"])
            salt = secrets.token_bytes(24)
            c.execute("UPDATE users SET salt=?,password_hash=? WHERE rowid=?",
                      (salt.hex(), _password_hash(pw,salt),user["rowid"]))
        if "role" in body:
            c.execute("UPDATE users SET role=? WHERE rowid=?", (body["role"],user["rowid"]))
        if "status" in body:
            c.execute("UPDATE users SET status=? WHERE rowid=?", (body["status"],user["rowid"]))
        c.execute("UPDATE sessions SET revoked=1 WHERE user_name=?", (user["name"],))
        if body.get("status") == "DISABLED":
            c.execute("DELETE FROM challenges WHERE user_name=?", (user["name"],))
        svc._audit(c, actor, "user.updated", dict(username=user["name"],
                    password_changed="password" in body,
                    role_changed="role" in body, status_changed="status" in body))
        return 200, _row_user(_lookup_user(c,user["rowid"])), None
    if suffix == "admin/password" and method == "POST":
        actor = _admin(svc, c, session)
        target = body.get("username")
        if not isinstance(target, str) or not target:
            raise HttpFailure(400, "An account is required.")
        if body.get("new_password") != body.get("confirm_password"):
            raise HttpFailure(400, "Password confirmation mismatch.")
        pw = _password(body.get("new_password"))
        provided = body.get("current_password")
        admin = svc._user(c, actor)
        if not isinstance(provided, str) or not hmac.compare_digest(
            _password_hash(provided, bytes.fromhex(admin["salt"])), admin["password_hash"]
        ):
            raise HttpFailure(403, "Administrator password reauthentication required.")
        existing = svc._user(c,target)
        salt = secrets.token_bytes(24)
        c.execute("UPDATE users SET salt=?,password_hash=? WHERE name=?",
                  (salt.hex(),_password_hash(pw,salt),target))
        c.execute("UPDATE sessions SET revoked=1 WHERE user_name=?", (target,))
        svc._audit(c,actor,"user.password_changed",dict(username=target))
        return 200,dict(ok=True),None
    if suffix == "admin/audit-log" and method == "GET":
        _admin(svc,c,session)
        rows = c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 100").fetchall()
        return 200, dict(total=len(rows),items=[
            dict(id=r["id"],created_at=_utc(r["at"]),actor_username=r["actor"],
                 action=r["operation"],entity_type="security",
                 entity_id=None,entity_name=None,details=json.loads(r["detail"]))
            for r in rows]),None
    raise HttpFailure(503, "This Control host operation has no installed native service.")
