"""Unprivileged ASGI -> fixed root-owned SSH ACL gateway, explicit opt-in only."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any


class HostSshBridgeUnavailable(RuntimeError):
    pass


class HostSshBridge:
    def __init__(self, helper: str | Path):
        binary = Path(helper)
        if not binary.is_absolute() or not binary.is_file() or binary.is_symlink():
            raise ValueError("A pinned absolute root-owned executable helper is required.")
        stats = binary.stat()
        if stats.st_uid != 0 or stats.st_mode & 0o022:
            raise ValueError("Privileged SSH gateway must be root-owned and non-writable.")
        self.helper = str(binary)

    def _call(self, action: str, *, operation: str | None = None,
              ssh_cidrs: list[str] | None = None) -> dict[str, Any]:
        if action not in ("status", "stage", "confirm", "rollback"):
            raise ValueError("Unsupported host SSH action.")
        command = ["sudo", "-n", self.helper, action]
        if operation is not None:
            command += ["--operation", operation]
        request = {"sshCidrs": ssh_cidrs} if action == "stage" else None
        try:
            done = subprocess.run(
                command, input=json.dumps(request) if request is not None else None,
                capture_output=True, text=True, check=False, timeout=14,
                env={**os.environ, "PATH": "/usr/sbin:/usr/bin:/bin"},
            )
            if done.returncode != 0 or len(done.stdout) > 4096:
                raise HostSshBridgeUnavailable("Privileged SSH host driver rejected the operation.")
            response = json.loads(done.stdout)
            if not isinstance(response, dict):
                raise HostSshBridgeUnavailable("Native SSH readback must be a JSON object.")
            return response
        except (OSError, subprocess.TimeoutExpired, ValueError) as exc:
            raise HostSshBridgeUnavailable("Privileged SSH host driver unavailable.") from exc

    def status(self) -> dict[str, Any]:
        return self._call("status")

    def stage(self, operation: str, sources: list[str]) -> dict[str, Any]:
        return self._call("stage", operation=operation, ssh_cidrs=sources)

    def confirm(self, operation: str) -> dict[str, Any]:
        return self._call("confirm", operation=operation)

    def rollback(self, operation: str) -> dict[str, Any]:
        return self._call("rollback", operation=operation)
