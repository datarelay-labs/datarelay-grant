"""Scoped, opt-in Nginx ingress authority; never owns the system Nginx.

Operator installation pins a private prefix, local upstream, TLS identity and
recovery mode. The Web gateway may only submit validated HTTPS options/ports.
Every change arms an independent rollback BEFORE Nginx is reloaded. Only the
prefix's Nginx master is signaled; other listeners/configuration are untouched.
"""
from __future__ import annotations

import fcntl
import http.client
import ipaddress
import json
import os
import re
import socket
import ssl
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from .host_https_observation import HostHttpsObserver, HostHttpsObservationError

_OPERATION = re.compile(r"ing-[0-9a-f]{20}\Z")


class NativeIngressError(RuntimeError):
    pass


def _guard_file(path: Path, *, owner: int = 0, private: bool = False):
    if (not path.is_absolute() or path.is_symlink() or not path.is_file()
            or path.stat().st_uid != owner
            or path.stat().st_mode & (0o077 if private else 0o022)):
        raise NativeIngressError("Native ingress file is missing or insecure.")


def _write(path: Path, value: str, *, mode: int = 0o600):
    # Atomic, fsynced replacements; never truncate an installed live file.
    temp = path.parent / ("." + path.name + "." + os.urandom(8).hex())
    fd = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, mode)
    try:
        with os.fdopen(fd, "w") as out:
            out.write(value)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temp, path)
        folder = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(folder)
        finally:
            os.close(folder)
    finally:
        temp.unlink(missing_ok=True)


def _json(path: Path) -> dict:
    _guard_file(path)
    payload = json.loads(path.read_text())
    if not isinstance(payload, dict):
        raise NativeIngressError("Malformed native ingress journal.")
    return payload


def _ports(http: object, https: object):
    if any(type(v) is not int or not 1024 <= v <= 65535 for v in (http, https)) or http == https:
        raise NativeIngressError("Distinct unprivileged HTTP and HTTPS ports required.")
    return int(http), int(https)


def _run(args: list[str], *, timeout: float = 8):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise NativeIngressError("Dedicated native ingress command unavailable.") from exc
    if result.returncode:
        raise NativeIngressError("Dedicated native ingress command failed: " + result.stderr[-320:])
    return result.stdout


class NativeNginxIngress:
    """Host effect guarded by exclusive root-private state and timed rollback.

    `isolated_lab` is valid ONLY inside an independently owned user+network
    namespace. Production always uses root + systemd transient timer.
    """

    def __init__(self, root: str | Path, *, isolated_lab: bool = False):
        if os.geteuid() != 0:
            raise NativeIngressError("Native ingress requires a root-owned helper.")
        if isolated_lab:
            from .host_ssh_nft import IsolatedNftError, _namespace
            try:
                _namespace()  # nsfs ownership oracle, not just UID mapping.
            except IsolatedNftError as exc:
                raise NativeIngressError("Laboratory mode requires owned rootless network isolation.") from exc
        self.lab = isolated_lab
        self._lab_watchdogs: dict[int, subprocess.Popen] = {}
        self.root = Path(root)
        if not self.lab and self.root != Path("/var/lib/datarelay-foundation/native-ingress"):
            raise NativeIngressError("Host production ingress must use the fixed root-owned state prefix.")
        if (not self.root.is_absolute() or self.root.is_symlink() or not self.root.is_dir()
                or any(not re.fullmatch(r"[A-Za-z0-9._-]+", part) for part in self.root.parts[1:])
                or self.root.stat().st_uid != 0 or self.root.stat().st_mode & 0o077):
            raise NativeIngressError("Explicit private root-owned ingress install is required.")
        self.manifest = self.root / "install.json"
        self.confirmed = self.root / "confirmed.json"
        self.pending = self.root / "pending.json"
        self.config = self.root / "ingress.conf"
        self.lock = self.root / "lock"
        self.nginx = "/usr/sbin/nginx"
        self._identity = _json(self.manifest)
        if self._identity.get("mode") != ("isolated_lab" if self.lab else "systemd"):
            raise NativeIngressError("Native recovery mode differs from the operator installation.")
        if self._identity.get("host") != "127.0.0.1":
            raise NativeIngressError("Current ingress profile permits loopback only.")
        _guard_file(self.root / "ca.pem")
        _guard_file(self.root / "server.pem")
        _guard_file(self.root / "server.key", private=True)

    @contextmanager
    def guard(self):
        fd = os.open(self.lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def _render(self, current: dict, *, rescue: dict | None = None):
        http_port, https_port = _ports(current["http_port"], current["https_port"])
        http_ports = sorted({http_port, *([rescue["http_port"]] if rescue else [])})
        tls_ports = sorted({https_port, *([rescue["https_port"]] if rescue else [])})
        if any(port in tls_ports for port in http_ports):
            raise NativeIngressError("HTTP and TLS rescue listener ports overlap.")
        backend = self._identity["backend_port"]
        if backend in http_ports or backend in tls_ports:
            raise NativeIngressError("Ingress listener collides with the private upstream.")
        http_listen = "\n".join(f"listen 127.0.0.1:{p};" for p in http_ports)
        tls_listen = "\n".join(f"listen 127.0.0.1:{p} ssl;" for p in tls_ports)
        # Host header may be attacker-supplied. Only a fixed local origin is safe.
        route = (f"return 308 https://127.0.0.1:{https_port}$request_uri;"
                 if current["redirect"] else f"include {self.root / 'upstream.inc'};")
        native_probe = 'location = /__foundation_ingress_probe__ { return 200 "foundation-ingress"; }\n'
        return (
            ("user root;\n" if self.lab else "user www-data;\n")
            + f"worker_processes 1;\npid {self.root / 'nginx.pid'};\n"
            + f"error_log {self.root / 'error.log'} warn;\n"
            + "events { worker_connections 128; }\nhttp {\naccess_log off;\n"
            + f"client_body_temp_path {self.root / 'tmp-body'};\n"
            + f"proxy_temp_path {self.root / 'tmp-proxy'};\n"
            + f"fastcgi_temp_path {self.root / 'tmp-fastcgi'};\n"
            + f"uwsgi_temp_path {self.root / 'tmp-uwsgi'};\n"
            + f"scgi_temp_path {self.root / 'tmp-scgi'};\n"
            + "server {\n" + http_listen + "\n"
            + ("" if current["redirect"] else native_probe)
            + "location / { " + route + " }\n}\n"
            + "server {\n" + tls_listen + "\nssl_protocols TLSv1.2 TLSv1.3;\n"
            + f"ssl_certificate {self.root / 'server.pem'};\n"
            + f"ssl_certificate_key {self.root / 'server.key'};\n"
            + native_probe
            + f"location / {{ include {self.root / 'upstream.inc'}; }}\n}}\n}}\n"
        )

    def _nginx(self, *args: str):
        return _run([self.nginx, "-p", str(self.root)+"/", "-c", str(self.config), *args])

    def _reload(self, current: dict, *, rescue: dict | None = None, start: bool = False):
        _write(self.config, self._render(current, rescue=rescue))
        self._nginx("-t")
        self._nginx(*(() if start else ("-s", "reload")))
        self._readback(current)

    def _readback(self, state: dict):
        observer = HostHttpsObserver(
            origin=f"https://127.0.0.1:{state['https_port']}",
            ca_file=self.root / "ca.pem", http_port=state["http_port"],
            timeout_seconds=0.45)
        error = None
        # Native helper holds a durable exclusive lock; an unresponsive peer
        # must not keep the independent watchdog waiting past its deadline.
        for _ in range(4):
            try:
                tls = observer.settings()  # CA, SAN, expiry and live handshake.
                if "127.0.0.1" not in tls["certificate_ip_addresses"]:
                    raise NativeIngressError("Verified certificate SAN is not loopback.")
                # Native probe must NOT call back into a locked SQLite/ASGI
                # handler, otherwise a host apply from the Admin API deadlocks.
                client = http.client.HTTPConnection("127.0.0.1", state["http_port"], timeout=0.45)
                try:
                    client.request("GET", "/__foundation_ingress_probe__")
                    result = client.getresponse()
                    status = result.status
                    location = result.getheader("Location", "")
                    content = result.read()
                    if state["redirect"]:
                        expected = f"https://127.0.0.1:{state['https_port']}/__foundation_ingress_probe__"
                        if status != 308 or location != expected:
                            raise NativeIngressError(f"HTTP redirect mismatched native listener: {status} {location!r} expected {expected!r}")
                    elif status != 200 or content != b"foundation-ingress":
                        raise NativeIngressError(f"Native HTTP listener health probe mismatch: status={status} body={content[:90]!r}")
                finally:
                    client.close()
                https_client = http.client.HTTPSConnection(
                    "127.0.0.1", state["https_port"], timeout=0.45,
                    context=ssl.create_default_context(cafile=str(self.root / "ca.pem")))
                try:
                    https_client.request("GET", "/__foundation_ingress_probe__")
                    result = https_client.getresponse()
                    if result.status != 200 or result.read() != b"foundation-ingress":
                        raise NativeIngressError("Native verified HTTPS health probe failed.")
                finally:
                    https_client.close()
                # Upstream TCP readiness is distinct from the browser/control
                # UI E2E gate; its HTTP handler may hold the caller's DB lock.
                with socket.create_connection(
                    ("127.0.0.1", self._identity["backend_port"]), timeout=0.45):
                    pass
                return tls
            except (OSError, http.client.HTTPException, HostHttpsObservationError, NativeIngressError) as exc:
                error = exc
                time.sleep(0.1)
        raise NativeIngressError("Native ingress socket/TLS health could not be independently verified.") from error

    @classmethod
    def install(cls, root: str | Path, *, backend_port: int, http_port: int,
                https_port: int, certificate: str | Path, key: str | Path,
                ca: str | Path, isolated_lab: bool = False):
        """Explicit operator-only setup; never called by a Web request."""
        if os.geteuid() != 0:
            raise NativeIngressError("Ingress installation requires a privileged operator.")
        if isolated_lab:
            from .host_ssh_nft import IsolatedNftError, _namespace
            try:
                _namespace()
            except IsolatedNftError as exc:
                raise NativeIngressError("Laboratory install requires owned rootless network isolation.") from exc
        _ports(http_port, https_port)
        if type(backend_port) is not int or not 1024 <= backend_port <= 65535 or backend_port in (http_port, https_port):
            raise NativeIngressError("Only a separate unprivileged local upstream is permitted.")
        dest = Path(root)
        if not isolated_lab and dest != Path("/var/lib/datarelay-foundation/native-ingress"):
            raise NativeIngressError("Privileged ingress installation requires its fixed state prefix.")
        if (not dest.parent.is_dir() or dest.parent.resolve(strict=True) != dest.parent):
            raise NativeIngressError("Native ingress installation parent cannot be a symlink.")
        if (not dest.is_absolute() or dest.exists() or dest.is_symlink()
                or any(not re.fullmatch(r"[A-Za-z0-9._-]+", part) for part in dest.parts[1:])):
            raise NativeIngressError("Refusing unsafe or existing ingress installation path.")
        source = [Path(v) for v in (certificate, key, ca)]
        for i, entry in enumerate(source):
            _guard_file(entry, owner=0, private=(i == 1))
        try:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(str(source[0]), str(source[1]))
            from cryptography import x509
            cert = x509.load_pem_x509_certificate(source[0].read_bytes())
            names = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            if ipaddress.ip_address("127.0.0.1") not in names.get_values_for_type(x509.IPAddress):
                raise NativeIngressError("Installed TLS certificate needs explicit loopback IP SAN.")
        except NativeIngressError:
            raise
        except Exception as exc:
            raise NativeIngressError("Installed TLS key/certificate validation failed.") from exc
        dest.mkdir(mode=0o700)
        os.chmod(dest, 0o700)
        for file, name in zip(source, ("server.pem", "server.key", "ca.pem")):
            _write(dest / name, file.read_text())
        _write(dest / "install.json", json.dumps(dict(
            host="127.0.0.1", backend_port=backend_port,
            mode="isolated_lab" if isolated_lab else "systemd")))
        _write(dest / "upstream.inc", (
            f"proxy_pass http://127.0.0.1:{backend_port};\n"
            "proxy_http_version 1.1;\nproxy_set_header Host $http_host;\n"
            "proxy_set_header X-Forwarded-For $remote_addr;\n"
            "proxy_set_header X-Forwarded-Proto $scheme;\n"))
        _write(dest / "confirmed.json", json.dumps(dict(
            http_port=http_port, https_port=https_port, redirect=False)))
        instance = cls(dest, isolated_lab=isolated_lab)
        with instance.guard():
            instance._reload(_json(instance.confirmed), start=True)
        return instance

    def _schedule(self, operation: str, seconds: int):
        command = [sys.executable, "-m", "datarelay_onprem_security.host_native_ingress",
                   "watchdog", "--state-root", str(self.root), "--operation", operation]
        if self.lab:
            child = subprocess.Popen([*command, "--isolated-lab", "--delay", str(seconds)],
                                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL, close_fds=True, start_new_session=True)
            if child.poll() is not None:
                raise NativeIngressError("Isolated watchdog did not start.")
            self._lab_watchdogs[child.pid] = child
            return dict(pid=child.pid)
        unit = "drf-ingress-" + operation.removeprefix("ing-")
        _run(["/usr/bin/systemd-run", "--unit="+unit,
              "--on-active="+str(seconds)+"s", "--timer-property=AccuracySec=100ms",
              *command])
        if _run(["/usr/bin/systemctl", "is-active", unit+".timer"]).strip() != "active":
            raise NativeIngressError("Independent ingress rollback timer is not armed.")
        return dict(unit=unit)

    def _cancel(self, pending: dict):
        if self.lab:
            pid = pending.get("watchdog", {}).get("pid")
            if type(pid) is int and pid > 1:
                try:
                    os.kill(pid, 15)
                except ProcessLookupError:
                    pass
                child = self._lab_watchdogs.pop(pid, None)
                if child is not None:
                    try:
                        child.wait(timeout=2)
                    except subprocess.TimeoutExpired as exc:
                        raise NativeIngressError("Isolated watchdog cancellation not verified.") from exc
        else:
            unit = pending.get("watchdog", {}).get("unit")
            if not isinstance(unit, str) or not re.fullmatch(r"drf-ingress-[0-9a-f]{20}", unit):
                raise NativeIngressError("Unexpected systemd watchdog identity.")
            _run(["/usr/bin/systemctl", "stop", unit+".timer"])

    def _pending(self, operation: str):
        if not _OPERATION.fullmatch(operation):
            raise NativeIngressError("Invalid scoped ingress operation.")
        pending = _json(self.pending)
        if pending["operation"] != operation:
            raise NativeIngressError("Native ingress operation ownership conflict.")
        return pending

    def status(self):
        for pid, child in list(self._lab_watchdogs.items()):
            if self.lab and not self.pending.exists():
                # A retired journal must not leave a detached watchdog able
                # to outlive the test/authority owner. Reap it before PASS.
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired as exc:
                    raise NativeIngressError("Expired isolated watchdog did not exit.") from exc
                self._lab_watchdogs.pop(pid, None)
            elif child.poll() is not None:
                child.wait()
                self._lab_watchdogs.pop(pid, None)
        with self.guard():
            previous = _json(self.confirmed)
            pending = _json(self.pending) if self.pending.exists() else None
            current = pending["target"] if pending else previous
            fact = self._readback(current)
            return dict(active=dict(current), confirmed=dict(previous),
                        pending=bool(pending), operation=pending["operation"] if pending else None,
                        certificate=fact, recovered=False)

    def stage(self, operation: str, target: dict, *, seconds: int = 35):
        if not isinstance(operation, str) or not _OPERATION.fullmatch(operation):
            raise NativeIngressError("Invalid scoped ingress operation.")
        if type(seconds) is not int or not 10 <= seconds <= 300:
            raise NativeIngressError("Rollback deadline must be 10–300 seconds.")
        if not isinstance(target, dict) or set(target) != {"http_port", "https_port", "redirect"}:
            raise NativeIngressError("Only HTTPS redirect and fixed ports can be changed.")
        http, https = _ports(target["http_port"], target["https_port"])
        if type(target["redirect"]) is not bool or self._identity["backend_port"] in (http, https):
            raise NativeIngressError("Unsafe ingress target.")
        target = dict(http_port=http, https_port=https, redirect=target["redirect"])
        with self.guard():
            if self.pending.exists():
                raise NativeIngressError("Another ingress mutation is in progress.")
            previous = _json(self.confirmed)
            self._readback(previous)
            if target == previous:
                raise NativeIngressError("The requested ingress is already active.")
            # Refuse to combine a prior HTTPS rescue port with a new HTTP port.
            self._render(target, rescue=previous)
            pending = dict(operation=operation, target=target, previous=previous,
                           expires_at=time.time()+seconds, phase="staged", watchdog=None)
            _write(self.pending, json.dumps(pending))
            try:
                pending["watchdog"] = self._schedule(operation, seconds)
                _write(self.pending, json.dumps(pending))
                self._reload(target, rescue=previous)
            except Exception:
                # The pending journal and watchdog remain for independent rescue.
                # Do not release the lease on an unverified kernel/user-space state.
                raise
            return dict(operation=operation, expires_at=pending["expires_at"],
                        active=target, pending=True)

    def confirm(self, operation: str):
        with self.guard():
            pending = self._pending(operation)
            if pending["phase"] != "staged" or time.time() >= pending["expires_at"]:
                raise NativeIngressError("Native ingress confirmation expired or was replayed.")
            target = pending["target"]
            self._readback(target)
            self._reload(target)  # Drop the previous port only after target verification.
            # A crashed confirmation retains its journal; the watchdog must
            # reconcile the committed target rather than undo a verified change.
            pending["phase"] = "committed"
            _write(self.pending, json.dumps(pending))
            _write(self.confirmed, json.dumps(target))
            self._cancel(pending)
            self.pending.unlink()
            return dict(success=True, active=target, pending=False)

    def rollback(self, operation: str):
        if not isinstance(operation, str) or not _OPERATION.fullmatch(operation):
            raise NativeIngressError("Invalid scoped native ingress rollback operation.")
        with self.guard():
            if not self.pending.exists():
                prior = _json(self.confirmed)
                self._readback(prior)
                return dict(recovered=True, pending=False)
            pending = self._pending(operation)
            if pending["phase"] == "committed":
                try:
                    self._readback(pending["target"])
                    _write(self.confirmed, json.dumps(pending["target"]))
                    self.pending.unlink()
                    return dict(recovered=True, committed=True, pending=False)
                except NativeIngressError:
                    pass
            previous = pending["previous"]
            self._reload(previous)
            _write(self.confirmed, json.dumps(previous))
            self.pending.unlink()
            return dict(recovered=True, committed=False, active=previous, pending=False)

    def apply(self, target: dict, *, seconds: int = 35):
        import secrets
        operation = "ing-" + secrets.token_hex(10)
        self.stage(operation, target, seconds=seconds)
        return self.confirm(operation)

    def stop_lab(self):
        if not self.lab:
            raise NativeIngressError("Stopping production ingress requires operator service management.")
        with self.guard():
            if self.pending.exists():
                raise NativeIngressError("Cannot stop a pending rollback.")
            pidfile = self.root / "nginx.pid"
            _guard_file(pidfile)
            pid = int(pidfile.read_text().strip())
            self._nginx("-s", "quit")
        for _ in range(60):
            try:
                os.kill(pid, 0)
                # Zombie of the one dedicated laboratory master has ceased
                # accepting traffic and awaits the OS init reaper.
                stat = Path(f"/proc/{pid}/stat")
                if not stat.exists() or stat.read_text().split()[2] == "Z":
                    return
            except ProcessLookupError:
                return
            time.sleep(0.05)
        raise NativeIngressError("Dedicated laboratory Nginx did not shut down.")


def main(argv: list[str] | None = None):
    """Operator-only lab install; production privilege provisioning is separate.

    This CLI can install inside a verified rootless user+network namespace only.
    The restricted ASGI-to-root gateway does not expose an install action.
    """
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("install-lab", "status", "stage", "confirm", "rollback", "watchdog"))
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--operation")
    parser.add_argument("--isolated-lab", action="store_true")
    parser.add_argument("--delay", type=int, default=0)
    parser.add_argument("--backend-port", type=int)
    parser.add_argument("--http-port", type=int)
    parser.add_argument("--https-port", type=int)
    parser.add_argument("--certificate", type=Path)
    parser.add_argument("--key", type=Path)
    parser.add_argument("--ca", type=Path)
    args = parser.parse_args(argv)
    install_inputs = (args.backend_port, args.http_port, args.https_port,
                      args.certificate, args.key, args.ca)
    if args.action == "install-lab":
        if not args.isolated_lab or args.operation is not None or args.delay != 0 or any(v is None for v in install_inputs):
            parser.error("Install requires a rootless network namespace, explicit listener ports and preprovisioned TLS identity.")
        instance = NativeNginxIngress.install(
            args.state_root, backend_port=args.backend_port,
            http_port=args.http_port, https_port=args.https_port,
            certificate=args.certificate, key=args.key, ca=args.ca,
            isolated_lab=True)
        output = instance.status()
    else:
        if any(v is not None for v in install_inputs):
            parser.error("Installer parameters cannot be forwarded to runtime actions.")
        if (args.action in ("status",) and (args.operation is not None or args.delay != 0)):
            parser.error("Status accepts no operation or watchdog delay.")
        if args.action in ("stage", "confirm", "rollback") and args.delay != 0:
            parser.error("Runtime mutations cannot override the recovery delay.")
        if args.action in ("stage", "confirm", "watchdog", "rollback") and not args.operation:
            parser.error("A valid native operation reference is required.")
        instance = NativeNginxIngress(args.state_root, isolated_lab=args.isolated_lab)
        if args.action == "watchdog":
            if args.delay:
                if not args.isolated_lab or not 10 <= args.delay <= 300:
                    raise NativeIngressError("Only isolated rollback delay is accepted.")
                time.sleep(args.delay)
            output = instance.rollback(args.operation)
        elif args.action == "status":
            output = instance.status()
        elif args.action == "stage":
            request = sys.stdin.buffer.read(2049)
            if len(request) > 2048:
                raise NativeIngressError("Ingress request exceeds bounds.")
            output = instance.stage(args.operation, json.loads(request))
        elif args.action == "confirm":
            output = instance.confirm(args.operation)
        else:
            output = instance.rollback(args.operation)
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
