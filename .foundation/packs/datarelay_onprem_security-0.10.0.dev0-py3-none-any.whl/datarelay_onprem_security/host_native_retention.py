"""Explicitly installed systemd encrypted-backup and retention scheduler.

The installer runs as root only after an operator chooses a dedicated native
runtime owner. Scheduled work itself runs without root, without systemd/nft
privileges. All archives, keys and SQLite state are kept inside a single
owned 0700 private directory. It never accesses another product repository.
"""
from __future__ import annotations

import argparse
import json
import os
import pwd
import sqlite3
import secrets
import stat
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from .host_ssh_nft import _write_json
from .host_sqlite_backup import EncryptedSQLiteBackup, NativeBackupError

CONFIG = Path("/etc/datarelay-foundation/retention.json")
UNIT = Path("/etc/systemd/system/drf-foundation-backup-retention.service")
TIMER = Path("/etc/systemd/system/drf-foundation-backup-retention.timer")
SERVICE = UNIT.name
TIMER_NAME = TIMER.name


class RetentionInstallError(RuntimeError):
    pass


def _check_private(path: Path, uid: int, *, directory: bool):
    if not path.is_absolute() or path.is_symlink():
        raise RetentionInstallError("Private backup storage requires a real absolute path.")
    v = path.stat()
    if v.st_uid != uid or v.st_mode & 0o077:
        raise RetentionInstallError("Backup state ownership or mode is insecure.")
    if directory and not stat.S_ISDIR(v.st_mode):
        raise RetentionInstallError("Backup state must be a directory.")
    if not directory and not stat.S_ISREG(v.st_mode):
        raise RetentionInstallError("Backup state must be a regular file.")


def _read_config() -> dict:
    if CONFIG.is_symlink() or not CONFIG.is_file():
        raise RetentionInstallError("No installed Foundation backup schedule.")
    if CONFIG.stat().st_uid != 0 or CONFIG.stat().st_mode & 0o022:
        raise RetentionInstallError("Native backup schedule config is not root-owned.")
    value = json.loads(CONFIG.read_text())
    if not isinstance(value, dict) or set(value) != {
        "root", "database", "user", "keep_last", "interval_seconds"
    }:
        raise RetentionInstallError("Malformed native backup schedule.")
    if type(value["keep_last"]) is not int or not 1 <= value["keep_last"] <= 128:
        raise RetentionInstallError("Invalid installed backup count.")
    user = pwd.getpwnam(value["user"])
    if user.pw_uid == 0:
        raise RetentionInstallError("Backup schedule must never run as root.")
    root = Path(value["root"])
    _check_private(root, user.pw_uid, directory=True)
    _check_private(root / value["database"], user.pw_uid, directory=False)
    _check_private(root / "backup.key", user.pw_uid, directory=False)
    if (root / "backup.key").stat().st_size != 32:
        raise RetentionInstallError("Encryption key must be 32 bytes.")
    return value


def _run(command: list[str]) -> str:
    complete = subprocess.run(command, capture_output=True, text=True,
                              check=False, timeout=16)
    if complete.returncode:
        raise RetentionInstallError("systemd refused private retention scheduling.")
    return complete.stdout.strip()


def backup_once():
    value = _read_config()
    driver = EncryptedSQLiteBackup(value["root"], database=value["database"])
    # Lock the same SQLite writer authority that the admin API uses for policy
    # updates. Without this the schedule could delete using a stale keep_last
    # after an administrator has increased the retention limit.
    with sqlite3.connect(str(driver.source), timeout=15) as db:
        db.execute("BEGIN IMMEDIATE")
        keep_last = value["keep_last"]
        has_table = db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='policies'"
        ).fetchone()
        if has_table:
            row = db.execute(
                "SELECT value FROM policies WHERE key='host_backup_retention'"
            ).fetchone()
            if row:
                config = json.loads(row[0])
                keep_last = config.get("keepLast")
                if type(keep_last) is not int or not 1 <= keep_last <= 365:
                    raise RetentionInstallError("Persisted encrypted backup retention count is unsafe.")
        reference = datetime.now(timezone.utc).strftime(
            "backup-%Y%m%d-%H%M%S-%f-"
        ) + secrets.token_hex(4)
        receipt = driver.create(reference)
        driver.verify(receipt.reference)
        preview = driver.preview_retention(keep_last)
        removed = driver.apply_retention(preview, confirmed=True)
        result = {
            "created": reference,
            "encrypted": True,
            "sha256": receipt.sha256,
            "size": receipt.size,
            "removed": removed,
            "retained": len(driver.preview_retention(keep_last).retain),
            "keepLast": keep_last,
            "verified": True,
        }
    return result


def _create_root_file(path: Path, data: str, mode: int):
    if path.is_symlink() or path.exists():
        raise RetentionInstallError("Refusing to replace existing host policy.")
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, mode)
    try:
        with os.fdopen(fd, "w") as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
    finally:
        if os.path.isfile(path):
            os.chmod(path, mode)


def install(*, root: Path, database: str, user: str, keep_last: int, interval_seconds: int):
    if os.geteuid() != 0:
        raise RetentionInstallError("Explicit scheduler installation requires root.")
    if user != "f31foundation":
        raise RetentionInstallError("This host scheduler requires the dedicated Foundation user.")
    if not (1 <= keep_last <= 128) or not (20 <= interval_seconds <= 86400):
        raise RetentionInstallError("Unsupported backup retention or interval.")
    if not database or database.startswith(".") or "/" in database or "\\" in database:
        raise RetentionInstallError("Invalid direct child database name.")
    target = pwd.getpwnam(user)
    if target.pw_uid == 0:
        raise RetentionInstallError("Rejecting privileged backup service owner.")
    _check_private(root, target.pw_uid, directory=True)
    _check_private(root / database, target.pw_uid, directory=False)
    if CONFIG.exists() or UNIT.exists() or TIMER.exists():
        raise RetentionInstallError("Existing native schedule must never be overwritten.")
    key = root / "backup.key"
    if key.exists():
        _check_private(key, target.pw_uid, directory=False)
        if key.stat().st_size != 32:
            raise RetentionInstallError("Existing encryption key has incorrect size.")
    else:
        fd = os.open(key, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "wb") as out:
            out.write(secrets.token_bytes(32))
            out.flush()
            os.fsync(out.fileno())
        os.chown(key, target.pw_uid, target.pw_gid)
    CONFIG.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    if CONFIG.parent.is_symlink() or CONFIG.parent.stat().st_uid != 0:
        raise RetentionInstallError("Native configuration parent is insecure.")
    data = dict(root=str(root), database=database, user=user,
                keep_last=keep_last, interval_seconds=interval_seconds)
    _create_root_file(CONFIG, json.dumps(data, separators=(",", ":"), sort_keys=True)+"\n", 0o644)
    executable = Path(sys.executable)
    if not executable.is_absolute() or not executable.is_file():
        raise RetentionInstallError("Schedule requires pinned installed Python runtime.")
    payload = (
        "[Unit]\nDescription=DataRelay Foundation encrypted backup/retention\n"
        "After=local-fs.target\n"
        "[Service]\nType=oneshot\nUser=" + user + "\nGroup=" + user + "\n"
        "ExecStart=" + str(executable) + " -m datarelay_onprem_security.host_native_retention once\n"
        "UMask=0077\nNoNewPrivileges=yes\nProtectSystem=strict\n"
        "ReadWritePaths=" + str(root) + "\nPrivateTmp=yes\n"
        "ProtectHome=read-only\nCapabilityBoundingSet=\n"
    )
    timer_text = (
        "[Unit]\nDescription=DataRelay Foundation persistent backup timer\n"
        "[Timer]\nUnit=" + SERVICE + "\n"
        "OnActiveSec=10s\nOnUnitActiveSec=" + str(interval_seconds) + "s\n"
        "AccuracySec=100ms\nPersistent=true\n"
        "[Install]\nWantedBy=timers.target\n"
    )
    _create_root_file(UNIT, payload, 0o644)
    _create_root_file(TIMER, timer_text, 0o644)
    _run(["/usr/bin/systemctl", "daemon-reload"])
    _run(["/usr/bin/systemctl", "enable", "--now", TIMER_NAME])
    return dict(installed=True, user=user, keep_last=keep_last, interval_seconds=interval_seconds)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("install", "once"))
    parser.add_argument("--root", type=Path)
    parser.add_argument("--database", default="foundation-native.sqlite")
    parser.add_argument("--user", default="f31foundation")
    parser.add_argument("--keep-last", type=int, default=3)
    parser.add_argument("--interval-seconds", type=int, default=3600)
    parser.add_argument("--approved-host-install", choices=("YES",))
    args = parser.parse_args()
    if args.operation == "install":
        if args.approved_host_install != "YES" or args.root is None:
            parser.error("Host impact, root and explicit operator approval required.")
        outcome = install(root=args.root, database=args.database, user=args.user,
                          keep_last=args.keep_last, interval_seconds=args.interval_seconds)
    else:
        if args.root is not None or args.approved_host_install is not None:
            parser.error("Scheduled work reads pinned root-owned configuration only.")
        outcome = backup_once()
    print(json.dumps(outcome, sort_keys=True))


if __name__ == "__main__":
    main()
