"""Rootless isolated-network-namespace IPv4 NIC/default-route recovery lab.

Research/qualification only. This does NOT operate on a real host NIC, system
network manager, external gateway, or production interface. Every entry point
proves the active net namespace is owned by the caller's mapped user namespace.
"""
from __future__ import annotations

import fcntl
import ipaddress
import json
import os
import re
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from .host_ssh_nft import IsolatedNftError, _namespace, _read_json, _write_json

_IFACE = "drf_nic_lab0"
_ADDRESS_NET = ipaddress.IPv4Network("198.18.0.0/15")
_OPERATION = re.compile(r"nic-[0-9a-f]{20}\Z")
_BASELINE = {"address": "198.18.31.1/32", "default_route": False}


class IsolatedNicError(RuntimeError):
    """Cannot prove scoped authority, native route effect, or rescue."""


def _checked_namespace() -> str:
    try:
        return _namespace()
    except IsolatedNftError as exc:
        raise IsolatedNicError("Only an owned rootless user+network namespace is permitted.") from exc


def _cidr(value: object) -> str:
    if not isinstance(value, str) or "%" in value:
        raise IsolatedNicError("Provide a fixed laboratory IPv4 CIDR.")
    try:
        parsed = ipaddress.IPv4Interface(value)
    except ValueError as exc:
        raise IsolatedNicError("Invalid laboratory NIC address.") from exc
    if parsed.network.prefixlen != 32 or parsed.ip not in _ADDRESS_NET:
        raise IsolatedNicError("Only RFC2544 laboratory /32 addresses are permitted.")
    if str(parsed) == _BASELINE["address"]:
        return str(parsed)
    if parsed.ip in (ipaddress.IPv4Address("198.18.0.0"),
                     ipaddress.IPv4Address("198.19.255.255")):
        raise IsolatedNicError("Reserved laboratory edge addresses are forbidden.")
    return str(parsed)


def _target(value: object) -> dict:
    if (not isinstance(value, dict) or set(value) != {"address", "default_route"}
            or type(value["default_route"]) is not bool):
        raise IsolatedNicError("Only native lab address and route flag are accepted.")
    return dict(address=_cidr(value["address"]), default_route=value["default_route"])


def _ip(*args: str, allowed_failure: bool = False):
    # Defense in depth: even direct use of this low-level helper can never
    # mutate the original host network namespace.
    _checked_namespace()
    try:
        r = subprocess.run(["/usr/sbin/ip", *args], capture_output=True,
                           text=True, check=False, timeout=5)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise IsolatedNicError("Isolated kernel networking command unavailable.") from exc
    if r.returncode and not allowed_failure:
        raise IsolatedNicError("Isolated kernel networking command refused.")
    return r


class IsolatedNativeNic:
    """Single fixed dummy NIC; cannot escape Linux rootless namespace guard."""

    def __init__(self, root: str | Path):
        self.namespace = _checked_namespace()
        directory = Path(root)
        if (not directory.is_absolute() or directory.is_symlink() or not directory.is_dir()
                or directory.stat().st_uid != 0 or directory.stat().st_mode & 0o077):
            raise IsolatedNicError("Only explicit, private lab state directories are valid.")
        self.root = directory
        self.saved = directory / "confirmed.json"
        self.pending = directory / "pending.json"
        self.lockfile = directory / "lock"
        self.watchdogs: dict[int, subprocess.Popen] = {}

    def _authority(self):
        if _checked_namespace() != self.namespace:
            raise IsolatedNicError("Network namespace changed after authority verification.")

    @contextmanager
    def guard(self):
        self._authority()
        fd = os.open(self.lockfile, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    @staticmethod
    def _kernel():
        interface = json.loads(_ip("-j", "-4", "addr", "show", "dev", _IFACE).stdout)
        if len(interface) != 1 or interface[0].get("ifname") != _IFACE:
            raise IsolatedNicError("Scoped laboratory network interface disappeared.")
        addresses = [f"{row['local']}/{row['prefixlen']}" for row in interface[0].get("addr_info", [])
                     if row.get("family") == "inet"]
        routes = json.loads(_ip("-j", "-4", "route", "show", "table", "main", "default").stdout)
        return addresses, routes

    def _readback(self, expected: dict):
        expected = _target(expected)
        addresses, routes = self._kernel()
        desired_routes = ([dict(dst="default", dev=_IFACE)] if expected["default_route"] else [])
        if (addresses != [expected["address"]] or len(routes) != len(desired_routes)
                or any(r.get("dst") != "default" or r.get("dev") != _IFACE
                       or r.get("gateway") is not None for r in routes)):
            raise IsolatedNicError("Actual network address/default route diverges from native journal.")
        return dict(expected)

    def _apply(self, target: dict):
        target = _target(target)
        addresses, routes = self._kernel()
        for route in routes:
            if route.get("dst") != "default" or route.get("dev") != _IFACE:
                raise IsolatedNicError("Foreign default route was found: do not mutate.")
        for raw in addresses:
            if _cidr(raw) != raw:
                raise IsolatedNicError("Unexpected laboratory NIC address.")
        for route in routes:
            _ip("-4", "route", "del", "default", "dev", _IFACE)
        for raw in addresses:
            _ip("-4", "addr", "del", raw, "dev", _IFACE)
        _ip("-4", "addr", "add", target["address"], "dev", _IFACE)
        if target["default_route"]:
            _ip("-4", "route", "add", "default", "dev", _IFACE)
        return self._readback(target)

    @classmethod
    def install(cls, root: str | Path):
        _checked_namespace()
        path = Path(root)
        if not path.is_absolute() or path.exists() or path.is_symlink():
            raise IsolatedNicError("Refusing to overwrite an isolated lab installation.")
        if _ip("-j", "link", "show", "dev", _IFACE, allowed_failure=True).returncode == 0:
            raise IsolatedNicError("Refusing to claim a pre-existing NIC.")
        path.mkdir(mode=0o700)
        os.chmod(path, 0o700)
        instance = cls(path)
        with instance.guard():
            _ip("link", "add", _IFACE, "type", "dummy")
            _ip("link", "set", _IFACE, "up")
            _ip("-4", "addr", "add", _BASELINE["address"], "dev", _IFACE)
            instance._readback(_BASELINE)
            _write_json(instance.saved, _BASELINE)
        return instance

    def status(self):
        for pid, child in list(self.watchdogs.items()):
            if child.poll() is not None:
                child.wait()
                self.watchdogs.pop(pid, None)
        with self.guard():
            current = _read_json(self.pending)["target"] if self.pending.exists() else _read_json(self.saved)
            self._readback(current)
            return dict(active=current, pending=self.pending.exists())

    def stage(self, operation: str, target: dict, *, seconds: int = 12):
        if not isinstance(operation, str) or not _OPERATION.fullmatch(operation):
            raise IsolatedNicError("Invalid laboratory operation token.")
        if type(seconds) is not int or not 10 <= seconds <= 120:
            raise IsolatedNicError("Independent recovery deadline must be 10–120 seconds.")
        proposed = _target(target)
        with self.guard():
            if self.pending.exists():
                raise IsolatedNicError("Only one native NIC mutation may be staged.")
            previous = _read_json(self.saved)
            self._readback(previous)
            if previous == proposed:
                raise IsolatedNicError("Target equals existing NIC state.")
            pending = dict(operation=operation, previous=previous,
                           target=proposed, expires_at=time.time()+seconds, phase="staged")
            _write_json(self.pending, pending)
            watcher = subprocess.Popen([
                sys.executable, "-m", "datarelay_onprem_security.host_lab_nic",
                "watchdog", "--state-root", str(self.root),
                "--operation", operation, "--delay", str(seconds)],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, close_fds=True, start_new_session=True)
            self.watchdogs[watcher.pid] = watcher
            if watcher.poll() is not None:
                raise IsolatedNicError("Independent lab NIC watchdog did not start.")
            try:
                self._apply(proposed)
            except Exception:
                # Keep the durable pending journal and independent recovery.
                raise
            return dict(operation=operation, active=proposed, pending=True)

    def confirm(self, operation: str):
        with self.guard():
            p = self._owned(operation)
            if time.time() >= p["expires_at"] or p["phase"] != "staged":
                raise IsolatedNicError("NIC stage expired or was already confirmed.")
            self._readback(p["target"])
            p["phase"] = "committed"
            _write_json(self.pending, p)
            _write_json(self.saved, p["target"])
            self.pending.unlink()
            # Lab watcher's later run sees no pending, reads confirmed state.
            return dict(active=p["target"], pending=False)

    def _owned(self, operation: str):
        if not isinstance(operation, str) or not _OPERATION.fullmatch(operation):
            raise IsolatedNicError("Invalid scoped NIC operation token.")
        value = _read_json(self.pending)
        if value["operation"] != operation:
            raise IsolatedNicError("Native NIC operation ownership mismatch.")
        return value

    def rollback(self, operation: str):
        with self.guard():
            if not self.pending.exists():
                state = _read_json(self.saved)
                self._readback(state)
                return dict(active=state, pending=False)
            p = self._owned(operation)
            if p["phase"] == "committed":
                self._readback(p["target"])
                _write_json(self.saved, p["target"])
                self.pending.unlink()
                return dict(active=p["target"], pending=False, committed=True)
            restored = self._apply(p["previous"])
            _write_json(self.saved, restored)
            self.pending.unlink()
            return dict(active=restored, pending=False, committed=False)

    def stop_lab(self):
        with self.guard():
            if self.pending.exists():
                raise IsolatedNicError("Cannot dismantle a pending native recovery lease.")
            current = _read_json(self.saved)
            self._readback(current)
            if current["default_route"]:
                _ip("-4", "route", "del", "default", "dev", _IFACE)
            _ip("link", "del", _IFACE)
        for child in list(self.watchdogs.values()):
            if child.poll() is None:
                child.terminate()
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired as exc:
                raise IsolatedNicError("Independent laboratory watchdog did not stop.") from exc
        self.watchdogs.clear()


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("watchdog",))
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--operation", required=True)
    parser.add_argument("--delay", type=int, required=True)
    args = parser.parse_args()
    if not 10 <= args.delay <= 120:
        raise IsolatedNicError("Watchdog delay out of lab bounds.")
    _checked_namespace()
    time.sleep(args.delay)
    result = IsolatedNativeNic(args.state_root).rollback(args.operation)
    print(json.dumps(result, separators=(",", ":"), sort_keys=True))


if __name__ == "__main__":
    main()
