"""SQLite-backed, same-origin common auth/MFA/RBAC/session/Web-ACL runtime.

Opt-in embedded deployment for consumers that do not have a native identity service.
No HTTP mock, no in-memory success path. SSH changes fail closed until host enforcement
is installed; do not mistake an API allowlist for host firewall/sshd enforcement.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from http.cookies import SimpleCookie
from pathlib import Path
from threading import RLock
from typing import Any
from urllib.parse import urlparse

from .totp import code_at, new_totp_secret, provisioning_uri, verify_totp
from .acl import canonical_network, resolve_web_source

PERMISSIONS = (
    "mfa.read", "mfa.manage", "acl.read", "acl.manage",
    "roles.read", "roles.manage", "sessions.read", "sessions.manage",
)
DEFAULT_ROLES = (
    ("ADMINISTRATOR", "Administrator", list(PERMISSIONS), False),
    ("OPERATOR", "Operator", ["mfa.read", "acl.read", "roles.read", "sessions.read"], True),
    ("VIEWER", "Viewer", ["mfa.read", "roles.read"], True),
)
COOKIE = "drf_session"
MAX_BODY = 16_384


class HttpFailure(Exception):
    def __init__(self, status: int, message: str, *, persist: bool = False):
        super().__init__(message)
        self.status = status
        self.persist = persist


def _password_hash(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 480_000).hex()


def _cidrs(values: Any, *, empty: bool = False) -> list[str]:
    if not isinstance(values, list) or len(values) > 64 or (not empty and not values):
        raise HttpFailure(400, "A nonempty list of at most 64 CIDRs is required.")
    result = []
    for value in values:
        if not isinstance(value, str) or not value or len(value) > 64:
            raise HttpFailure(400, "Invalid management access CIDR.")
        try:
            network = ipaddress.ip_network(value, strict=False)
        except ValueError as exc:
            raise HttpFailure(400, "Invalid management access CIDR.") from exc
        if network.prefixlen == 0:
            raise HttpFailure(400, "Unrestricted management access is not allowed.")
        result.append(str(network))
    if len(set(result)) != len(result):
        raise HttpFailure(400, "Duplicate management access CIDR.")
    return result


def _client_allowed(client: str, cidrs: list[str]) -> bool:
    try:
        source = ipaddress.ip_address(client)
        return any(source in ipaddress.ip_network(c) for c in cidrs)
    except (ValueError, TypeError):
        return False


def _utc(ts: float) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).isoformat().replace("+00:00", "Z")


class EmbeddedFoundationRuntime:
    """Create once per ASGI process. All privileged reads/writes occur in SQLite transactions.

    Host configuration is explicit: HTTPS ingress must be terminated by the product
    or service proxy; this runtime rejects credential-bearing cross-origin requests.
    """
    def __init__(self, database: str | Path, *, origin: str, cookie_secure: bool = True,
                 trusted_proxy_cidrs: tuple[str, ...] = (), native_ssh=None, native_lifecycle=None,
                 native_https=None, native_ingress=None,
                 native_ingress_migrate_origin: bool = False):
        parsed = urlparse(origin)
        if parsed.scheme not in ("http", "https") or not parsed.netloc or parsed.path not in ("", "/"):
            raise ValueError("A full origin is required.")
        if parsed.scheme != "https" and cookie_secure:
            raise ValueError("Secure cookies require an HTTPS origin.")
        if parsed.scheme == "http" and parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
            raise ValueError("Insecure HTTP is permitted on loopback only.")
        if type(native_ingress_migrate_origin) is not bool:
            raise ValueError("Explicit Boolean native ingress origin migration setting required.")
        if native_ingress_migrate_origin and (
                native_ingress is None or parsed.scheme != "https"
                or parsed.hostname != "127.0.0.1"
                or parsed.port is None or not 1024 <= parsed.port <= 65535
                or origin.rstrip("/") != f"https://127.0.0.1:{parsed.port}"):
            raise ValueError("Origin migration requires a pinned HTTPS loopback ingress gateway.")
        self.origin = origin.rstrip("/")
        self.native_ingress_migrate_origin = native_ingress_migrate_origin
        self.cookie_secure = cookie_secure
        if not isinstance(trusted_proxy_cidrs, tuple) or len(trusted_proxy_cidrs) > 32:
            raise ValueError("Invalid trusted-proxy configuration.")
        self.trusted_proxy_cidrs = tuple(canonical_network(c) for c in trusted_proxy_cidrs)
        self.database = Path(database)
        self.native_ssh = native_ssh  # Explicit opt-in privileged helper; None => 503.
        self.native_lifecycle = native_lifecycle  # Optional private AES-GCM SQLite authority.
        self.native_https = native_https  # Real observed external TLS, never mutation authority.
        self.native_ingress = native_ingress  # Opt-in, fixed privileged proxy gateway.
        self.started_at = time.time()
        self.lock = RLock()
        if not self.database.is_file():
            raise ValueError("Initialize the database with bootstrap_admin before starting.")
        if self.database.stat().st_mode & 0o077:
            raise ValueError("Security database must be private (0600).")

    @staticmethod
    def _connect(database: Path) -> sqlite3.Connection:
        c = sqlite3.connect(str(database), timeout=10)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=10000")
        return c

    @classmethod
    def bootstrap_admin(
        cls, database: str | Path, username: str, password: str,
        *, initial_web_cidrs: tuple[str, ...] = (),
    ) -> None:
        if not isinstance(initial_web_cidrs, tuple):
            raise ValueError("An immutable initial Web CIDR list is required.")
        try:
            web_allowlist = _cidrs(["127.0.0.1/32", "::1/128", *initial_web_cidrs])
        except HttpFailure as exc:
            raise ValueError("Initial Web access policy is invalid: "+str(exc)) from exc
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{1,63}", username):
            raise ValueError("Invalid administrator username.")
        if len(password) < 12 or len(password) > 256:
            raise ValueError("Administrator password must contain 12–256 characters.")
        path = Path(database)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            raise ValueError("Database already exists; refusing to overwrite credentials.")
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        try:
            with cls._connect(path) as c:
                c.executescript("""
                CREATE TABLE users (
                  name TEXT PRIMARY KEY, salt TEXT NOT NULL, password_hash TEXT NOT NULL,
                  role TEXT NOT NULL, mfa_secret TEXT, mfa_counter INTEGER,
                  mfa_pending TEXT, pending_ref TEXT, pending_until INTEGER,
                  mfa_revision INTEGER NOT NULL DEFAULT 1,
                  recovery_hashes TEXT NOT NULL DEFAULT '[]',
                  created_at INTEGER NOT NULL DEFAULT 0,
                  last_login INTEGER,
                  status TEXT NOT NULL DEFAULT 'ACTIVE',
                  timezone TEXT
                );
                CREATE TABLE sessions (
                  id TEXT PRIMARY KEY, user_name TEXT NOT NULL, csrf TEXT NOT NULL,
                  created INTEGER NOT NULL, last_seen INTEGER NOT NULL,
                  expires INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0,
                  factor_verified INTEGER NOT NULL DEFAULT 0,
                  FOREIGN KEY(user_name) REFERENCES users(name)
                );
                CREATE TABLE challenges (
                  id TEXT PRIMARY KEY, user_name TEXT NOT NULL, expires INTEGER NOT NULL,
                  attempts INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE policies (key TEXT PRIMARY KEY, value TEXT NOT NULL, revision INTEGER NOT NULL);
                CREATE TABLE previews (
                  id TEXT PRIMARY KEY, kind TEXT NOT NULL, owner TEXT NOT NULL,
                  revision TEXT NOT NULL, value TEXT NOT NULL, expires INTEGER NOT NULL
                );
                CREATE TABLE audit (
                  id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL,
                  actor TEXT NOT NULL, operation TEXT NOT NULL, detail TEXT NOT NULL
                );
                CREATE TABLE login_failures (
                  subject TEXT PRIMARY KEY, count INTEGER NOT NULL, until INTEGER NOT NULL
                );
                """)
                salt = secrets.token_bytes(24)
                c.execute("INSERT INTO users(name,salt,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                          (username, salt.hex(), _password_hash(password, salt), "ADMINISTRATOR", int(time.time())))
                for role_id, label, permissions, mutable in DEFAULT_ROLES:
                    c.execute("INSERT INTO policies(key,value,revision) VALUES(?,?,1)",
                              ("role:"+role_id, json.dumps(dict(label=label, permissions=permissions, mutable=mutable))))
                c.execute("INSERT INTO policies(key,value,revision) VALUES('acl',?,1)",
                          (json.dumps(dict(webCidrs=web_allowlist, sshCidrs=[])),))
                c.execute("INSERT INTO policies(key,value,revision) VALUES('sessions','{}',1)")
                c.execute("INSERT INTO policies(key,value,revision) VALUES('display',?,1)",
                          (json.dumps(dict(default_timezone="UTC")),))
                c.execute("INSERT INTO audit(at,actor,operation,detail) VALUES(?,?,?,?)",
                          (int(time.time()), username, "runtime.bootstrap", "{}"))
        except Exception:
            path.unlink(missing_ok=True)
            raise

    @classmethod
    def add_account(cls, database: str | Path, username: str, password: str, *, role: str) -> None:
        if role not in ("OPERATOR", "VIEWER") or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{1,63}", username):
            raise ValueError("Invalid restricted account.")
        if len(password) < 12 or len(password) > 256:
            raise ValueError("Password must contain 12–256 characters.")
        salt = secrets.token_bytes(24)
        with cls._connect(Path(database)) as c:
            c.execute("INSERT INTO users(name,salt,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                      (username, salt.hex(), _password_hash(password, salt), role, int(time.time())))

    @staticmethod
    def _rev(row: sqlite3.Row, prefix: str) -> str:
        return prefix + "-" + str(row["revision"])

    @staticmethod
    def _policy(c: sqlite3.Connection, key: str) -> sqlite3.Row:
        row = c.execute("SELECT * FROM policies WHERE key=?", (key,)).fetchone()
        if row is None:
            raise HttpFailure(503, "Required security policy is missing.")
        return row

    @staticmethod
    def _user(c: sqlite3.Connection, name: str) -> sqlite3.Row:
        row = c.execute("SELECT * FROM users WHERE name=?", (name,)).fetchone()
        if row is None:
            raise HttpFailure(401, "Not authenticated.")
        return row

    @staticmethod
    def _audit(c: sqlite3.Connection, actor: str, operation: str, detail: dict[str, Any]) -> None:
        c.execute("INSERT INTO audit(at,actor,operation,detail) VALUES(?,?,?,?)",
                  (int(time.time()), actor, operation, json.dumps(detail, sort_keys=True)))

    @staticmethod
    def _principal(c: sqlite3.Connection, headers: dict[str, str], now: int):
        token = ""
        try:
            jar = SimpleCookie()
            jar.load(headers.get("cookie", ""))
            token = jar[COOKIE].value if COOKIE in jar else ""
        except Exception:
            pass
        if not token:
            return None
        key = hashlib.sha256(token.encode("ascii", errors="ignore")).hexdigest()
        row = c.execute("""SELECT s.* FROM sessions s JOIN users u
                           ON s.user_name=u.name WHERE s.id=? AND s.revoked=0
                           AND s.expires>? AND u.status='ACTIVE'""",
                        (key, now)).fetchone()
        return row

    @staticmethod
    def _permission(c: sqlite3.Connection, session: sqlite3.Row | None, permission: str) -> str:
        if session is None:
            raise HttpFailure(401, "Sign in to continue.")
        user = EmbeddedFoundationRuntime._user(c, session["user_name"])
        role = user["role"]
        if role == "ADMINISTRATOR":
            return user["name"]
        row = EmbeddedFoundationRuntime._policy(c, "role:"+role)
        if permission not in json.loads(row["value"])["permissions"]:
            raise HttpFailure(403, "You do not have permission to perform this operation.")
        return user["name"]

    @staticmethod
    def _csrf(session: sqlite3.Row | None, headers: dict[str, str]):
        if session is None:
            raise HttpFailure(401, "Sign in to continue.")
        if not hmac.compare_digest(session["csrf"], headers.get("x-foundation-csrf", "")):
            raise HttpFailure(403, "Invalid CSRF token.")

    @staticmethod
    def _require_revision(actual: str, supplied: Any):
        if not isinstance(supplied, str) or not hmac.compare_digest(actual, supplied):
            raise HttpFailure(409, "Security configuration revision changed.")

    def _new_session(self, c: sqlite3.Connection, name: str, now: int, verified: bool):
        token = secrets.token_urlsafe(32)
        key = hashlib.sha256(token.encode()).hexdigest()
        c.execute("INSERT INTO sessions(id,user_name,csrf,created,last_seen,expires,factor_verified) VALUES(?,?,?,?,?,?,?)",
                  (key, name, secrets.token_urlsafe(32), now, now, now+3600, int(verified)))
        return token

    def _cookie(self, token: str, *, clear: bool = False) -> str:
        secure = "; Secure" if self.cookie_secure else ""
        if clear:
            return f"{COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0{secure}"
        return f"{COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=3600{secure}"

    def _roles(self, c: sqlite3.Connection):
        rows = c.execute("SELECT * FROM policies WHERE key LIKE 'role:%' ORDER BY key").fetchall()
        revision = max(r["revision"] for r in rows)
        return dict(revision="roles-"+str(revision), roles=[
            dict(id=r["key"][5:], **json.loads(r["value"])) for r in rows
        ], availablePermissions=list(PERMISSIONS))

    def _mfa(self, c: sqlite3.Connection, name: str):
        u = self._user(c, name)
        return dict(revision="mfa-"+str(u["mfa_revision"]), enrolled=bool(u["mfa_secret"]),
                    required=False, recoveryCodesRemaining=len(json.loads(u["recovery_hashes"])))

    def _acl(self, c: sqlite3.Connection):
        row = self._policy(c, "acl")
        value = json.loads(row["value"])
        if self.native_ssh is not None:
            try:
                native = self.native_ssh.status()
                pending = value.get("sshPending")
                if pending:
                    if native["pending"]:
                        if (native["operation"] != pending["operation"]
                                or native["sources"] != value["sshCidrs"]):
                            raise HttpFailure(503, "Native SSH operation has diverged.")
                    elif native["confirmedSources"] == value["sshCidrs"]:
                        # Privileged confirm succeeded just before SQLite commit failure:
                        # reconcile idempotently from exact native readback.
                        value.pop("sshPending")
                        c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key='acl'",
                                  (json.dumps(value),))
                    elif native["confirmedSources"] == pending["previous"]["sshCidrs"]:
                        # Independent timer or reboot recovered previous kernel policy.
                        # Roll back both SQL Web/SSH changes; never claim false PASS.
                        value = pending["previous"]
                        c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key='acl'",
                                  (json.dumps(value),))
                        self._audit(c, "native-host", "acl.ssh.rollback", {})
                    else:
                        raise HttpFailure(503, "Native SSH rollback does not match durable policy.")
                elif native["pending"]:
                    # Process died after privileged stage but before SQLite commit.
                    # Revert the orphaned kernel change independently.
                    self.native_ssh.rollback(native["operation"])
                    if self.native_ssh.status()["confirmedSources"] != value["sshCidrs"]:
                        raise HttpFailure(503, "Orphaned native SSH policy recovery failed.")
                elif native["confirmedSources"] != value["sshCidrs"]:
                    raise HttpFailure(503, "SQLite and kernel SSH policies disagree.")
            except HttpFailure:
                raise
            except Exception as exc:
                raise HttpFailure(503, "Native SSH readback or reconciliation failed.") from exc
            row = self._policy(c, "acl")
        return dict(revision=self._rev(row, "acl"), **value)

    def _sessions(self, c: sqlite3.Connection, session: sqlite3.Row, now: int):
        row = self._policy(c, "sessions")
        rows = c.execute("""SELECT * FROM sessions WHERE revoked=0 AND expires>?
                             ORDER BY created DESC LIMIT 200""", (now,)).fetchall()
        return dict(revision=self._rev(row, "sessions"), sessions=[
            dict(id=r["id"], principal=r["user_name"], createdAt=_utc(r["created"]),
                 lastSeenAt=_utc(r["last_seen"]), current=r["id"]==session["id"],
                 revocable=r["id"]!=session["id"]) for r in rows
        ])

    @staticmethod
    def _preview(c: sqlite3.Connection, kind: str, owner: str, revision: str, value: dict[str, Any], now: int):
        ref = "preview-"+secrets.token_hex(18)
        c.execute("INSERT INTO previews(id,kind,owner,revision,value,expires) VALUES(?,?,?,?,?,?)",
                  (ref, kind, owner, revision, json.dumps(value), now+90))
        return dict(previewRef=ref, expectedRevision=revision, safe=True, expiresAt=(now+90)*1000)

    @staticmethod
    def _consume_preview(c: sqlite3.Connection, kind: str, owner: str, revision: str, body: dict[str, Any], now: int):
        ref = body.get("previewRef")
        if body.get("confirm") is not True or not isinstance(ref, str):
            raise HttpFailure(400, "Explicit confirmation is required.")
        row = c.execute("SELECT * FROM previews WHERE id=? AND kind=? AND owner=? AND revision=? AND expires>?",
                        (ref, kind, owner, revision, now)).fetchone()
        if row is None:
            raise HttpFailure(409, "Expired, foreign, or stale security preview.")
        c.execute("DELETE FROM previews WHERE id=?", (ref,))
        return json.loads(row["value"])

    def _dispatch(self, c: sqlite3.Connection, method: str, path: str, body: dict[str, Any],
                  headers: dict[str, str], session: sqlite3.Row | None, client: str, now: int):
        if path.startswith("/api/v1/"):
            from .embedded_control_admin import dispatch_control_admin
            return dispatch_control_admin(self, c, method, path, body, headers, session, now)
        if path.startswith("/api/foundation/host/"):
            from .embedded_lifecycle_api import dispatch_lifecycle
            return dispatch_lifecycle(self, c, method, path, body, headers, session, now)
        token = None
        if path == "/api/foundation/auth/login" and method == "POST":
            name, password = body.get("username"), body.get("password")
            if not isinstance(name, str) or not isinstance(password, str):
                raise HttpFailure(400, "Enter your username and password.")
            subject = hashlib.sha256((name+"|"+client).encode()).hexdigest()
            failures = c.execute("SELECT * FROM login_failures WHERE subject=?", (subject,)).fetchone()
            if failures and failures["count"] >= 5 and failures["until"] > now:
                raise HttpFailure(429, "Too many sign-in attempts.")
            user = c.execute("SELECT * FROM users WHERE name=?", (name,)).fetchone()
            salt = bytes.fromhex(user["salt"]) if user else b"0"*24
            valid = hmac.compare_digest(_password_hash(password, salt),
                                        user["password_hash"] if user else "0"*64)
            if valid and user["status"] != "ACTIVE":
                valid = False
            if not valid:
                count = 1 if not failures or failures["until"] < now else failures["count"]+1
                c.execute("INSERT OR REPLACE INTO login_failures VALUES(?,?,?)",
                          (subject, count, now+120))
                raise HttpFailure(401, "Invalid username or password.", persist=True)
            c.execute("DELETE FROM login_failures WHERE subject=?", (subject,))
            if user["mfa_secret"]:
                challenge = "challenge-"+secrets.token_hex(20)
                c.execute("INSERT INTO challenges(id,user_name,expires) VALUES(?,?,?)",
                          (hashlib.sha256(challenge.encode()).hexdigest(), name, now+300))
                methods = ["totp"] + (["recovery"] if json.loads(user["recovery_hashes"]) else [])
                return 200, dict(state="mfa_required", challengeRef=challenge, methods=methods), None
            c.execute("UPDATE users SET last_login=? WHERE name=?", (now, name))
            token = self._new_session(c, name, now, False)
            return 200, dict(state="authenticated"), self._cookie(token)
        if path == "/api/foundation/auth/otp" and method == "POST":
            challenge, code = body.get("challengeRef"), body.get("code")
            if not isinstance(challenge, str) or not isinstance(code, str):
                raise HttpFailure(400, "Invalid MFA verification request.")
            ch = c.execute("SELECT * FROM challenges WHERE id=? AND expires>?",
                           (hashlib.sha256(challenge.encode()).hexdigest(), now)).fetchone()
            if ch is None or ch["attempts"] >= 5:
                raise HttpFailure(401, "Expired or rejected MFA challenge.")
            user = self._user(c, ch["user_name"])
            if user["status"] != "ACTIVE" or not user["mfa_secret"]:
                raise HttpFailure(401, "The authenticator challenge is no longer valid.")
            counter = verify_totp(user["mfa_secret"], code, now=now, last_counter=user["mfa_counter"])
            recovery_hashes = json.loads(user["recovery_hashes"])
            used_recovery = None
            if counter is None and re.fullmatch(r"[0-9a-f]{24}", code, re.ASCII | re.IGNORECASE):
                supplied = hashlib.sha256(code.lower().encode("ascii")).hexdigest()
                used_recovery = next((index for index, digest in enumerate(recovery_hashes)
                                      if hmac.compare_digest(supplied, digest)), None)
            if counter is None and used_recovery is None:
                c.execute("UPDATE challenges SET attempts=attempts+1 WHERE id=?", (ch["id"],))
                raise HttpFailure(401, "Invalid or reused authenticator code.", persist=True)
            if used_recovery is None:
                c.execute("UPDATE users SET mfa_counter=? WHERE name=?", (counter, user["name"]))
            else:
                recovery_hashes.pop(used_recovery)
                c.execute("UPDATE users SET recovery_hashes=? WHERE name=?",
                          (json.dumps(recovery_hashes), user["name"]))
                self._audit(c, user["name"], "mfa.recovery.used", {"remaining": len(recovery_hashes)})
            c.execute("DELETE FROM challenges WHERE id=?", (ch["id"],))
            c.execute("UPDATE users SET last_login=? WHERE name=?", (now, user["name"]))
            token = self._new_session(c, user["name"], now, True)
            return 200, dict(state="authenticated"), self._cookie(token)
        if path == "/api/foundation/session" and method == "GET":
            if session is None:
                return 200, dict(authenticated=False), None
            user = self._user(c, session["user_name"])
            permissions = (list(PERMISSIONS) if user["role"] == "ADMINISTRATOR"
                           else json.loads(self._policy(c, "role:"+user["role"])["value"])["permissions"])
            return 200, dict(authenticated=True, csrf=session["csrf"],
                user=dict(username=user["name"], role=user["role"], status="ACTIVE",
                          capabilities={name: name in permissions for name in PERMISSIONS}),
                expiresAt=_utc(session["expires"])), None
        if path == "/api/foundation/auth/logout" and method == "POST":
            self._csrf(session, headers)
            c.execute("UPDATE sessions SET revoked=1 WHERE id=?", (session["id"],))
            self._audit(c, session["user_name"], "auth.logout", {})
            return 200, dict(ok=True), self._cookie("", clear=True)
        if path == "/api/foundation/mfa" and method == "GET":
            name = self._permission(c, session, "mfa.read")
            return 200, self._mfa(c, name), None
        if path == "/api/foundation/mfa/begin" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "mfa.manage")
            user = self._user(c, name)
            self._require_revision(self._mfa(c, name)["revision"], body.get("expectedRevision"))
            if user["mfa_secret"]:
                raise HttpFailure(409, "MFA is already enrolled.")
            secret = new_totp_secret()
            ref = "enroll-"+secrets.token_hex(20)
            c.execute("UPDATE users SET mfa_pending=?, pending_ref=?, pending_until=? WHERE name=?",
                      (secret, hashlib.sha256(ref.encode()).hexdigest(), now+600, name))
            uri = provisioning_uri(secret, issuer="DataRelay", account=name)
            return 200, dict(enrollmentRef=ref, expectedRevision=body["expectedRevision"],
                             secret=secret, otpauthUri=uri), None
        if path == "/api/foundation/mfa/confirm" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "mfa.manage")
            u = self._user(c, name)
            self._require_revision(self._mfa(c, name)["revision"], body.get("expectedRevision"))
            ref = body.get("enrollmentRef")
            if not u["mfa_pending"] or u["pending_until"] < now or not isinstance(ref, str) or not hmac.compare_digest(u["pending_ref"], hashlib.sha256(ref.encode()).hexdigest()):
                raise HttpFailure(409, "MFA enrollment expired.")
            counter = verify_totp(u["mfa_pending"], body.get("code"), now=now)
            if counter is None:
                raise HttpFailure(400, "Invalid authenticator code.")
            codes = [secrets.token_hex(12) for _ in range(8)]
            digests = [hashlib.sha256(v.encode()).hexdigest() for v in codes]
            c.execute("""UPDATE users SET mfa_secret=mfa_pending, mfa_counter=?,
                mfa_pending=NULL,pending_ref=NULL,pending_until=NULL,mfa_revision=mfa_revision+1,
                recovery_hashes=? WHERE name=?""", (counter, json.dumps(digests), name))
            c.execute("UPDATE sessions SET revoked=1 WHERE user_name=? AND id!=?", (name, session["id"]))
            c.execute("UPDATE sessions SET factor_verified=1 WHERE id=?", (session["id"],))
            self._audit(c, name, "mfa.enrolled", {})
            return 200, dict(**self._mfa(c, name), recoveryCodes=codes), None
        if path == "/api/foundation/mfa/disable" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "mfa.manage")
            self._require_revision(self._mfa(c, name)["revision"], body.get("expectedRevision"))
            if body.get("confirm") is not True or not session["factor_verified"]:
                raise HttpFailure(403, "A confirmed, factor-verified session is required.")
            c.execute("""UPDATE users SET mfa_secret=NULL,mfa_counter=NULL,mfa_pending=NULL,
                pending_ref=NULL,pending_until=NULL,mfa_revision=mfa_revision+1,recovery_hashes='[]'
                WHERE name=?""", (name,))
            self._audit(c, name, "mfa.disabled", {})
            return 200, self._mfa(c, name), None
        if path == "/api/foundation/acl" and method == "GET":
            self._permission(c, session, "acl.read")
            return 200, self._acl(c), None
        if path == "/api/foundation/acl/preview" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "acl.manage")
            before = self._acl(c)
            self._require_revision(before["revision"], body.get("expectedRevision"))
            web = _cidrs(body.get("webCidrs"))
            ssh = _cidrs(body.get("sshCidrs"), empty=True)
            if before.get("sshPending"):
                raise HttpFailure(409, "Confirm or recover the previous SSH operation first.")
            if ssh != before["sshCidrs"]:
                if self.native_ssh is None:
                    raise HttpFailure(503, "SSH native host enforcement is not installed; changes are refused.")
                if not ssh:
                    raise HttpFailure(400, "Host SSH policy requires a rescue CIDR.")
                native = self.native_ssh.status()
                if native["pending"] or native["confirmedSources"] != before["sshCidrs"]:
                    raise HttpFailure(503, "Host SSH baseline does not match durable policy.")
                if native["port"] < 1024:
                    raise HttpFailure(503, "Native SSH port is not a designated management port.")
                if not _client_allowed(client, ssh):
                    raise HttpFailure(409, "New SSH policy excludes the current management source.")
            if not _client_allowed(client, web):
                raise HttpFailure(409, "Management access change would lock out the current peer.")
            return 200, dict(**self._preview(c, "acl", name, before["revision"],
                                  dict(webCidrs=web, sshCidrs=ssh), now), lockoutRisk=False), None
        if path == "/api/foundation/acl/apply" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "acl.manage")
            old = self._acl(c)
            self._require_revision(old["revision"], body.get("expectedRevision"))
            if old.get("sshPending"):
                raise HttpFailure(409, "A native SSH change already awaits confirmation.")
            value = self._consume_preview(c, "acl", name, old["revision"], body, now)
            if not _client_allowed(client, value["webCidrs"]):
                raise HttpFailure(409, "Current Web management client would lose access.")
            native_change = value["sshCidrs"] != old["sshCidrs"]
            if native_change:
                if self.native_ssh is None:
                    raise HttpFailure(503, "Native SSH host management is unavailable.")
                operation = "op-"+secrets.token_hex(10)
                try:
                    staged = self.native_ssh.stage(operation, value["sshCidrs"])
                    if staged["operation"] != operation or staged["sources"] != value["sshCidrs"]:
                        raise ValueError("Native SSH apply acknowledgement mismatched.")
                except Exception as exc:
                    # An independently armed rollback still runs if this process crashes.
                    raise HttpFailure(503, "Native SSH apply/readback could not be proven.") from exc
                value["sshPending"] = dict(operation=operation,
                    previous=dict(webCidrs=old["webCidrs"], sshCidrs=old["sshCidrs"]),
                    expiresAt=staged["expiresAt"])
            c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key='acl'",
                      (json.dumps(value),))
            self._audit(c, name, "acl.native.staged" if native_change else "acl.web.applied",
                        dict(webCidrs=value["webCidrs"], sshCidrs=value["sshCidrs"]))
            return 200, self._acl(c), None
        if path == "/api/foundation/acl/confirm" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "acl.manage")
            old = self._acl(c)
            self._require_revision(old["revision"], body.get("expectedRevision"))
            pending = old.get("sshPending")
            if (not pending or body.get("confirm") is not True
                    or body.get("operation") != pending["operation"]):
                raise HttpFailure(409, "No matching pending SSH change to confirm.")
            if self.native_ssh is None:
                raise HttpFailure(503, "Privileged SSH authority is unavailable.")
            try:
                confirmed = self.native_ssh.confirm(pending["operation"])
            except Exception as exc:
                raise HttpFailure(503, "SSH kernel confirmation is unverified.") from exc
            if confirmed["pending"] or confirmed["confirmedSources"] != old["sshCidrs"]:
                raise HttpFailure(503, "Native SSH kernel did not confirm the applied CIDRs.")
            old.pop("sshPending")
            c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key='acl'",
                      (json.dumps(dict(webCidrs=old["webCidrs"], sshCidrs=old["sshCidrs"])),))
            self._audit(c, name, "acl.ssh.confirmed", {"sshCidrs": old["sshCidrs"]})
            return 200, self._acl(c), None
        if path == "/api/foundation/roles" and method == "GET":
            self._permission(c, session, "roles.read")
            return 200, self._roles(c), None
        if path == "/api/foundation/roles/preview" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "roles.manage")
            old = self._roles(c)
            self._require_revision(old["revision"], body.get("expectedRevision"))
            role = body.get("roleId")
            permissions = body.get("permissions")
            selected = next((r for r in old["roles"] if r["id"] == role), None)
            if not selected or not selected["mutable"] or not isinstance(permissions, list) or len(set(map(str,permissions))) != len(permissions) or any(p not in PERMISSIONS for p in permissions):
                raise HttpFailure(400, "Immutable role or invalid permissions.")
            return 200, self._preview(c, "roles", name, old["revision"],
                                      dict(roleId=role, permissions=permissions), now), None
        if path == "/api/foundation/roles/apply" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "roles.manage")
            old = self._roles(c)
            self._require_revision(old["revision"], body.get("expectedRevision"))
            value = self._consume_preview(c, "roles", name, old["revision"], body, now)
            role_id = value["roleId"]
            if role_id == "ADMINISTRATOR":
                raise HttpFailure(403, "Administrator role is immutable.")
            existing = self._policy(c, "role:"+role_id)
            mutable = json.loads(existing["value"])
            if mutable["mutable"] is not True:
                raise HttpFailure(403, "Role is immutable.")
            mutable["permissions"] = value["permissions"]
            c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key=?",
                      (json.dumps(mutable), "role:"+role_id))
            # Keep a coherent global policy revision across roles.
            c.execute("UPDATE policies SET revision=revision+1 WHERE key LIKE 'role:%' AND key!=?",
                      ("role:"+role_id,))
            self._audit(c, name, "roles.updated", value)
            return 200, self._roles(c), None
        if path == "/api/foundation/sessions" and method == "GET":
            self._permission(c, session, "sessions.read")
            return 200, self._sessions(c, session, now), None
        if path == "/api/foundation/sessions/revoke" and method == "POST":
            self._csrf(session, headers)
            name = self._permission(c, session, "sessions.manage")
            old = self._sessions(c, session, now)
            self._require_revision(old["revision"], body.get("expectedRevision"))
            target = body.get("sessionId")
            if not isinstance(target, str) or target == session["id"]:
                raise HttpFailure(403, "Current session cannot be revoked in this view.")
            row = c.execute("SELECT * FROM sessions WHERE id=? AND revoked=0", (target,)).fetchone()
            if row is None:
                raise HttpFailure(404, "Session does not exist.")
            if body.get("confirm") is not True:
                raise HttpFailure(400, "Explicit confirmation is required.")
            c.execute("UPDATE sessions SET revoked=1 WHERE id=?", (target,))
            c.execute("UPDATE policies SET revision=revision+1 WHERE key='sessions'")
            self._audit(c, name, "sessions.revoked", dict(principal=row["user_name"], sessionRef=target))
            return 200, dict(revision=self._sessions(c, session, now)["revision"]), None
        raise HttpFailure(404, "Unknown Foundation security endpoint.")

    def _require_mutation_origin(self, headers: dict[str, str]) -> None:
        if not self.native_ingress_migrate_origin:
            if headers.get("origin") != self.origin:
                raise HttpFailure(403, "Cross-origin mutation is not authorized.")
            return
        # The pinned native listener is the only authority for switching origin.
        # Request Host/X-Forwarded-* cannot manufacture an allowed listener.
        raw = headers.get("origin", "")
        try:
            candidate = urlparse(raw)
            port = candidate.port
            if (candidate.scheme != "https" or candidate.hostname != "127.0.0.1"
                    or candidate.username is not None or candidate.password is not None
                    or port is None or not 1024 <= port <= 65535
                    or raw != f"https://127.0.0.1:{port}"
                    or headers.get("host") != f"127.0.0.1:{port}"):
                raise HttpFailure(403, "Native ingress request authority is invalid.")
        except (ValueError, TypeError) as exc:
            raise HttpFailure(403, "Native ingress request authority is invalid.") from exc
        try:
            fact = self.native_ingress.status()
            if not isinstance(fact, dict) or type(fact.get("pending")) is not bool:
                raise ValueError("Invalid ingress reconciliation state.")
            active = fact["active"]
            choices = (active, fact["confirmed"]) if fact["pending"] else (active,)
            verified_ports = []
            for entry in choices:
                candidate_port = entry["https_port"]
                if type(candidate_port) is not int or not 1024 <= candidate_port <= 65535:
                    raise ValueError("Native ingress port is unverified.")
                verified_ports.append(candidate_port)
        except (RuntimeError, ValueError, TypeError, KeyError) as exc:
            raise HttpFailure(503, "Native ingress origin cannot be verified.") from exc
        if port not in verified_ports:
            raise HttpFailure(403, "This HTTPS origin is no longer active.")

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http":
            return
        method = scope.get("method", "GET")
        path = scope.get("path", "")
        headers = {k.decode("latin1").lower(): v.decode("latin1") for k,v in scope.get("headers", [])}
        peer = scope.get("client")
        direct_peer = peer[0] if isinstance(peer, (tuple, list)) and peer else None
        client = resolve_web_source(
            direct_peer, headers.get("x-forwarded-for"),
            trusted_proxy_cidrs=self.trusted_proxy_cidrs
        )
        now = int(time.time())
        body_bytes = bytearray()
        try:
            if method not in ("GET", "POST", "PUT", "PATCH", "DELETE") or not (
                path.startswith("/api/foundation/") or path.startswith("/api/v1/")
            ):
                raise HttpFailure(404, "Unknown endpoint.")
            if method in ("POST", "PUT", "PATCH", "DELETE"):
                self._require_mutation_origin(headers)
            while True:
                event = await receive()
                if event["type"] == "http.disconnect":
                    return
                if event["type"] != "http.request":
                    continue
                body_bytes.extend(event.get("body", b""))
                if len(body_bytes) > MAX_BODY:
                    raise HttpFailure(413, "Request exceeds the security limit.")
                if not event.get("more_body"):
                    break
            payload = json.loads(body_bytes) if body_bytes else {}
            if not isinstance(payload, dict):
                raise HttpFailure(400, "Object request body required.")
            with self.lock:
                c = self._connect(self.database)
                try:
                    c.execute("BEGIN IMMEDIATE")
                    policy = json.loads(self._policy(c, "acl")["value"])
                    if not _client_allowed(client, policy["webCidrs"]):
                        raise HttpFailure(403, "Management access denied for this source.")
                    session = self._principal(c, headers, now)
                    status, data, cookie = self._dispatch(c, method, path, payload, headers, session, client, now)
                    c.commit()
                except HttpFailure as failure:
                    if failure.persist:
                        c.commit()
                    else:
                        c.rollback()
                    raise
                except:
                    c.rollback()
                    raise
                finally:
                    c.close()
        except HttpFailure as exc:
            # The exact Control-cloned Admin UI displays "detail"/"message".
            # Preserve "error" for existing Foundation clients and expose
            # the same already-public, fail-closed message to that original UI.
            message = str(exc)
            status, data, cookie = exc.status, {"error": message, "detail": message}, None
        except (ValueError, TypeError, json.JSONDecodeError):
            message = "Invalid security request."
            status, data, cookie = 400, {"error": message, "detail": message}, None
        except Exception:
            message = "Security service unavailable."
            status, data, cookie = 500, {"error": message, "detail": message}, None
        response = json.dumps(data, separators=(",", ":")).encode()
        head = [(b"content-type", b"application/json; charset=utf-8"),
                (b"cache-control", b"no-store"), (b"x-content-type-options", b"nosniff"),
                (b"x-frame-options", b"DENY"), (b"content-length", str(len(response)).encode())]
        if cookie:
            head.append((b"set-cookie", cookie.encode("ascii")))
        await send({"type": "http.response.start", "status": status, "headers": head})
        await send({"type": "http.response.body", "body": response})


def app_from_environment():
    db = os.environ["DATARELAY_FOUNDATION_DB"]
    origin = os.environ["DATARELAY_FOUNDATION_ORIGIN"]
    secure = os.environ.get("DATARELAY_FOUNDATION_LOCAL_HTTP") != "1"
    proxies = os.environ.get("DATARELAY_FOUNDATION_TRUSTED_PROXIES", "")
    trusted = tuple(c.strip() for c in proxies.split(",") if c.strip())
    native_helper = os.environ.get("DATARELAY_FOUNDATION_NATIVE_SSH_HELPER")
    native = None
    if native_helper:
        from .native_ssh_bridge import HostSshBridge
        native = HostSshBridge(native_helper)
    backup_root = os.environ.get("DATARELAY_FOUNDATION_BACKUP_ROOT")
    lifecycle = None
    if backup_root:
        from .embedded_lifecycle import EmbeddedLifecycle
        default_keep_last = int(os.environ.get("DATARELAY_FOUNDATION_BACKUP_DEFAULT_KEEP_LAST", "7"))
        lifecycle = EmbeddedLifecycle(db, backup_root, default_keep_last=default_keep_last)
    native_https = None
    host_ca = os.environ.get("DATARELAY_FOUNDATION_EXTERNAL_TLS_CA")
    host_http_port = os.environ.get("DATARELAY_FOUNDATION_EXTERNAL_HTTP_PORT")
    if host_ca:
        from .host_https_observation import HostHttpsObserver
        native_https = HostHttpsObserver(
            origin=origin, ca_file=host_ca,
            http_port=int(host_http_port) if host_http_port else None,
        )
    native_ingress = None
    ingress_helper = os.environ.get("DATARELAY_FOUNDATION_NATIVE_INGRESS_HELPER")
    if ingress_helper:
        from .native_ingress_bridge import HostIngressBridge
        native_ingress = HostIngressBridge(ingress_helper)
    migration = os.environ.get("DATARELAY_FOUNDATION_NATIVE_INGRESS_ORIGIN_MIGRATION", "0")
    if migration not in ("0", "1"):
        raise ValueError("Ingress origin migration flag must be 0 or 1.")
    runtime = EmbeddedFoundationRuntime(
        db, origin=origin, cookie_secure=secure, trusted_proxy_cidrs=trusted,
        native_ssh=native, native_lifecycle=lifecycle, native_https=native_https,
        native_ingress=native_ingress, native_ingress_migrate_origin=migration == "1",
    )
    static_dir = os.environ.get("DATARELAY_FOUNDATION_STATIC_DIST")
    return EmbeddedControlWebApp(runtime, static_dir) if static_dir else runtime


class EmbeddedControlWebApp:
    """Serve the compiled Control-first UI and native API behind one Web ACL.

    Using only the API guard while an unguarded proxy serves HTML/assets is not
    sufficient for Management Access. This wrapper protects every frontend
    request and every supported API using the same authoritative CIDR policy.
    Uvicorn MUST use --no-proxy-headers; explicit trusted proxy CIDRs and a
    correctly overwritten XFF chain are required when a reverse proxy is used.
    """
    def __init__(self, runtime: EmbeddedFoundationRuntime, static_dir: str | Path):
        self.runtime = runtime
        self.static_dir = Path(static_dir).resolve(strict=True)
        if not self.static_dir.is_dir() or not (self.static_dir / "index.html").is_file():
            raise ValueError("Provide a built Control-first static dist with index.html.")

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http":
            return
        path = scope.get("path", "")
        if path.startswith("/api/"):
            await self.runtime(scope, receive, send)
            return
        from mimetypes import guess_type

        async def reply(status: int, payload: bytes, kind: bytes,
                        *, head: bool = False, cache: bytes = b"no-store"):
            fields = [
                (b"content-type", kind),
                (b"cache-control", cache),
                (b"content-length", str(len(payload)).encode("ascii")),
                (b"x-content-type-options", b"nosniff"),
                (b"x-frame-options", b"DENY"),
                (b"referrer-policy", b"no-referrer"),
                (b"content-security-policy",
                 b"default-src 'self'; base-uri 'self'; object-src 'none'; "
                 b"form-action 'self'; frame-ancestors 'none'; connect-src 'self'; "
                 b"img-src 'self' data:; font-src 'self' data:; script-src 'self'; "
                 b"style-src 'self' 'unsafe-inline'"),
            ]
            await send({"type": "http.response.start", "status": status, "headers": fields})
            await send({"type": "http.response.body", "body": b"" if head else payload})

        method = scope.get("method", "GET")
        if method not in ("GET", "HEAD"):
            await reply(405, b"Method not allowed", b"text/plain; charset=utf-8")
            return
        headers = {key.decode("latin1").lower(): val.decode("latin1")
                   for key, val in scope.get("headers", [])}
        peer = scope.get("client")
        direct = peer[0] if isinstance(peer, (tuple, list)) and peer else None
        client = resolve_web_source(
            direct, headers.get("x-forwarded-for"),
            trusted_proxy_cidrs=self.runtime.trusted_proxy_cidrs
        )
        with self.runtime.lock:
            with self.runtime._connect(self.runtime.database) as c:
                policy = json.loads(self.runtime._policy(c, "acl")["value"])
                permitted = _client_allowed(client, policy["webCidrs"])
        if not permitted:
            await reply(403, b"Management access denied", b"text/plain; charset=utf-8",
                        head=method == "HEAD")
            return
        if not isinstance(path, str) or "\x00" in path or "\\" in path or len(path) > 4096:
            await reply(404, b"Not found", b"text/plain; charset=utf-8")
            return
        relative = path.removeprefix("/") or "index.html"
        if any(part in (".", "..") for part in relative.split("/")):
            await reply(404, b"Not found", b"text/plain; charset=utf-8")
            return
        candidate = (self.static_dir / relative).resolve()
        if not candidate.is_relative_to(self.static_dir):
            await reply(404, b"Not found", b"text/plain; charset=utf-8")
            return
        if not candidate.is_file():
            if "." not in Path(relative).name:
                candidate = self.static_dir / "index.html"  # SPA /settings etc.
            else:
                await reply(404, b"Not found", b"text/plain; charset=utf-8")
                return
        try:
            if candidate.stat().st_size > 24 * 1024 * 1024:
                raise OSError("Asset exceeds maximum allowed size.")
            payload = candidate.read_bytes()
        except OSError:
            await reply(404, b"Not found", b"text/plain; charset=utf-8")
            return
        kind = guess_type(candidate.name)[0] or "application/octet-stream"
        if kind in ("text/javascript", "application/x-javascript"):
            kind = "application/javascript"
        if kind in ("text/html", "text/css", "application/javascript"):
            kind += "; charset=utf-8"
        # IP authorization can be revoked at any moment. Never mark a protected
        # asset public/immutable in the browser cache and bypass a new ACL read.
        await reply(200, payload, kind.encode("ascii"),
                    head=method == "HEAD", cache=b"no-store")


def main(argv: list[str] | None = None) -> int:
    """One-time private database bootstrap; no credentials on the command line."""
    import argparse
    from getpass import getpass

    parser = argparse.ArgumentParser(
        description="DataRelay Foundation standalone security runtime"
    )
    commands = parser.add_subparsers(dest="operation", required=True)
    init = commands.add_parser("init", help="Initialize a private SQLite security database")
    init.add_argument("--database", type=Path, required=True)
    init.add_argument("--admin", required=True)
    init.add_argument("--allow-web-cidr", action="append", default=[], metavar="IP/CIDR",
                      help="Explicit extra initial management source (no /0); repeat as needed")
    args = parser.parse_args(argv)

    if args.operation == "init":
        password = getpass("Initial administrator password (min. 12 characters): ")
        confirmed = getpass("Confirm administrator password: ")
        if password != confirmed:
            parser.error("Initial password and confirmation do not match.")
        try:
            EmbeddedFoundationRuntime.bootstrap_admin(
                args.database, args.admin, password,
                initial_web_cidrs=tuple(args.allow_web_cidr)
            )
        except (OSError, ValueError) as exc:
            parser.error(str(exc))
        print("FOUNDATION_EMBEDDED_BOOTSTRAP=PASS")
        return 0
    parser.error("Unknown operation.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
