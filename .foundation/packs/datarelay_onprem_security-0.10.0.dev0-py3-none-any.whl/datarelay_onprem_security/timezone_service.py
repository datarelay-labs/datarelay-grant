"""Reusable server-side display-timezone service for all Foundation consumers.

A product supplies its authenticated actor and an atomic persistence/audit port.
No caller-provided HTTP body can select an actor, grant permission, or skip CAS.
MemoryTimezoneStore is an isolated reference/test implementation, not production
identity or storage. The service never changes the operating-system timezone.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import time


class SettingsPermissionError(PermissionError):
    """Authenticated native actor lacks an explicitly required capability."""


class SettingsValidationError(ValueError):
    """Invalid submitted configuration or unsafe stored state."""


class SettingsRevisionConflict(RuntimeError):
    """Concurrent configuration changed before an atomic commit."""


@dataclass(frozen=True)
class SettingsActor:
    """Server-authenticated identity; never construct this from request-body claims."""

    subject: str
    capabilities: frozenset[str] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        if (not isinstance(self.subject, str) or not self.subject
                or len(self.subject) > 256 or any(ord(c) < 33 or ord(c) == 127 for c in self.subject)):
            raise SettingsValidationError("Invalid authenticated subject.")
        if not isinstance(self.capabilities, frozenset) or not all(
            isinstance(value, str) and 0 < len(value) <= 128 for value in self.capabilities
        ):
            raise SettingsValidationError("Capabilities must come from a native authenticated context.")


@dataclass(frozen=True)
class VersionedTimezoneState:
    revision: str
    value: dict[str, Any]


class TimezoneStore(Protocol):
    """Implement with an existing product transaction, not a separate shared DB.

    read returns a detached snapshot. commit MUST atomically compare revision,
    persist the new state AND its audit event, or raise without either effect.
    """

    def read(self) -> VersionedTimezoneState: ...

    def commit(self, expected_revision: str, value: Mapping[str, Any],
               audit_event: Mapping[str, Any]) -> VersionedTimezoneState: ...


def _zone(value: object) -> str:
    if not isinstance(value, str) or not value or len(value) > 128 or value != value.strip():
        raise SettingsValidationError("Choose a valid IANA timezone.")
    try:
        ZoneInfo(value)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        raise SettingsValidationError("Choose a valid IANA timezone.") from None
    return value


def _snapshot(value: VersionedTimezoneState) -> VersionedTimezoneState:
    if not isinstance(value, VersionedTimezoneState) or not isinstance(value.revision, str) or not value.revision:
        raise SettingsValidationError("Timezone revision is unavailable.")
    if not isinstance(value.value, dict) or set(value.value) != {"platformDefaultTimezone", "userOverrides"}:
        raise SettingsValidationError("Invalid stored timezone state.")
    _zone(value.value["platformDefaultTimezone"])
    overrides = value.value["userOverrides"]
    if not isinstance(overrides, dict) or len(overrides) > 100000:
        raise SettingsValidationError("Invalid stored timezone preferences.")
    for subject, zone in overrides.items():
        if not isinstance(subject, str) or not subject or len(subject) > 256:
            raise SettingsValidationError("Invalid stored preference owner.")
        _zone(zone)
    return VersionedTimezoneState(value.revision, deepcopy(value.value))


class MemoryTimezoneStore:
    """Reference/test store; native products implement the same atomic port."""

    def __init__(self, platform_default: str = "UTC") -> None:
        self._lock = RLock()
        self._revision = 1
        self._value: dict[str, Any] = {"platformDefaultTimezone": _zone(platform_default), "userOverrides": {}}
        self._audit: list[dict[str, Any]] = []

    def _read_locked(self) -> VersionedTimezoneState:
        return VersionedTimezoneState("timezone-" + str(self._revision), deepcopy(self._value))

    def read(self) -> VersionedTimezoneState:
        with self._lock:
            return self._read_locked()

    def commit(self, expected_revision: str, value: Mapping[str, Any],
               audit_event: Mapping[str, Any]) -> VersionedTimezoneState:
        # Validate/copy both values before changing either state or audit log.
        next_value = _snapshot(VersionedTimezoneState(expected_revision, dict(value))).value
        next_event = deepcopy(dict(audit_event))
        if not isinstance(next_event.get("id"), str) or not next_event["id"]:
            raise SettingsValidationError("An audit event is required.")
        with self._lock:
            if expected_revision != "timezone-" + str(self._revision):
                raise SettingsRevisionConflict("Timezone settings changed. Refresh and retry.")
            self._value = next_value
            self._audit.append(next_event)
            self._revision += 1
            return self._read_locked()

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class DisplayTimezoneService:
    """Shared business logic behind TimezoneAdapter, not a browser fixture.

    Native integration is limited to authenticated SettingsActor creation and
    the existing database/audit transaction implementing TimezoneStore.
    """

    def __init__(self, store: TimezoneStore, clock: Callable[[], float] = time.time) -> None:
        self.store = store
        self.clock = clock

    @staticmethod
    def _require(actor: SettingsActor, permission: str) -> None:
        if not isinstance(actor, SettingsActor) or permission not in actor.capabilities:
            raise SettingsPermissionError("The product did not authorize this timezone operation.")

    def _project(self, snapshot: VersionedTimezoneState, actor: SettingsActor) -> dict[str, Any]:
        preference = snapshot.value["userOverrides"].get(actor.subject)
        platform = snapshot.value["platformDefaultTimezone"]
        return {"effective": {"resolvedTimezone": preference or platform,
                              "userTimezone": preference,
                              "platformDefaultTimezone": platform},
                "revision": snapshot.revision,
                "readAt": datetime.fromtimestamp(self.clock(), timezone.utc).isoformat()}

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, "timezone.read")
        return self._project(_snapshot(self.store.read()), actor)

    def configure(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, "timezone.read")
        if not isinstance(request, Mapping) or set(request) != {"scope", "timezone", "expectedRevision"}:
            raise SettingsValidationError("Only scope, timezone and expectedRevision may be submitted.")
        scope = request["scope"]
        if scope not in ("personal", "platform"):
            raise SettingsValidationError("Choose personal or platform timezone scope.")
        self._require(actor, "timezone.personal.configure" if scope == "personal" else "timezone.configure")
        proposed = request["timezone"]
        if proposed is not None or scope == "platform":
            proposed = _zone(proposed)
        expected = request["expectedRevision"]
        if not isinstance(expected, str) or not expected or len(expected) > 256:
            raise SettingsValidationError("A current timezone revision is required.")
        before = _snapshot(self.store.read())
        if before.revision != expected:
            raise SettingsRevisionConflict("Timezone settings changed. Refresh and retry.")
        next_value = deepcopy(before.value)
        if scope == "personal":
            previous = before.value["userOverrides"].get(actor.subject)
            if proposed is None:
                next_value["userOverrides"].pop(actor.subject, None)
            else:
                next_value["userOverrides"][actor.subject] = proposed
        else:
            previous = before.value["platformDefaultTimezone"]
            next_value["platformDefaultTimezone"] = proposed
        if proposed == previous:
            return {"effective": self._project(before, actor)}
        event_id = "timezone-audit-" + uuid4().hex
        event = {"id": event_id, "actor": actor.subject, "action": "timezone." + scope + ".configured",
                 "timestamp": datetime.fromtimestamp(self.clock(), timezone.utc).isoformat(),
                 "before": previous, "after": proposed,
                 "scope": scope, "expectedRevision": expected}
        after = _snapshot(self.store.commit(expected, next_value, event))
        if after.revision == before.revision or after.value != next_value:
            raise SettingsRevisionConflict("Timezone commit could not be verified.")
        projected = self._project(after, actor)
        projected["audit"] = {"id": event_id}
        return {"effective": projected, "audit": {"id": event_id}}
