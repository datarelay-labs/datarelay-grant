"""Common alert policy and explicit native test-delivery lifecycle.

Destinations are private native data, never public metadata or audit fields. No
network transport is installed. A native adapter must encrypt destination data,
validate egress at the actual connection boundary and enforce operation fences.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from hashlib import sha256
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from urllib.parse import urlsplit
from uuid import uuid4
import json
import math
import re
import time

from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict

KINDS = ('webhook', 'slack', 'email')
DELIVERY_STATUSES = ('queued', 'dispatching', 'accepted', 'delivered', 'failed', 'unknown', 'cancelled', 'simulated')
PUBLIC_DELIVERY_DETAIL = 'Native transport status recorded; human inbox receipt is not verified.'
_REF = re.compile(r'[a-zA-Z0-9_.:-]{1,256}\Z', re.ASCII)


class AlertOperationUnverified(RuntimeError):
    """Reconcile existing native audit/operation; do not automatically repeat it."""


def _ref(value: object) -> str:
    if not isinstance(value, str) or not _REF.fullmatch(value):
        raise SettingsValidationError('Invalid native alert reference.')
    return value


def _text(value: object, maximum: int, *, empty: bool = False) -> str:
    if (not isinstance(value, str) or len(value) > maximum or (not empty and not value)
            or any(ord(c) < 32 or ord(c) == 127 for c in value)):
        raise SettingsValidationError('Invalid alert metadata.')
    return value


def _time(value: object) -> float:
    if type(value) not in (float, int) or not math.isfinite(value) or not 0 <= value <= 253402300000:
        raise SettingsValidationError('Invalid native alert clock.')
    return float(value)


def _stamp(value: object) -> str:
    _text(value, 64)
    try:
        stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if stamp.tzinfo is None or stamp.utcoffset() is None:
            raise ValueError('timezone required')
        return stamp.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')
    except (ValueError, TypeError, OverflowError):
        raise SettingsValidationError('Invalid native alert timestamp.') from None


def _destination(kind: str, value: object) -> str:
    text = _text(value, 2048)
    if kind == 'email':
        recipients = text.split(',')
        if len(recipients) > 50 or any(not re.fullmatch(r'[^\s@,]+@[^\s@,]+\.[^\s@,]+', address.strip()) for address in recipients):
            raise SettingsValidationError('Invalid alert recipient list.')
    else:
        try:
            parsed = urlsplit(text)
            if (parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username is not None
                    or parsed.password is not None or parsed.fragment or parsed.port == 0
                    or '\\' in text or any(c.isspace() for c in text)):
                raise ValueError('invalid URL')
        except (ValueError, TypeError):
            raise SettingsValidationError('Invalid alert destination URL.') from None
    return text


def _state(value: object) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != {'monitorEnabled', 'cooldownSeconds', 'rules', 'channels', 'history'}:
        raise SettingsValidationError('Complete native alert policy is required.')
    if type(value['monitorEnabled']) is not bool or type(value['cooldownSeconds']) is not int or not 10 <= value['cooldownSeconds'] <= 86400:
        raise SettingsValidationError('Invalid native alert policy settings.')
    if not isinstance(value['rules'], list) or len(value['rules']) > 128:
        raise SettingsValidationError('Invalid native alert rule registry.')
    ids = set()
    for rule in value['rules']:
        if (not isinstance(rule, dict) or set(rule) != {'id', 'enabled', 'severity', 'lastTriggeredAt'}
                or type(rule['enabled']) is not bool or rule['severity'] not in ('WARNING', 'CRITICAL')):
            raise SettingsValidationError('Invalid native alert rule.')
        key = _ref(rule['id'])
        if key in ids:
            raise SettingsValidationError('Duplicate native alert rule.')
        ids.add(key)
        if rule['lastTriggeredAt'] is not None:
            _stamp(rule['lastTriggeredAt'])
    if not isinstance(value['channels'], list) or len(value['channels']) > 3:
        raise SettingsValidationError('Invalid native alert channels.')
    kinds = set()
    for channel in value['channels']:
        if (not isinstance(channel, dict) or set(channel) != {'kind', 'label', 'supported', 'revision', 'destination'}
                or channel['kind'] not in KINDS or channel['kind'] in kinds or type(channel['supported']) is not bool):
            raise SettingsValidationError('Invalid native alert channel.')
        kinds.add(channel['kind']); _ref(channel['revision']); _text(channel['label'], 256)
        if channel['destination'] is not None:
            _destination(channel['kind'], channel['destination'])
    history = value['history']
    if not isinstance(history, list) or len(history) > 1000:
        raise SettingsValidationError('Invalid bounded native alert history.')
    seen = set()
    for receipt in history:
        if (not isinstance(receipt, dict) or not {'id', 'ruleId', 'channel', 'status', 'timestamp'} <= set(receipt)
                or not set(receipt) <= {'id', 'ruleId', 'channel', 'status', 'timestamp', 'detail'}):
            raise SettingsValidationError('Invalid public alert delivery receipt.')
        _ref(receipt['id']); _ref(receipt['ruleId']); _text(receipt['channel'], 80)
        _text(receipt['status'], 80); _stamp(receipt['timestamp'])
        channel_names = receipt['channel'].split(',')
        if (receipt['status'] not in DELIVERY_STATUSES or any(c not in KINDS for c in channel_names)
                or len(set(channel_names)) != len(channel_names)):
            raise SettingsValidationError('Delivery history must contain channel kinds and status codes only.')
        if 'detail' in receipt:
            _text(receipt['detail'], 512, empty=True)
        if receipt['id'] in seen:
            raise SettingsValidationError('Duplicate native alert receipt.')
        seen.add(receipt['id'])
    return deepcopy(value)


def _policy(value: Mapping[str, Any]) -> dict[str, Any]:
    return {'monitorEnabled': value['monitorEnabled'], 'cooldownSeconds': value['cooldownSeconds'],
        'rules': [{k: r[k] for k in ('id', 'enabled', 'severity')} for r in value['rules']],
        'channels': deepcopy(value['channels'])}


def _digest(value: Mapping[str, Any]) -> str:
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()).hexdigest()


@dataclass(frozen=True)
class AlertReadiness:
    recent_mfa_verified: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        if type(self.recent_mfa_verified) is not bool or type(self.audit_ready) is not bool:
            raise SettingsValidationError('Alert readiness requires native Boolean evidence.')

    @property
    def safe(self) -> bool:
        return self.recent_mfa_verified and self.audit_ready


@dataclass(frozen=True)
class AlertSnapshot:
    revision: str
    value: dict[str, Any]


@dataclass(frozen=True)
class AlertPreview:
    reference: str
    actor: str
    revision: str
    intent_digest: str
    policy_digest: str
    created_at: float
    expires_at: float


@dataclass(frozen=True)
class AlertJob:
    id: str
    actor: str
    rule_id: str
    policy_revision: str
    channels: tuple[str, ...]
    created_at: float
    phase: str
    receipt: dict[str, Any]


@dataclass(frozen=True)
class AlertMutation:
    value: dict[str, Any]
    event: dict[str, Any]
    preview_ref: str | None = None
    job: AlertJob | None = None
    policy_changed: bool = False


@dataclass(frozen=True)
class AlertDeliveryObservation:
    status: str
    channels: tuple[str, ...]


class AlertTransport(Protocol):
    """Native bounded once-only dispatch for the durable operation identifier.

    Revalidate current authority, policy/recipient revision, job ownership and
    final egress/DNS/redirect policy at the actual effect boundary. The native
    implementation uses operation+channel idempotency/fencing so one claim cannot
    produce multiple sends. Only native verified transport status is returned;
    accepted/delivered never means a human inbox receipt. No destination, body or
    raw exception belongs in public detail. A lost response stays unknown and
    requires native reconciliation, never an automatic resend.
    """
    def deliver(self, operation_id: str, rule_id: str, severity: str,
                destinations: Mapping[str, str]) -> AlertDeliveryObservation: ...


class AlertStore(Protocol):
    """Bind existing encrypted policy, restricted previews, durable jobs and audit.

    transact locks all authoritative data and invokes build exactly once with
    detached current state. Current authorization participates in this native
    transaction. Commit policy/job/history plus audit atomically or write nothing.
    Policy changes advance revision and consume previews; history-only updates
    preserve policy revision. A test claim is persisted before any transport
    effect. A failed/unknown terminal commit retains dispatching ownership and
    prevents another test for that rule until actual native reconciliation.
    Never infer a destination from posted public channel metadata.
    """
    def read(self) -> AlertSnapshot: ...
    def register_preview(self, preview: AlertPreview) -> None: ...
    def read_audit(self, reference: str) -> Mapping[str, Any] | None: ...
    def read_job(self, reference: str) -> AlertJob | None: ...
    def transact(self, build: Callable[[AlertSnapshot, Mapping[str, AlertPreview], Mapping[str, AlertJob]], AlertMutation]) -> AlertSnapshot: ...


class MemoryAlertStore:
    """Synthetic-only reference; no destination credentials or messages are real."""
    def __init__(self, value: dict[str, Any]) -> None:
        self._value = _state(value); self._version = 1; self._lock = RLock()
        self._previews: dict[str, AlertPreview] = {}; self._jobs: dict[str, AlertJob] = {}; self._audit = []

    def read(self) -> AlertSnapshot:
        with self._lock:
            return AlertSnapshot('alerts-' + str(self._version), deepcopy(self._value))

    def register_preview(self, preview: AlertPreview) -> None:
        with self._lock:
            if preview.revision != self.read().revision:
                raise SettingsRevisionConflict('Alert settings changed.')
            self._previews = {k: p for k, p in self._previews.items() if p.expires_at > preview.created_at}
            if len(self._previews) >= 1024:
                raise SettingsValidationError('Native alert preview capacity exceeded.')
            self._previews[preview.reference] = deepcopy(preview)

    def read_audit(self, reference: str) -> Mapping[str, Any] | None:
        with self._lock:
            return deepcopy(next((e for e in self._audit if e['id'] == reference), None))

    def read_job(self, reference: str) -> AlertJob | None:
        with self._lock:
            return deepcopy(self._jobs.get(reference))

    def transact(self, build: Callable[[AlertSnapshot, Mapping[str, AlertPreview], Mapping[str, AlertJob]], AlertMutation]) -> AlertSnapshot:
        with self._lock:
            mutation = build(self.read(), deepcopy(self._previews), deepcopy(self._jobs))
            if not isinstance(mutation, AlertMutation):
                raise SettingsValidationError('Invalid native alert transaction.')
            value = _state(mutation.value); event = deepcopy(mutation.event); _ref(event.get('id'))
            if mutation.preview_ref is not None and mutation.preview_ref not in self._previews:
                raise SettingsRevisionConflict('Native alert preview was consumed.')
            job = deepcopy(mutation.job)
            if job is not None:
                previous = self._jobs.get(job.id)
                if (not isinstance(job, AlertJob) or job.phase not in ('dispatching', 'complete', 'unknown')
                        or (previous is not None and previous.phase != 'dispatching')
                        or (previous is None and (job.phase != 'dispatching' or len(self._jobs) >= 10000))):
                    raise SettingsRevisionConflict('Native alert delivery claim is no longer available.')
            self._value = value; self._audit.append(event)
            if mutation.policy_changed:
                self._version += 1; self._previews.clear()
            elif mutation.preview_ref is not None:
                self._previews.pop(mutation.preview_ref, None)
            if job is not None:
                self._jobs[job.id] = job
            return self.read()

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class OperationalAlertService:
    def __init__(self, store: AlertStore, transport: AlertTransport, *,
                 authorize: Callable[[SettingsActor, str], bool], readiness: Callable[[SettingsActor], AlertReadiness],
                 validate_destination: Callable[[SettingsActor, str, str], bool], clock: Callable[[], float] = time.time) -> None:
        if not all(callable(f) for f in (authorize, readiness, validate_destination)):
            raise SettingsValidationError('Native authority, readiness and egress validation are required.')
        self.store = store; self.transport = transport; self.authorize = authorize
        self.readiness = readiness; self.validate_destination = validate_destination; self.clock = clock

    def _require(self, actor: SettingsActor, right: str) -> None:
        try:
            allowed = isinstance(actor, SettingsActor) and right in actor.capabilities and self.authorize(actor, right) is True
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError('Native actor does not currently authorize this alert operation.')

    def _ready(self, actor: SettingsActor) -> None:
        try:
            evidence = self.readiness(actor)
        except Exception:
            evidence = None
        if not isinstance(evidence, AlertReadiness) or not evidence.safe:
            raise SettingsPermissionError('Current native MFA and audit readiness are required.')

    def _snapshot(self) -> AlertSnapshot:
        value = self.store.read()
        if not isinstance(value, AlertSnapshot):
            raise SettingsValidationError('Native alert state is unavailable.')
        _ref(value.revision)
        return AlertSnapshot(value.revision, _state(value.value))

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, 'alerts.read'); snapshot = self._snapshot(); self._require(actor, 'alerts.read')
        value = snapshot.value
        return {'revision': snapshot.revision, 'effective': {
            'monitorEnabled': value['monitorEnabled'], 'cooldownSeconds': value['cooldownSeconds'],
            'rules': value['rules'], 'history': [{k: r[k] for k in ('id', 'ruleId', 'channel', 'status', 'timestamp')} | {'detail': PUBLIC_DELIVERY_DETAIL} for r in value['history']],
            'channels': [{k: c[k] for k in ('kind', 'label', 'revision', 'supported')} | {'configured': c['destination'] is not None} for c in value['channels']]}}

    def _egress(self, actor: SettingsActor, value: Mapping[str, Any]) -> None:
        for channel in value['channels']:
            if channel['destination'] is None:
                continue
            _destination(channel['kind'], channel['destination'])
            try:
                safe = self.validate_destination(actor, channel['kind'], channel['destination']) is True
            except Exception:
                safe = False
            if not safe:
                raise SettingsPermissionError('Native destination or egress policy did not authorize the alert destination.')

    def _draft(self, actor: SettingsActor, request: object, snapshot: AlertSnapshot) -> dict[str, Any]:
        keys = {'expectedRevision', 'monitorEnabled', 'cooldownSeconds', 'rules', 'destinations'}
        if not isinstance(request, Mapping) or set(request) != keys:
            raise SettingsValidationError('Submit only common alert policy fields and write-only destination changes.')
        _ref(request['expectedRevision'])
        if request['expectedRevision'] != snapshot.revision:
            raise SettingsRevisionConflict('Alert settings changed. Refresh the native policy.')
        if (type(request['monitorEnabled']) is not bool or type(request['cooldownSeconds']) is not int
                or not 10 <= request['cooldownSeconds'] <= 86400 or not isinstance(request['rules'], list)
                or len(request['rules']) != len(snapshot.value['rules']) or not isinstance(request['destinations'], dict)):
            raise SettingsValidationError('Invalid native alert policy intent.')
        known = {r['id'] for r in snapshot.value['rules']}; supplied = set()
        for rule in request['rules']:
            if (not isinstance(rule, dict) or set(rule) != {'id', 'enabled', 'severity'} or type(rule['enabled']) is not bool
                    or rule['severity'] not in ('WARNING', 'CRITICAL') or not isinstance(rule['id'], str)
                    or rule['id'] not in known or rule['id'] in supplied):
                raise SettingsValidationError('Only the complete current native rule registry may be configured.')
            supplied.add(rule['id'])
        channels = {c['kind'] for c in snapshot.value['channels']}
        for kind, value in request['destinations'].items():
            if kind not in channels:
                raise SettingsValidationError('Unknown native alert channel.')
            if value is not None:
                _destination(kind, value)
        return deepcopy(dict(request))

    @staticmethod
    def _proposed(current: dict[str, Any], draft: dict[str, Any]) -> dict[str, Any]:
        value = deepcopy(current); value['monitorEnabled'] = draft['monitorEnabled']; value['cooldownSeconds'] = draft['cooldownSeconds']
        rules = {r['id']: r for r in draft['rules']}
        for rule in value['rules']:
            rule.update(rules[rule['id']])
        for channel in value['channels']:
            if channel['kind'] in draft['destinations']:
                channel['destination'] = draft['destinations'][channel['kind']]
        return value

    def preview(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'alerts.read'); self._require(actor, 'alerts.configure')
        snapshot = self._snapshot(); draft = self._draft(actor, request, snapshot)
        proposed = self._proposed(snapshot.value, draft)
        self._ready(actor); self._egress(actor, proposed); self._require(actor, 'alerts.configure')
        if _policy(proposed) == _policy(snapshot.value) and not draft['destinations']:
            raise SettingsValidationError('No alert policy change remains.')
        now = _time(self.clock())
        plan = AlertPreview('alert-preview-' + uuid4().hex, actor.subject, snapshot.revision,
            _digest(draft), _digest(_policy(snapshot.value)), now, now + 300)
        self.store.register_preview(plan)
        return {'expectedRevision': snapshot.revision, 'previewRef': plan.reference, 'allowed': True, 'blockers': [],
                'actorAuthorized': True, 'recentMfaVerified': True, 'auditReady': True, 'destinationsVerified': True}

    @staticmethod
    def _event(actor: SettingsActor, action: str, now: float, **metadata: Any) -> dict[str, Any]:
        return {'id': 'alert-audit-' + uuid4().hex, 'actor': actor.subject, 'action': action, 'timestamp': now, **metadata}

    def _transact(self, build: Callable) -> AlertSnapshot:
        try:
            return self.store.transact(build)
        except (SettingsValidationError, SettingsRevisionConflict, SettingsPermissionError, AlertOperationUnverified):
            raise
        except Exception:
            raise AlertOperationUnverified('Native alert operation or audit is unverified. Reconcile before repeating.') from None

    def configure(self, actor: SettingsActor, request: Mapping[str, Any], preview_ref: str) -> dict[str, Any]:
        self._require(actor, 'alerts.configure'); self._require(actor, 'alerts.read'); _ref(preview_ref)
        before = self._snapshot(); draft = self._draft(actor, request, before)
        event = self._event(actor, 'alerts.policy.configured', _time(self.clock()), expectedRevision=before.revision)
        desired: dict[str, Any] = {}
        def build(current: AlertSnapshot, plans: Mapping[str, AlertPreview], jobs: Mapping[str, AlertJob]) -> AlertMutation:
            nonlocal desired
            self._require(actor, 'alerts.configure'); self._require(actor, 'alerts.read')
            self._draft(actor, draft, current); plan = plans.get(preview_ref)
            if not isinstance(plan, AlertPreview):
                raise SettingsValidationError('A stored native alert preview is required.')
            if plan.actor != actor.subject:
                raise SettingsPermissionError('This native alert preview belongs to another actor.')
            if plan.revision != current.revision or plan.intent_digest != _digest(draft):
                raise SettingsValidationError('Alert preview does not match the exact reviewed intent.')
            if plan.policy_digest != _digest(_policy(current.value)):
                raise SettingsRevisionConflict('Native alert policy changed without a matching revision.')
            desired = self._proposed(current.value, draft)
            self._ready(actor); self._egress(actor, desired); self._require(actor, 'alerts.configure')
            if not plan.created_at <= _time(self.clock()) < plan.expires_at:
                raise SettingsValidationError('Native alert preview expired.')
            for channel in desired['channels']:
                if channel['kind'] in draft['destinations']:
                    channel['revision'] = 'destination-' + uuid4().hex
            return AlertMutation(desired, event, preview_ref=preview_ref, policy_changed=True)
        result = self._transact(build); observed = self._snapshot()
        if (not isinstance(result, AlertSnapshot) or result.revision == before.revision or observed.revision != result.revision
                or _policy(observed.value) != _policy(desired) or _policy(result.value) != _policy(desired)
                or self.store.read_audit(event['id']) != event):
            raise AlertOperationUnverified('Native alert configuration and audit were not independently verified.')
        return {'revision': observed.revision, 'auditReference': event['id']}

    def _test_gate(self, actor: SettingsActor, current: AlertSnapshot, rule_id: str, revision: str) -> tuple[dict[str, Any], dict[str, str]]:
        self._require(actor, 'alerts.read'); self._require(actor, 'alerts.test')
        if current.revision != revision:
            raise SettingsRevisionConflict('Alert policy changed before test dispatch.')
        rule = next((r for r in current.value['rules'] if r['id'] == rule_id), None)
        destinations = {c['kind']: c['destination'] for c in current.value['channels'] if c['supported'] and c['destination'] is not None}
        if rule is None or not destinations:
            raise SettingsValidationError('A current rule and supported configured channel are required.')
        self._ready(actor); self._egress(actor, current.value); self._require(actor, 'alerts.test')
        return rule, destinations

    def test(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'alerts.test'); self._require(actor, 'alerts.read')
        if not isinstance(request, Mapping) or set(request) != {'ruleId', 'expectedRevision'}:
            raise SettingsValidationError('Submit only the existing rule and current policy revision.')
        rule_id = _ref(request['ruleId']); revision = _ref(request['expectedRevision'])
        now = _time(self.clock()); identity = 'alert-test-' + uuid4().hex
        event = self._event(actor, 'alerts.test.claimed', now, operation=identity, ruleId=rule_id)
        claim: AlertJob | None = None
        def claim_test(current: AlertSnapshot, plans: Mapping[str, AlertPreview], jobs: Mapping[str, AlertJob]) -> AlertMutation:
            nonlocal claim
            rule, destinations = self._test_gate(actor, current, rule_id, revision)
            at = _time(self.clock())
            for existing in jobs.values():
                if existing.rule_id != rule_id:
                    continue
                if existing.phase in ('dispatching', 'unknown'):
                    raise AlertOperationUnverified('An existing alert delivery requires native reconciliation before another test.')
                if at - existing.created_at < current.value['cooldownSeconds']:
                    raise SettingsValidationError('Wait for the native test cooldown before sending again.')
            receipt = {'id': identity, 'ruleId': rule_id, 'channel': ','.join(sorted(destinations)), 'status': 'dispatching',
                       'timestamp': datetime.fromtimestamp(at, timezone.utc).isoformat(), 'detail': 'Native test operation claimed; inbox receipt is not verified.'}
            claim = AlertJob(identity, actor.subject, rule_id, revision, tuple(sorted(destinations)), at, 'dispatching', receipt)
            value = deepcopy(current.value); value['history'] = [receipt, *value['history']][:1000]
            return AlertMutation(value, event, job=claim)
        self._transact(claim_test)
        if claim is None or self.store.read_job(identity) != claim or self.store.read_audit(event['id']) != event:
            raise AlertOperationUnverified('Native alert delivery claim/audit was not independently persisted. Do not resend.')
        status = 'unknown'; delivery_attempted = False
        try:
            rule, destinations = self._test_gate(actor, self._snapshot(), rule_id, revision)
            if tuple(sorted(destinations)) != claim.channels or self.store.read_job(identity) != claim:
                raise AlertOperationUnverified('Native delivery claim changed.')
            delivery_attempted = True
            observation = self.transport.deliver(identity, rule_id, rule['severity'], destinations)
            if (isinstance(observation, AlertDeliveryObservation) and observation.channels == claim.channels
                    and observation.status in ('accepted', 'delivered', 'failed', 'unknown', 'simulated')):
                status = observation.status
        except (SettingsPermissionError, SettingsRevisionConflict, SettingsValidationError):
            status = 'unknown' if delivery_attempted else 'cancelled'
        except Exception:
            status = 'unknown'
        receipt = {**claim.receipt, 'status': status, 'detail': PUBLIC_DELIVERY_DETAIL}
        terminal = replace(claim, phase='unknown' if status == 'unknown' else 'complete', receipt=receipt)
        terminal_event = self._event(actor, 'alerts.test.' + status, now, operation=identity, ruleId=rule_id)
        def finish(current: AlertSnapshot, plans: Mapping[str, AlertPreview], jobs: Mapping[str, AlertJob]) -> AlertMutation:
            if jobs.get(identity) != claim:
                raise AlertOperationUnverified('Native alert delivery ownership changed; no terminal overwrite is permitted.')
            value = deepcopy(current.value)
            value['history'] = [receipt if r['id'] == identity else r for r in value['history']]
            return AlertMutation(value, terminal_event, job=terminal)
        self._transact(finish)
        self._require(actor, 'alerts.read')
        observed = self._snapshot()
        if (self.store.read_job(identity) != terminal or self.store.read_audit(terminal_event['id']) != terminal_event
                or receipt not in observed.value['history']):
            raise AlertOperationUnverified('Native alert delivery receipt/audit was not independently persisted.')
        return receipt
