"""Common management Web/API and host SSH allowlist lifecycle.

Reuse the existing ACL parser and source/lockout engines. Native typed ports
provide current source/proxy trust, current authority, durable recovery and actual
host enforcement. No firewall, sshd, proxy rule or live permission is modified by
this module itself; the in-memory store and synthetic drivers are test-only.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import math
import re
import time

from .acl import ManagementPolicy, SurfacePolicy, AllowEntry, preview_change, resolve_web_source, canonical_network
from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict

_REF = re.compile(r'[a-z][a-z0-9_.-]{0,95}\Z', re.ASCII)


class ManagementAccessUnverified(RuntimeError):
    """Reconcile the exact native operation; never guess that host access is safe."""


def _ref(value: object) -> str:
    if not isinstance(value, str) or not _REF.fullmatch(value):
        raise SettingsValidationError('A current native access-policy reference is required.')
    return value


def _time(value: object) -> int:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402296000:
        raise SettingsValidationError('Invalid native access-policy time.')
    return int(value)


def _surface(value: object, now: int) -> SurfacePolicy:
    if (not isinstance(value, Mapping) or set(value) != {'enabled', 'sources'} or type(value['enabled']) is not bool
            or not isinstance(value['sources'], list) or len(value['sources']) > 64):
        raise SettingsValidationError('Supply the surface enablement and at most 64 source CIDRs.')
    entries = []
    for item in value['sources']:
        if (not isinstance(item, dict) or 'cidr' not in item or not set(item) <= {'cidr', 'expiresAt'}
                or not isinstance(item['cidr'], str) or len(item['cidr']) > 64):
            raise SettingsValidationError('Each access entry requires an IP/CIDR and optional expiry.')
        expiry = item.get('expiresAt')
        if expiry is not None and (type(expiry) is not int or not now < expiry <= 253402300799):
            raise SettingsValidationError('Access entry expiry must be an exact future UTC timestamp.')
        try:
            entries.append(AllowEntry(item['cidr'], expires_at=expiry))
        except ValueError:
            raise SettingsValidationError('Invalid or unrestricted access CIDR.') from None
    try:
        return SurfacePolicy(value['enabled'], tuple(entries))
    except ValueError:
        raise SettingsValidationError('Enabled allowlists require unique, nonempty source ranges.') from None


def _draft(value: object, now: int) -> tuple[dict[str, Any], ManagementPolicy]:
    if not isinstance(value, Mapping) or set(value) != {'expectedRevision', 'rollbackSeconds', 'web', 'ssh'}:
        raise SettingsValidationError('Supply only surface policies, expected revision and rollback interval.')
    _ref(value['expectedRevision'])
    if type(value['rollbackSeconds']) is not int or not 60 <= value['rollbackSeconds'] <= 3600:
        raise SettingsValidationError('Rollback interval must be 60–3600 seconds.')
    candidate = ManagementPolicy(web=_surface(value['web'], now), ssh=_surface(value['ssh'], now))
    return deepcopy(dict(value)), candidate


@dataclass(frozen=True)
class ManagementAccessContext:
    direct_web_peer: str | None = None
    current_ssh_source: str | None = None
    forwarded_for: str | None = None
    trusted_proxy_cidrs: tuple[str, ...] = ()
    emergency_console_confirmed: bool = False
    web_enforcement_supported: bool = False
    ssh_enforcement_supported: bool = False
    rollback_ready: bool = False
    recent_mfa_verified: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        for field in ('emergency_console_confirmed', 'web_enforcement_supported', 'ssh_enforcement_supported',
                      'rollback_ready', 'recent_mfa_verified', 'audit_ready'):
            if type(getattr(self, field)) is not bool:
                raise SettingsValidationError('Access safety requires actual native Boolean facts.')
        for field in ('direct_web_peer', 'current_ssh_source', 'forwarded_for'):
            value = getattr(self, field)
            if value is not None and (not isinstance(value, str) or len(value) > 2048 or any(ord(c) < 32 for c in value)):
                raise SettingsValidationError('Invalid native connection-source evidence.')
        if not isinstance(self.trusted_proxy_cidrs, tuple) or len(self.trusted_proxy_cidrs) > 64:
            raise SettingsValidationError('Invalid native trusted-proxy policy.')
        try:
            for entry in self.trusted_proxy_cidrs:
                canonical_network(entry)
        except ValueError:
            raise SettingsValidationError('Invalid native trusted-proxy range.') from None


@dataclass(frozen=True)
class ManagementAccessObservation:
    policy: ManagementPolicy
    web_enforced: bool
    ssh_enforced: bool

    def __post_init__(self) -> None:
        if not isinstance(self.policy, ManagementPolicy) or type(self.web_enforced) is not bool or type(self.ssh_enforced) is not bool:
            raise SettingsValidationError('Independent native Web/API and SSH enforcement observations are required.')


@dataclass(frozen=True)
class ManagementAccessSnapshot:
    revision: str
    policy: ManagementPolicy
    applying: bool = False


@dataclass(frozen=True)
class ManagementAccessPreview:
    reference: str
    actor: str
    draft: dict[str, Any]
    candidate: ManagementPolicy
    created_at: int
    expires_at: int
    allowed: bool


@dataclass(frozen=True)
class ManagementAccessClaim:
    reference: str
    preview: ManagementAccessPreview
    previous: ManagementAccessObservation


class ManagementAccessDriver(Protocol):
    """Bind existing native protected ingress and recovery mechanisms.

    context derives current source from native sockets/proxy trust and verified
    current MFA/audit/console evidence, never browser-posted IPs or checkboxes.
    observe inspects actual Web UI AND every management API + host SSH filters,
    not just saved config. SSH means this product host, not a proxied service.
    arm_rollback persists a recovery operation that outlives this process.
    Each apply/rollback/confirm rechecks current native ownership and limits the
    effect to that exact operation; apply also checks current authorization.
    rollback proves prior state AND timer cleanup before returning True; confirm
    proves timer cancellation. Lost responses never permit a late stale rollback.
    """
    def context(self, actor: SettingsActor) -> ManagementAccessContext: ...
    def observe(self) -> ManagementAccessObservation: ...
    def arm_rollback(self, operation: str, previous: ManagementAccessObservation, seconds: int) -> bool: ...
    def apply(self, operation: str, desired: ManagementPolicy) -> None: ...
    def rollback(self, operation: str) -> bool: ...
    def confirm(self, operation: str) -> bool: ...


class ManagementAccessStore(Protocol):
    """Native revisioned config, exact preview, exclusive durable lease and audit.

    Current authority participates in claim/configuration native transactions.
    Changes outside this coordinator also advance revision. mark_applied atomically
    persists observed policy and audit while retaining the lease. Only confirmed
    recovery-timer cleanup permits release; unknown operations never silently
    expire into a new owner's authority. Store methods are once-only operations;
    native crash/lost-reply reconciliation must not retry host effects blindly.
    """
    def read(self) -> ManagementAccessSnapshot: ...
    def register_preview(self, preview: ManagementAccessPreview) -> None: ...
    def preview(self, reference: str) -> ManagementAccessPreview | None: ...
    def claim(self, preview: ManagementAccessPreview, previous: ManagementAccessObservation, now: int) -> ManagementAccessClaim: ...
    def mark_applied(self, claim: ManagementAccessClaim, observed: ManagementAccessObservation, event: Mapping[str, Any]) -> ManagementAccessSnapshot: ...
    def read_audit(self, reference: str) -> Mapping[str, Any] | None: ...
    def release(self, claim: ManagementAccessClaim) -> None: ...
    def fail(self, claim: ManagementAccessClaim, event: Mapping[str, Any], recovered: bool) -> None: ...


class MemoryManagementAccessStore:
    """Isolated reference only; no production firewall or access database."""
    def __init__(self, policy: ManagementPolicy) -> None:
        if not isinstance(policy, ManagementPolicy):
            raise SettingsValidationError('A native management policy is required.')
        self._policy = policy; self._version = 1; self._lock = RLock()
        self._previews = {}; self._claim: ManagementAccessClaim | None = None; self._audit = []

    def read(self) -> ManagementAccessSnapshot:
        with self._lock:
            return ManagementAccessSnapshot('acl-' + str(self._version), self._policy, self._claim is not None)

    def _available(self, revision: str) -> None:
        if self._claim is not None or revision != self.read().revision:
            raise SettingsRevisionConflict('Management access changed or an existing operation requires reconciliation.')

    def register_preview(self, preview: ManagementAccessPreview) -> None:
        with self._lock:
            self._available(preview.draft['expectedRevision'])
            self._previews = {k: p for k, p in self._previews.items() if p.expires_at > preview.created_at}
            if len(self._previews) >= 256:
                raise SettingsValidationError('Management access preview capacity exceeded.')
            self._previews[preview.reference] = deepcopy(preview)

    def preview(self, reference: str) -> ManagementAccessPreview | None:
        with self._lock:
            return deepcopy(self._previews.get(reference))

    def claim(self, preview: ManagementAccessPreview, previous: ManagementAccessObservation, now: int) -> ManagementAccessClaim:
        with self._lock:
            self._available(preview.draft['expectedRevision'])
            if (self._previews.get(preview.reference) != preview or preview.allowed is not True
                    or not preview.created_at <= now < preview.expires_at or previous.policy != self._policy):
                raise SettingsRevisionConflict('Native access preview or current observed policy changed.')
            self._claim = ManagementAccessClaim('acl-operation-' + uuid4().hex, deepcopy(preview), previous)
            self._previews.clear(); return deepcopy(self._claim)

    def _owned(self, claim: ManagementAccessClaim) -> None:
        if self._claim != claim:
            raise SettingsRevisionConflict('Management access operation ownership changed.')

    def mark_applied(self, claim: ManagementAccessClaim, observed: ManagementAccessObservation, event: Mapping[str, Any]) -> ManagementAccessSnapshot:
        copied = deepcopy(dict(event)); _ref(copied.get('id'))
        with self._lock:
            self._owned(claim)
            if observed.policy != claim.preview.candidate:
                raise SettingsRevisionConflict('Observed access policy does not match the native claim.')
            self._policy = observed.policy; self._version += 1; self._audit.append(copied)
            return self.read()

    def read_audit(self, reference: str) -> Mapping[str, Any] | None:
        with self._lock:
            return deepcopy(next((e for e in self._audit if e['id'] == reference), None))

    def release(self, claim: ManagementAccessClaim) -> None:
        with self._lock:
            self._owned(claim); self._claim = None

    def fail(self, claim: ManagementAccessClaim, event: Mapping[str, Any], recovered: bool) -> None:
        copied = deepcopy(dict(event)); _ref(copied.get('id'))
        if type(recovered) is not bool:
            raise SettingsValidationError('Recovery proof must be Boolean.')
        with self._lock:
            self._owned(claim)
            if recovered:
                self._policy = claim.previous.policy; self._claim = None
            self._version += 1; self._audit.append(copied)

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class ManagementAccessService:
    def __init__(self, store: ManagementAccessStore, driver: ManagementAccessDriver, *,
                 authorize: Callable[[SettingsActor, str], bool], clock: Callable[[], float] = time.time) -> None:
        if not callable(authorize):
            raise SettingsValidationError('Current native management access authority is required.')
        self.store = store; self.driver = driver; self.authorize = authorize; self.clock = clock

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            allowed = isinstance(actor, SettingsActor) and permission in actor.capabilities and self.authorize(actor, permission) is True
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError('Current native authority does not allow this management access operation.')

    def _snapshot(self, expected: str | None = None, *, claim_allowed: bool = False) -> ManagementAccessSnapshot:
        s = self.store.read()
        if not isinstance(s, ManagementAccessSnapshot) or not isinstance(s.policy, ManagementPolicy) or type(s.applying) is not bool:
            raise SettingsValidationError('Invalid native management policy snapshot.')
        _ref(s.revision)
        if (expected is not None and s.revision != expected) or (s.applying and not claim_allowed):
            raise SettingsRevisionConflict('Management access changed or recovery requires reconciliation.')
        return s

    @staticmethod
    def _projection(policy: ManagementPolicy, revision: str) -> dict[str, Any]:
        return {target: {'target': target, 'revision': revision, 'enabled': getattr(policy, target).enabled,
                        'sources': [{'cidr': e.cidr, 'expiresAt': e.expires_at} for e in getattr(policy, target).sources]}
                for target in ('web', 'ssh')}

    def _observed(self, desired: ManagementPolicy) -> ManagementAccessObservation:
        o = self.driver.observe()
        if (not isinstance(o, ManagementAccessObservation) or o.policy != desired
                or o.web_enforced != desired.web.enabled or o.ssh_enforced != desired.ssh.enabled):
            raise ManagementAccessUnverified('Actual Web/API and SSH enforcement does not match the native policy.')
        return o

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, 'acl.read'); s = self._snapshot(); self._observed(s.policy); self._require(actor, 'acl.read')
        return {'revision': s.revision, 'policy': self._projection(s.policy, s.revision)}

    def _safety(self, actor: SettingsActor, candidate: ManagementPolicy, before: ManagementPolicy,
                revision: str, seconds: int) -> tuple[dict[str, Any], list[str]]:
        self._require(actor, 'acl.read'); self._require(actor, 'acl.configure')
        c = self.driver.context(actor)
        if not isinstance(c, ManagementAccessContext):
            raise SettingsValidationError('Actual native connection and recovery evidence is required.')
        now = _time(self.clock())
        source = resolve_web_source(c.direct_web_peer, c.forwarded_for, trusted_proxy_cidrs=c.trusted_proxy_cidrs)
        base = preview_change(candidate, current_web_source=source, current_ssh_source=c.current_ssh_source,
            emergency_console_confirmed=c.emergency_console_confirmed, ssh_enforcement_supported=c.ssh_enforcement_supported,
            rollback_seconds=seconds, now=now)
        horizon = preview_change(candidate, current_web_source=source, current_ssh_source=c.current_ssh_source,
            emergency_console_confirmed=c.emergency_console_confirmed, ssh_enforcement_supported=c.ssh_enforcement_supported,
            rollback_seconds=seconds, now=now + seconds)
        blockers = list(base.blockers)
        for condition, blocker in ((not c.web_enforcement_supported and (candidate.web.enabled or candidate.web != before.web), 'WEB_ENFORCEMENT_UNAVAILABLE'),
                (not c.ssh_enforcement_supported and candidate.ssh != before.ssh, 'SSH_ENFORCEMENT_UNAVAILABLE'),
                (not c.rollback_ready, 'ROLLBACK_UNAVAILABLE'), (not c.recent_mfa_verified, 'RECENT_MFA_REQUIRED'),
                (not c.audit_ready, 'AUDIT_UNAVAILABLE'),
                (base.safe and (not horizon.web_decision.allowed or not horizon.ssh_decision.allowed), 'SOURCE_EXPIRES_DURING_RECOVERY')):
            if condition and blocker not in blockers:
                blockers.append(blocker)
        projection = self._projection(candidate, revision)
        # Existing review panel understands pure-engine blockers; lifecycle blockers
        # are separate and authoritative in the enclosing common page preview.
        projection['preview'] = {'sshRevision': revision, 'webRevision': revision, 'safe': base.safe,
            'blockers': list(base.blockers), 'rollbackSeconds': seconds,
            'sshDecision': {'allowed': base.ssh_decision.allowed, 'reason': base.ssh_decision.reason.value},
            'webDecision': {'allowed': base.web_decision.allowed, 'reason': base.web_decision.reason.value}}
        self._require(actor, 'acl.configure')
        return projection, blockers

    def preview(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'acl.configure'); self._require(actor, 'acl.read')
        draft, candidate = _draft(request, _time(self.clock())); s = self._snapshot(draft['expectedRevision']); self._observed(s.policy)
        if candidate == s.policy:
            raise SettingsValidationError('No pending management access change remains.')
        projection, blockers = self._safety(actor, candidate, s.policy, s.revision, draft['rollbackSeconds'])
        now = _time(self.clock()); p = ManagementAccessPreview('acl-preview-' + uuid4().hex, actor.subject, draft, candidate, now, now + 300, not blockers)
        self.store.register_preview(p)
        return {'previewRef': p.reference, 'expectedRevision': s.revision, 'expiresAt': p.expires_at * 1000,
                'allowed': p.allowed, 'blockers': blockers, 'policy': projection, 'draft': deepcopy(draft)}

    def _plan(self, p: ManagementAccessPreview | None, actor: SettingsActor, draft: dict[str, Any]) -> ManagementAccessPreview:
        if not isinstance(p, ManagementAccessPreview):
            raise SettingsValidationError('A stored native access preview is required.')
        if p.actor != actor.subject:
            raise SettingsPermissionError('The native access preview belongs to another actor.')
        if p.draft != draft or not p.created_at <= _time(self.clock()) < p.expires_at:
            raise SettingsValidationError('Native access preview is mismatched or expired.')
        if p.allowed is not True:
            raise SettingsPermissionError('Native management access safety is not established.')
        return p

    @staticmethod
    def _event(actor: SettingsActor, operation: str, action: str, now: int) -> dict[str, Any]:
        return {'id': 'acl-audit-' + uuid4().hex, 'actor': actor.subject, 'operation': operation, 'action': action, 'timestamp': now}

    def apply(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, 'acl.configure'); self._require(actor, 'acl.read')
        if not isinstance(request, Mapping) or set(request) != {'draft', 'previewRef', 'confirm'} or request['confirm'] is not True:
            raise SettingsValidationError('The exact reviewed access intent and explicit confirmation are required.')
        draft, candidate = _draft(request['draft'], _time(self.clock())); _ref(request['previewRef'])
        s = self._snapshot(draft['expectedRevision']); before = self._observed(s.policy)
        p = self._plan(self.store.preview(request['previewRef']), actor, draft)
        _, blockers = self._safety(actor, candidate, s.policy, s.revision, draft['rollbackSeconds'])
        if blockers:
            raise SettingsPermissionError('Current native management access safety is not established.')
        claim = self.store.claim(p, before, _time(self.clock()))
        if not isinstance(claim, ManagementAccessClaim) or claim.preview != p or claim.previous != before:
            raise ManagementAccessUnverified('Exclusive native access-policy operation was not proven.')
        _ref(claim.reference); confirm_attempted = False; started = _time(self.clock())
        try:
            if self.driver.arm_rollback(claim.reference, before, draft['rollbackSeconds']) is not True:
                raise ManagementAccessUnverified('Native access recovery timer was not proven armed.')
            self._plan(p, actor, draft)
            _, blockers = self._safety(actor, candidate, s.policy, s.revision, draft['rollbackSeconds'])
            current = self._snapshot(s.revision, claim_allowed=True)
            if blockers or not current.applying or current.policy != s.policy:
                raise ManagementAccessUnverified('Access safety or exclusive state changed after recovery setup.')
            self.driver.apply(claim.reference, candidate); observed = self._observed(candidate)
            self._require(actor, 'acl.configure')
            _, blockers = self._safety(actor, candidate, s.policy, s.revision, draft['rollbackSeconds'])
            if blockers:
                raise ManagementAccessUnverified('Current access/recovery proof changed after native apply.')
            event = self._event(actor, claim.reference, 'acl.apply.verified', started)
            saved = self.store.mark_applied(claim, observed, event)
            if (not isinstance(saved, ManagementAccessSnapshot) or not saved.applying or saved.revision == s.revision
                    or saved.policy != candidate or self.store.read_audit(event['id']) != event):
                raise ManagementAccessUnverified('Applied access state and audit were not independently persisted.')
            confirm_attempted = True
            if self.driver.confirm(claim.reference) is not True:
                raise ManagementAccessUnverified('Native recovery timer cancellation was not proven.')
            self._require(actor, 'acl.read'); self._require(actor, 'acl.configure')
            final = self._snapshot(saved.revision, claim_allowed=True); self._observed(candidate)
            if not final.applying or final.policy != candidate:
                raise ManagementAccessUnverified('Native access state changed before ownership release.')
            self.store.release(claim)
            return {'applied': True, 'revision': final.revision, 'auditReference': event['id'], 'policy': self._projection(candidate, final.revision)}
        except Exception:
            recovered = False
            if not confirm_attempted:
                try:
                    restored = self.driver.rollback(claim.reference) is True
                    recovered = restored and self.driver.observe() == before
                except Exception:
                    recovered = False
            failure = self._event(actor, claim.reference, 'acl.apply.rolled_back' if recovered else 'acl.apply.unknown', started)
            try:
                self.store.fail(claim, failure, recovered)
            except Exception:
                recovered = False
            raise ManagementAccessUnverified('Management access was not verified; ' + ('prior state and recovery timer restored.' if recovered else 'native operation/recovery reconciliation is required.')) from None
