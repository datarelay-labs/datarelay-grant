"""Native Control Administration HTTPS/Network REST binding (root gateway opt-in).

All writes require an authenticated administrator, CSRF, fresh verified MFA,
an installed narrow ingress gateway, independent live readback and durable
host rollback. The UI never supplies command strings, filesystem paths or keys.
"""
from __future__ import annotations

import json
import secrets
import sqlite3
from typing import Any

from .embedded_runtime import HttpFailure
from .native_ingress_bridge import IngressGatewayUnavailable
from .host_native_ingress import NativeIngressError

_NETWORK_POLICY = "native_ingress_network_desired"


def _status(svc):
    try:
        state = svc.native_ingress.status()
        active = state["active"]
        cert = state["certificate"]
        if (not isinstance(active, dict) or set(active) != {"http_port", "https_port", "redirect"}
                or type(active["redirect"]) is not bool
                or any(type(active[k]) is not int or not 1024 <= active[k] <= 65535
                       for k in ("http_port", "https_port"))
                or active["http_port"] == active["https_port"]
                or not isinstance(cert, dict) or cert.get("https_active") is not True
                or cert.get("https_listener_active") is not True
                or not cert.get("certificate_not_after")
                or not isinstance(state.get("pending"), bool)):
            raise NativeIngressError("Native ingress did not return qualified socket evidence.")
        return state
    except (IngressGatewayUnavailable, NativeIngressError, ValueError, KeyError, TypeError) as exc:
        raise HttpFailure(503, "Native ingress and its rollback state could not be independently verified.") from exc


def _desired(c: sqlite3.Connection, active: dict):
    row = c.execute("SELECT value,revision FROM policies WHERE key=?", (_NETWORK_POLICY,)).fetchone()
    if row is None:
        return dict(active), 0, None
    try:
        value = json.loads(row["value"])
        if (not isinstance(value, dict)
                or set(value) != {"http_port", "https_port", "owner", "expires", "applied"}
                or any(type(value[k]) is not int or not 1024 <= value[k] <= 65535
                       for k in ("http_port", "https_port"))
                or value["http_port"] == value["https_port"]
                or not isinstance(value["owner"], str) or len(value["owner"]) != 64
                or type(value["expires"]) is not int or type(value["applied"]) is not bool):
            raise ValueError("Unsafe desired network state")
        return dict(http_port=value["http_port"], https_port=value["https_port"],
                    redirect=active["redirect"]), row["revision"], value
    except (ValueError, TypeError) as exc:
        raise HttpFailure(503, "Saved native network policy is invalid.") from exc


def _admin_mfa(session: sqlite3.Row, now: int):
    if (not session["factor_verified"] or now-session["created"] > 600):
        raise HttpFailure(403, "Recent verified MFA is required for host ingress changes.")


def _apply(svc, target: dict):
    # No ambient root privileges in the Web/ASGI process. Explicit staged
    # mutation is owned by a fixed privileged helper with a rescue watchdog.
    operation = "ing-"+secrets.token_hex(10)
    try:
        svc.native_ingress.stage(operation, target)
        svc.native_ingress.confirm(operation)
        current = _status(svc)
        if current["pending"] or current["active"] != target:
            raise HttpFailure(503, "Native ingress confirmation disagrees with active listeners.")
        return current
    except HttpFailure:
        raise
    except (IngressGatewayUnavailable, NativeIngressError, ValueError, TypeError) as exc:
        # A process crash after stage leaves the independent root rescue timer
        # armed. Never cancel it or claim success on an ambiguous mutation.
        raise HttpFailure(503, "Native ingress apply was not verified; timed rollback remains authoritative.") from exc


def dispatch_ingress(svc, c: sqlite3.Connection, method: str, suffix: str,
                     body: dict[str, Any], actor: str, session: sqlite3.Row, now: int):
    current = _status(svc)
    active, cert = current["active"], current["certificate"]
    if method == "GET" and suffix == "admin/https-settings":
        observed = dict(cert)
        observed.update(redirect_http_to_https=active["redirect"],
                        redirect_http_to_https_effective=active["redirect"],
                        http_listener_active=True, https_listener_active=True,
                        proxy_status="unknown", proxy_health_ok=None,
                        restart_required_after_save=False,
                        browser_http_url="http://127.0.0.1:"+str(active["http_port"]),
                        browser_https_url="https://127.0.0.1:"+str(active["https_port"]),
                        current_access_url="https://127.0.0.1:"+str(active["https_port"]))
        return 200, observed, None
    if method == "GET" and suffix == "admin/network-settings":
        desired, _, intent = _desired(c, active)
        # An unapplied Save is private to its owning authenticated session.
        # Other admins and expired/applied intents must see proven live socket
        # state, never a stale or unauthorized "restart required" instruction.
        own_live_intent = (intent is not None and intent["owner"] == session["id"]
                           and not intent["applied"] and now <= intent["expires"])
        visible = desired if own_live_intent else active
        return 200, dict(
            http_port=visible["http_port"], https_port=visible["https_port"],
            env_example=dict(GDC_HTTP_PORT=str(visible["http_port"]),
                             GDC_HTTPS_PORT=str(visible["https_port"])),
            restart_required=own_live_intent and (
                visible["http_port"] != active["http_port"]
                or visible["https_port"] != active["https_port"]),
            restart_command="Apply via the scoped Foundation native ingress gateway."), None
    if method == "PUT" and suffix == "admin/https-settings":
        _admin_mfa(session, now)
        fields = {"enabled", "certificate_ip_addresses", "certificate_dns_names",
                  "redirect_http_to_https", "certificate_valid_days", "regenerate_certificate"}
        if (set(body) != fields or body["enabled"] is not True
                or type(body["redirect_http_to_https"]) is not bool
                or type(body["regenerate_certificate"]) is not bool
                or type(body["certificate_valid_days"]) is not int):
            raise HttpFailure(400, "Only explicit preprovisioned TLS settings are accepted.")
        if body["regenerate_certificate"]:
            raise HttpFailure(503, "Certificate issuance requires a qualified operator-provisioned issuer.")
        if (body["certificate_ip_addresses"] != cert["certificate_ip_addresses"]
                or body["certificate_dns_names"] != cert["certificate_dns_names"]
                or body["certificate_valid_days"] != cert["certificate_valid_days"]):
            raise HttpFailure(409, "TLS identity/expiry may not change without a preprovisioned certificate.")
        if current["pending"]:
            raise HttpFailure(409, "Native ingress recovery is already active.")
        target = dict(active, redirect=body["redirect_http_to_https"])
        if target != active:
            result = _apply(svc, target)
            svc._audit(c, actor, "host.https.redirect.applied",
                       {"redirect": target["redirect"], "http_port": target["http_port"],
                        "https_port": target["https_port"]})
        else:
            result = current
        return 200, dict(ok=True, restart_required=False,
                         certificate_not_after=result["certificate"]["certificate_not_after"],
                         message="Verified native HTTPS proxy settings; certificate remains operator-managed.",
                         proxy_reload_applied=target != active,
                         proxy_https_effective=True, proxy_fallback_to_http=False), None
    if method == "PUT" and suffix == "admin/network-settings":
        _admin_mfa(session, now)
        if set(body) != {"http_port", "https_port"} or any(
            type(body[k]) is not int or not 1024 <= body[k] <= 65535 for k in body
        ) or body["http_port"] == body["https_port"]:
            raise HttpFailure(400, "Select distinct unprivileged browser ports.")
        if current["pending"]:
            raise HttpFailure(409, "Finish the current native ingress recovery first.")
        if (body["https_port"] != active["https_port"]
                and not svc.native_ingress_migrate_origin):
            # The embedded origin/secure-cookie/CSRF authority is fixed at
            # process startup. A proxy-only HTTPS port migration would strand
            # authenticated clients until an independently recovered app
            # origin restart exists; never advertise such an apply as safe.
            raise HttpFailure(503, "HTTPS port migration needs a qualified runtime-origin recovery driver.")
        values = dict(http_port=body["http_port"], https_port=body["https_port"])
        # The saved intent is bound to the exact authenticated/MFA session,
        # short-lived and single-use. Another administrator cannot apply it.
        persisted = dict(values, owner=session["id"], expires=now+300, applied=False)
        prior = c.execute("SELECT revision FROM policies WHERE key=?", (_NETWORK_POLICY,)).fetchone()
        if prior is None:
            c.execute("INSERT INTO policies(key,value,revision) VALUES(?,?,1)",
                      (_NETWORK_POLICY, json.dumps(persisted)))
        else:
            c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key=?",
                      (json.dumps(persisted),_NETWORK_POLICY))
        svc._audit(c, actor, "host.network.desired.saved", values)
        return 200, dict(**values,
                         env_example=dict(GDC_HTTP_PORT=str(values["http_port"]),
                                          GDC_HTTPS_PORT=str(values["https_port"])),
                         restart_required=True,
                         restart_command="Apply via the scoped Foundation native ingress gateway.",
                         message="Desired proxy ports saved; current listeners are unchanged."), None
    if method == "POST" and suffix == "admin/network-settings/apply":
        _admin_mfa(session, now)
        if body:
            raise HttpFailure(400, "Native network apply does not accept commands or paths.")
        if current["pending"]:
            raise HttpFailure(409, "Native ingress recovery is pending.")
        target, rev, intent = _desired(c, active)
        if not rev or intent is None:
            raise HttpFailure(409, "Save desired network ports before applying.")
        if (intent["owner"] != session["id"] or intent["applied"] or now > intent["expires"]):
            raise HttpFailure(409, "Network apply requires this session's current unconsumed save.")
        if target != active:
            current = _apply(svc, target)
            svc._audit(c, actor, "host.network.ports.applied", target)
        c.execute("UPDATE policies SET value=?,revision=revision+1 WHERE key=? AND revision=?",
                  (json.dumps(dict(intent, applied=True)),_NETWORK_POLICY,rev))
        return 200, dict(success=True, command="scoped-foundation-ingress",
                         stdout="", stderr="", exit_code=0,
                         message="Native HTTP and TLS ports verified; previous ports recovered or retired."), None
    raise HttpFailure(503, "This privileged TLS/Network operation has no approved native driver.")
