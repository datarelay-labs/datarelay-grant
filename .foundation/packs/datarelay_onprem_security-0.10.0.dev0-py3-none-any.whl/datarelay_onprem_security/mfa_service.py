"""Reusable MFA lifecycle orchestration over product-native authority/storage ports.

Foundation owns validation, TOTP/recovery semantics, replay protection, lifecycle
state transitions, audit construction and session-epoch invalidation. A consuming
product binds its authenticated authorization, protected secret storage, password
pre-auth challenge and session enforcement. This module issues no login session,
JWT/cookie, host permission or production identity database.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, replace
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import math
import re
import time
import unicodedata

from .timezone_service import (
    SettingsActor,
    SettingsPermissionError,
    SettingsRevisionConflict,
    SettingsValidationError,
)
from .totp import (
    new_recovery_codes,
    new_totp_secret,
    provisioning_uri,
    verify_totp,
)

_REF = re.compile(r"[a-z][a-z0-9_.-]{0,127}\Z", re.ASCII)
_RECOVERY = re.compile(r"[0-9a-f]{24}\Z", re.ASCII)
_METHODS = ("totp", "recovery_code")


class MfaVerificationUnverified(RuntimeError):
    """Factor was consumed but native pre-auth completion was not proven."""


def _ref(value: object, label: str = "reference") -> str:
    if not isinstance(value, str) or _REF.fullmatch(value) is None:
        raise SettingsValidationError("Invalid MFA " + label + ".")
    return value


def _time(value: object) -> float:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402300799:
        raise SettingsValidationError("Invalid native MFA clock evidence.")
    return float(value)


def _subject(value: object) -> str:
    if (
        not isinstance(value, str)
        or not 0 < len(value) <= 256
        or any(ord(char) < 33 or ord(char) == 127 for char in value)
    ):
        raise SettingsValidationError("Invalid native MFA subject.")
    return value


def _text(value: object, maximum: int, label: str) -> str:
    if (
        not isinstance(value, str)
        or not 0 < len(value) <= maximum
        or value != value.strip()
        or any(unicodedata.category(char).startswith("C") for char in value)
    ):
        raise SettingsValidationError("Invalid MFA " + label + ".")
    return value


def _counter(value: object) -> int | None:
    if value is None:
        return None
    if type(value) is not int or not 0 <= value <= 2**64 - 1:
        raise SettingsValidationError("Invalid stored MFA replay counter.")
    return value


def _epoch(value: object) -> int:
    if type(value) is not int or not 0 <= value < 2**53 - 1:
        raise SettingsValidationError("Invalid native session epoch.")
    return value


def _digest(value: object) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value, re.ASCII):
        raise SettingsValidationError("Invalid protected recovery digest.")
    return value


@dataclass(frozen=True)
class MfaReadiness:
    """Current server-derived evidence for a privileged MFA lifecycle action."""

    reauthenticated: bool = False
    recent_mfa_verified: bool = False
    audit_ready: bool = False
    recovery_ready: bool = False
    policy_change_ready: bool = False
    last_admin_recovery_ready: bool = False

    def __post_init__(self) -> None:
        if any(type(value) is not bool for value in vars(self).values()):
            raise SettingsValidationError("MFA readiness requires actual native Boolean evidence.")


@dataclass(frozen=True)
class MfaChallenge:
    """Server-created password-preauth challenge. Never construct from request body claims."""

    reference: str
    subject: str
    expected_revision: str
    session_epoch: int
    password_verified: bool
    issued_at: float
    expires_at: float
    methods: tuple[str, ...]

    def __post_init__(self) -> None:
        _ref(self.reference, "challenge reference")
        _subject(self.subject)
        _ref(self.expected_revision, "revision")
        _epoch(self.session_epoch)
        if type(self.password_verified) is not bool:
            raise SettingsValidationError("Invalid password-preauth evidence.")
        issued = _time(self.issued_at)
        expires = _time(self.expires_at)
        if expires <= issued or expires - issued > 900:
            raise SettingsValidationError("Invalid MFA challenge lifetime.")
        if (
            not isinstance(self.methods, tuple)
            or not self.methods
            or len(set(self.methods)) != len(self.methods)
            or any(method not in _METHODS for method in self.methods)
        ):
            raise SettingsValidationError("Invalid MFA challenge methods.")


@dataclass(frozen=True)
class PendingEnrollment:
    reference: str
    actor: str
    secret: str
    issuer: str
    account_label: str
    created_at: float
    expires_at: float

    def __post_init__(self) -> None:
        _ref(self.reference, "enrollment reference")
        _subject(self.actor)
        _text(self.secret, 256, "enrollment secret")
        _text(self.issuer, 128, "issuer")
        _text(self.account_label, 256, "account label")
        created = _time(self.created_at)
        expires = _time(self.expires_at)
        if expires <= created or expires - created > 900:
            raise SettingsValidationError("Invalid MFA enrollment lifetime.")


@dataclass(frozen=True)
class MfaSnapshot:
    """Internal protected state. Public projections MUST exclude secret/digests."""

    revision: str
    subject: str
    required: bool
    enrolled: bool
    secret: str | None
    last_counter: int | None
    recovery_digests: tuple[str, ...]
    session_epoch: int
    pending: PendingEnrollment | None = None

    def __post_init__(self) -> None:
        _ref(self.revision, "revision")
        _subject(self.subject)
        if type(self.required) is not bool or type(self.enrolled) is not bool:
            raise SettingsValidationError("Invalid native MFA state.")
        _epoch(self.session_epoch)
        _counter(self.last_counter)
        if not isinstance(self.recovery_digests, tuple) or len(self.recovery_digests) > 20:
            raise SettingsValidationError("Invalid protected recovery state.")
        for item in self.recovery_digests:
            _digest(item)
        if len(set(self.recovery_digests)) != len(self.recovery_digests):
            raise SettingsValidationError("Duplicate protected recovery digest.")
        if self.enrolled:
            if self.secret is None:
                raise SettingsValidationError("Enrolled MFA requires a protected TOTP secret.")
            _text(self.secret, 256, "TOTP secret")
        elif self.secret is not None or self.last_counter is not None or self.recovery_digests:
            raise SettingsValidationError("Unenrolled MFA cannot retain active factor material.")
        if self.pending is not None and not isinstance(self.pending, PendingEnrollment):
            raise SettingsValidationError("Invalid pending MFA enrollment.")


@dataclass(frozen=True)
class MfaMutation:
    value: MfaSnapshot
    event: dict[str, Any]


class MfaRecoveryCodec(Protocol):
    """Product-bound keyed recovery-code digest/compare implementation."""

    def digest(self, code: str) -> str: ...

    def matches(self, code: str, digest: str) -> bool: ...


class MfaNativeDriver(Protocol):
    """Current native authority/evidence and password-preauth challenge boundary."""

    def readiness(self, actor: SettingsActor, subject: str, action: str) -> MfaReadiness: ...
    def challenge(self, reference: str) -> MfaChallenge | None: ...
    def consume_challenge(self, reference: str, verification_reference: str) -> bool: ...


class MfaStore(Protocol):
    """Bind protected existing identity storage and an atomic audit transaction."""

    def read(self, subject: str) -> MfaSnapshot: ...
    def list_subjects(self) -> tuple[str, ...]: ...

    def transact(
        self,
        subject: str,
        expected_revision: str,
        build: Callable[[MfaSnapshot], MfaMutation],
    ) -> MfaSnapshot: ...


def _copy_snapshot(value: MfaSnapshot) -> MfaSnapshot:
    if not isinstance(value, MfaSnapshot):
        raise SettingsValidationError("Invalid native MFA snapshot.")
    return deepcopy(value)


class MemoryMfaStore:
    """Thread-safe synthetic reference store; never use as an authentication DB."""

    def __init__(self, records: list[Mapping[str, Any]]) -> None:
        if not isinstance(records, list) or not records or len(records) > 10000:
            raise SettingsValidationError("Invalid reference MFA directory.")
        self._lock = RLock()
        self._records: dict[str, dict[str, Any]] = {}
        self._versions: dict[str, int] = {}
        self._audit: list[dict[str, Any]] = []
        for raw in records:
            if not isinstance(raw, Mapping) or set(raw) != {
                "subject",
                "required",
                "enrolled",
                "secret",
                "lastCounter",
                "recoveryDigests",
                "sessionEpoch",
            }:
                raise SettingsValidationError("Invalid reference MFA record.")
            subject = _subject(raw["subject"])
            if subject in self._records:
                raise SettingsValidationError("Duplicate MFA subject.")
            snapshot = MfaSnapshot(
                "mfa-1",
                subject,
                raw["required"],
                raw["enrolled"],
                raw["secret"],
                raw["lastCounter"],
                tuple(raw["recoveryDigests"]),
                raw["sessionEpoch"],
                None,
            )
            self._records[subject] = self._record(snapshot)
            self._versions[subject] = 1

    @staticmethod
    def _record(snapshot: MfaSnapshot) -> dict[str, Any]:
        snapshot = _copy_snapshot(snapshot)
        return {
            "subject": snapshot.subject,
            "required": snapshot.required,
            "enrolled": snapshot.enrolled,
            "secret": snapshot.secret,
            "last_counter": snapshot.last_counter,
            "recovery_digests": tuple(snapshot.recovery_digests),
            "session_epoch": snapshot.session_epoch,
            "pending": deepcopy(snapshot.pending),
        }

    def _read_locked(self, subject: str) -> MfaSnapshot:
        subject = _subject(subject)
        raw = self._records.get(subject)
        if raw is None:
            raise SettingsValidationError("MFA subject is not current.")
        return MfaSnapshot(
            "mfa-" + str(self._versions[subject]),
            raw["subject"],
            raw["required"],
            raw["enrolled"],
            raw["secret"],
            raw["last_counter"],
            tuple(raw["recovery_digests"]),
            raw["session_epoch"],
            deepcopy(raw["pending"]),
        )

    def read(self, subject: str) -> MfaSnapshot:
        with self._lock:
            return deepcopy(self._read_locked(subject))

    def list_subjects(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted(self._records))

    def transact(
        self,
        subject: str,
        expected_revision: str,
        build: Callable[[MfaSnapshot], MfaMutation],
    ) -> MfaSnapshot:
        with self._lock:
            before = self._read_locked(subject)
            if before.revision != _ref(expected_revision, "revision"):
                raise SettingsRevisionConflict("MFA state changed. Refresh and retry.")
            mutation = build(deepcopy(before))
            if not isinstance(mutation, MfaMutation):
                raise SettingsValidationError("Invalid atomic MFA mutation.")
            after = _copy_snapshot(mutation.value)
            if after.subject != before.subject or after.revision != before.revision:
                raise SettingsValidationError("MFA mutation cannot replace native identity/revision.")
            event = deepcopy(dict(mutation.event))
            _ref(event.get("id"), "audit reference")
            if event.get("subject") != subject or not isinstance(event.get("action"), str):
                raise SettingsValidationError("Invalid MFA audit event.")
            # Never accept likely secret-bearing fields in the generic audit envelope.
            forbidden = {"secret", "code", "recoveryCodes", "recoveryDigests", "otpauthUri"}
            if forbidden.intersection(event):
                raise SettingsValidationError("MFA audit cannot contain factor material.")
            self._records[subject] = self._record(after)
            self._versions[subject] += 1
            self._audit.append(event)
            return self._read_locked(subject)

    def set_required_for_test(self, subject: str, required: bool) -> None:
        if type(required) is not bool:
            raise SettingsValidationError("Invalid synthetic MFA requirement.")
        with self._lock:
            current = self._read_locked(subject)
            raw = self._records[subject]
            raw["required"] = required
            self._versions[subject] += 1
            # Keep test helper bounded to policy state only.
            MfaSnapshot(
                "mfa-" + str(self._versions[subject]),
                current.subject,
                required,
                current.enrolled,
                current.secret,
                current.last_counter,
                current.recovery_digests,
                current.session_epoch,
                current.pending,
            )

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class MfaLifecycleService:
    """Complete common MFA lifecycle without issuing an authenticated session."""

    def __init__(
        self,
        store: MfaStore,
        driver: MfaNativeDriver,
        recovery_codec: MfaRecoveryCodec,
        *,
        authorize: Callable[[SettingsActor, str], bool],
        clock: Callable[[], float] = time.time,
        secret_factory: Callable[[], str] = new_totp_secret,
        recovery_factory: Callable[[int], tuple[str, ...]] = new_recovery_codes,
    ) -> None:
        if not callable(authorize) or not callable(clock) or not callable(secret_factory) or not callable(recovery_factory):
            raise SettingsValidationError("MFA service requires native authority and bounded factories.")
        self.store = store
        self.driver = driver
        self.recovery_codec = recovery_codec
        self.authorize = authorize
        self.clock = clock
        self.secret_factory = secret_factory
        self.recovery_factory = recovery_factory

    def _now(self) -> float:
        return _time(self.clock())

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            allowed = (
                isinstance(actor, SettingsActor)
                and permission in actor.capabilities
                and self.authorize(actor, permission) is True
            )
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError("Current native authority does not allow this MFA operation.")

    def _snapshot(self, subject: str, expected: str | None = None) -> MfaSnapshot:
        snapshot = _copy_snapshot(self.store.read(_subject(subject)))
        if expected is not None and snapshot.revision != _ref(expected, "revision"):
            raise SettingsRevisionConflict("MFA state changed. Refresh and retry.")
        return snapshot

    @staticmethod
    def _public(snapshot: MfaSnapshot) -> dict[str, Any]:
        return {
            "subject": snapshot.subject,
            "revision": snapshot.revision,
            "required": snapshot.required,
            "enrolled": snapshot.enrolled,
            "recoveryCodesRemaining": len(snapshot.recovery_digests),
            "sessionEpoch": snapshot.session_epoch,
        }

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, "mfa.read.self")
        snapshot = self._snapshot(actor.subject)
        self._require(actor, "mfa.read.self")
        return self._public(snapshot)

    def read_managed(self, actor: SettingsActor) -> dict[str, Any]:
        """Return bounded MFA metadata for product-authorized administrators only."""
        self._require(actor, "mfa.manage")
        try:
            subjects = self.store.list_subjects()
        except Exception:
            raise SettingsValidationError("Native MFA directory listing is unavailable.") from None
        if (
            not isinstance(subjects, tuple)
            or len(subjects) > 10000
            or len(set(subjects)) != len(subjects)
        ):
            raise SettingsValidationError("Invalid native MFA directory listing.")
        records = [self._public(self._snapshot(_subject(subject))) for subject in subjects]
        self._require(actor, "mfa.manage")
        return {
            "currentUserId": actor.subject,
            "complete": True,
            "records": records,
        }

    def _readiness(self, actor: SettingsActor, subject: str, action: str) -> MfaReadiness:
        value = self.driver.readiness(actor, subject, action)
        if not isinstance(value, MfaReadiness):
            raise SettingsValidationError("Current native MFA readiness is required.")
        return value

    @staticmethod
    def _basic_ready(value: MfaReadiness) -> bool:
        return value.reauthenticated and value.audit_ready and value.recovery_ready

    @staticmethod
    def _privileged_ready(value: MfaReadiness) -> bool:
        return MfaLifecycleService._basic_ready(value) and value.recent_mfa_verified

    def _event(self, actor: str, subject: str, action: str) -> dict[str, Any]:
        return {
            "id": "mfa-audit-" + uuid4().hex,
            "actor": _subject(actor),
            "subject": _subject(subject),
            "action": action,
            "timestamp": self._now(),
        }

    def begin_enrollment(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, "mfa.enroll.self")
        if not isinstance(request, Mapping) or set(request) != {"expectedRevision", "issuer", "accountLabel"}:
            raise SettingsValidationError("Submit only enrollment revision and display labels.")
        expected = _ref(request["expectedRevision"], "revision")
        issuer = _text(request["issuer"], 128, "issuer")
        account_label = _text(request["accountLabel"], 256, "account label")
        before = self._snapshot(actor.subject, expected)
        now = self._now()
        if before.enrolled or (before.pending is not None and before.pending.expires_at > now):
            raise SettingsValidationError("MFA enrollment is already active or pending.")
        readiness = self._readiness(actor, actor.subject, "enroll")
        if not self._basic_ready(readiness):
            raise SettingsPermissionError("Enrollment requires current reauthentication, recovery and audit readiness.")
        try:
            secret = self.secret_factory()
            uri = provisioning_uri(secret, issuer=issuer, account=account_label)
        except Exception:
            raise SettingsValidationError("Native MFA secret generation was rejected.") from None
        pending = PendingEnrollment(
            "mfa-enrollment-" + uuid4().hex,
            actor.subject,
            secret,
            issuer,
            account_label,
            now,
            now + 600,
        )
        event = self._event(actor.subject, actor.subject, "mfa.enrollment.started")

        def build(current: MfaSnapshot) -> MfaMutation:
            self._require(actor, "mfa.enroll.self")
            if (
                current != before
                or current.enrolled
                or (current.pending is not None and current.pending.expires_at > now)
            ):
                raise SettingsRevisionConflict("MFA state changed during enrollment.")
            return MfaMutation(replace(current, pending=pending), event)

        after = self.store.transact(actor.subject, expected, build)
        verified = self._snapshot(actor.subject, after.revision)
        if verified.pending != pending or verified.enrolled:
            raise MfaVerificationUnverified("Pending MFA enrollment was not independently verified.")
        return {
            "revision": verified.revision,
            "enrollmentRef": pending.reference,
            "expiresAt": pending.expires_at * 1000,
            "issuer": issuer,
            "accountLabel": account_label,
            "secret": secret,
            "otpauthUri": uri,
        }

    def confirm_enrollment(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, "mfa.enroll.self")
        if not isinstance(request, Mapping) or set(request) != {"expectedRevision", "enrollmentRef", "code"}:
            raise SettingsValidationError("Submit only current enrollment confirmation fields.")
        expected = _ref(request["expectedRevision"], "revision")
        enrollment_ref = _ref(request["enrollmentRef"], "enrollment reference")
        code = request["code"]
        before = self._snapshot(actor.subject, expected)
        pending = before.pending
        now = self._now()
        if (
            pending is None
            or pending.reference != enrollment_ref
            or pending.actor != actor.subject
            or not pending.created_at <= now < pending.expires_at
            or before.enrolled
        ):
            raise SettingsValidationError("A current matching MFA enrollment is required.")
        readiness = self._readiness(actor, actor.subject, "confirm_enrollment")
        if not self._basic_ready(readiness):
            raise SettingsPermissionError("MFA enrollment confirmation requires current reauthentication and recovery.")
        counter = verify_totp(pending.secret, code, now=now, last_counter=None)
        if counter is None:
            raise SettingsValidationError("Authentication code was not accepted.")
        try:
            raw_codes = self.recovery_factory(8)
            if not isinstance(raw_codes, tuple) or len(raw_codes) != 8 or len(set(raw_codes)) != len(raw_codes):
                raise ValueError("invalid recovery set")
            digests = tuple(_digest(self.recovery_codec.digest(code_value)) for code_value in raw_codes)
        except Exception:
            raise SettingsValidationError("Native recovery-code protection was rejected.") from None
        event = self._event(actor.subject, actor.subject, "mfa.enrollment.confirmed")

        def build(current: MfaSnapshot) -> MfaMutation:
            self._require(actor, "mfa.enroll.self")
            if current != before or current.pending != pending:
                raise SettingsRevisionConflict("MFA enrollment changed before confirmation.")
            return MfaMutation(
                replace(
                    current,
                    enrolled=True,
                    secret=pending.secret,
                    last_counter=counter,
                    recovery_digests=digests,
                    session_epoch=current.session_epoch + 1,
                    pending=None,
                ),
                event,
            )

        after = self.store.transact(actor.subject, expected, build)
        observed = self._snapshot(actor.subject, after.revision)
        if (
            not observed.enrolled
            or observed.secret != pending.secret
            or observed.last_counter != counter
            or observed.recovery_digests != digests
            or observed.session_epoch != before.session_epoch + 1
            or observed.pending is not None
        ):
            raise MfaVerificationUnverified("Enrolled MFA state was not independently verified.")
        return {**self._public(observed), "recoveryCodes": raw_codes}

    def _challenge(self, reference: str) -> MfaChallenge:
        try:
            challenge = self.driver.challenge(reference)
        except Exception:
            challenge = None
        if not isinstance(challenge, MfaChallenge) or challenge.reference != reference:
            raise SettingsValidationError("A current native password-preauth challenge is required.")
        now = self._now()
        if not challenge.issued_at <= now < challenge.expires_at:
            raise SettingsValidationError("MFA challenge expired or is not active.")
        if not challenge.password_verified:
            raise SettingsPermissionError("Password preauthentication is not verified.")
        return challenge

    def verify_challenge(self, request: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(request, Mapping) or set(request) != {"challengeRef", "method", "value"}:
            raise SettingsValidationError("Submit only native challenge reference, method and factor value.")
        reference = _ref(request["challengeRef"], "challenge reference")
        method = request["method"]
        value = request["value"]
        if method not in _METHODS or not isinstance(value, str) or not value:
            raise SettingsValidationError("Invalid MFA challenge submission.")
        challenge = self._challenge(reference)
        if method not in challenge.methods:
            raise SettingsPermissionError("MFA method is not allowed for this challenge.")
        before = self._snapshot(challenge.subject, challenge.expected_revision)
        if before.session_epoch != challenge.session_epoch:
            raise SettingsRevisionConflict("Password-preauth session epoch is stale.")
        if not before.enrolled or before.secret is None:
            raise SettingsPermissionError("MFA is not currently enrolled.")
        verification_reference = "mfa-verification-" + uuid4().hex
        event = {
            "id": "mfa-audit-" + uuid4().hex,
            "actor": challenge.subject,
            "subject": challenge.subject,
            "action": "mfa.challenge." + method,
            "timestamp": self._now(),
            "verificationReference": verification_reference,
        }

        def build(current: MfaSnapshot) -> MfaMutation:
            if current != before or current.session_epoch != challenge.session_epoch:
                raise SettingsRevisionConflict("MFA state changed during challenge verification.")
            if method == "totp":
                matched = verify_totp(
                    current.secret or "",
                    value,
                    now=self._now(),
                    last_counter=current.last_counter,
                )
                if matched is None:
                    raise SettingsValidationError("Authentication code was not accepted.")
                next_value = replace(current, last_counter=matched)
            else:
                if _RECOVERY.fullmatch(value.strip().lower()) is None:
                    raise SettingsValidationError("Recovery code was not accepted.")
                matched_index = None
                for index, digest in enumerate(current.recovery_digests):
                    try:
                        if self.recovery_codec.matches(value, digest) is True:
                            matched_index = index
                            break
                    except Exception:
                        raise SettingsValidationError("Recovery code verification was unavailable.") from None
                if matched_index is None:
                    raise SettingsValidationError("Recovery code was not accepted.")
                remaining = list(current.recovery_digests)
                del remaining[matched_index]
                next_value = replace(current, recovery_digests=tuple(remaining))
            return MfaMutation(next_value, event)

        after = self.store.transact(challenge.subject, challenge.expected_revision, build)
        observed = self._snapshot(challenge.subject, after.revision)
        try:
            consumed = self.driver.consume_challenge(reference, verification_reference) is True
        except Exception:
            consumed = False
        if not consumed:
            raise MfaVerificationUnverified(
                "MFA factor was consumed but password-preauth completion was not verified."
            )
        if observed.session_epoch != challenge.session_epoch:
            raise MfaVerificationUnverified("MFA verification cannot issue authority for a changed session epoch.")
        return {
            "verified": True,
            "verificationRef": verification_reference,
            "auditReference": event["id"],
            "method": method,
        }

    @staticmethod
    def _confirmed_request(request: Mapping[str, Any], *, extra: tuple[str, ...] = ()) -> dict[str, Any]:
        keys = {"expectedRevision", "confirm", *extra}
        if not isinstance(request, Mapping) or set(request) != keys or request["confirm"] is not True:
            raise SettingsValidationError("Exact current MFA revision and explicit confirmation are required.")
        _ref(request["expectedRevision"], "revision")
        return deepcopy(dict(request))

    def regenerate_recovery_codes(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, "mfa.recovery.self")
        draft = self._confirmed_request(request)
        before = self._snapshot(actor.subject, draft["expectedRevision"])
        if not before.enrolled:
            raise SettingsValidationError("MFA must be enrolled before recovery codes can be regenerated.")
        ready = self._readiness(actor, actor.subject, "regenerate_recovery")
        if not self._privileged_ready(ready):
            raise SettingsPermissionError("Recovery-code regeneration requires current MFA, reauthentication and recovery readiness.")
        try:
            raw_codes = self.recovery_factory(8)
            if not isinstance(raw_codes, tuple) or len(raw_codes) != 8 or len(set(raw_codes)) != 8:
                raise ValueError("invalid recovery set")
            digests = tuple(_digest(self.recovery_codec.digest(item)) for item in raw_codes)
        except Exception:
            raise SettingsValidationError("Native recovery-code protection was rejected.") from None
        event = self._event(actor.subject, actor.subject, "mfa.recovery.regenerated")

        def build(current: MfaSnapshot) -> MfaMutation:
            self._require(actor, "mfa.recovery.self")
            if current != before or not current.enrolled:
                raise SettingsRevisionConflict("MFA state changed before recovery rotation.")
            return MfaMutation(replace(current, recovery_digests=digests), event)

        after = self.store.transact(actor.subject, before.revision, build)
        observed = self._snapshot(actor.subject, after.revision)
        if observed.recovery_digests != digests:
            raise MfaVerificationUnverified("Recovery-code rotation was not independently verified.")
        return {**self._public(observed), "recoveryCodes": raw_codes}

    def disable(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, "mfa.disable.self")
        draft = self._confirmed_request(request)
        before = self._snapshot(actor.subject, draft["expectedRevision"])
        if before.required:
            raise SettingsPermissionError("Required MFA cannot be disabled until policy is changed.")
        if not before.enrolled:
            raise SettingsValidationError("MFA is not enrolled.")
        ready = self._readiness(actor, actor.subject, "disable")
        if not self._privileged_ready(ready):
            raise SettingsPermissionError("MFA disable requires current MFA, reauthentication, recovery and audit readiness.")
        event = self._event(actor.subject, actor.subject, "mfa.disabled")

        def build(current: MfaSnapshot) -> MfaMutation:
            self._require(actor, "mfa.disable.self")
            if current != before:
                raise SettingsRevisionConflict("MFA state changed before disable.")
            return MfaMutation(
                replace(
                    current,
                    enrolled=False,
                    secret=None,
                    last_counter=None,
                    recovery_digests=(),
                    pending=None,
                    session_epoch=current.session_epoch + 1,
                ),
                event,
            )

        after = self.store.transact(actor.subject, before.revision, build)
        observed = self._snapshot(actor.subject, after.revision)
        if observed.enrolled or observed.secret is not None or observed.session_epoch != before.session_epoch + 1:
            raise MfaVerificationUnverified("MFA disable/session invalidation was not independently verified.")
        return self._public(observed)

    def reset(self, actor: SettingsActor, subject: str, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, "mfa.manage")
        subject = _subject(subject)
        draft = self._confirmed_request(request)
        before = self._snapshot(subject, draft["expectedRevision"])
        ready = self._readiness(actor, subject, "reset")
        if not (
            self._privileged_ready(ready)
            and ready.last_admin_recovery_ready
        ):
            raise SettingsPermissionError("MFA reset requires current privileged recovery, policy and last-admin safeguards.")
        event = self._event(actor.subject, subject, "mfa.reset")

        def build(current: MfaSnapshot) -> MfaMutation:
            self._require(actor, "mfa.manage")
            if current != before:
                raise SettingsRevisionConflict("MFA state changed before reset.")
            return MfaMutation(
                replace(
                    current,
                    enrolled=False,
                    secret=None,
                    last_counter=None,
                    recovery_digests=(),
                    pending=None,
                    session_epoch=current.session_epoch + 1,
                ),
                event,
            )

        after = self.store.transact(subject, before.revision, build)
        observed = self._snapshot(subject, after.revision)
        if observed.enrolled or observed.required != before.required or observed.session_epoch != before.session_epoch + 1:
            raise MfaVerificationUnverified("MFA reset/session invalidation was not independently verified.")
        return self._public(observed)

    def set_requirement(
        self,
        actor: SettingsActor,
        subject: str,
        request: Mapping[str, Any],
    ) -> dict[str, Any]:
        self._require(actor, "mfa.requirement.manage")
        subject = _subject(subject)
        draft = self._confirmed_request(request, extra=("required",))
        if type(draft["required"]) is not bool:
            raise SettingsValidationError("MFA requirement must be Boolean.")
        before = self._snapshot(subject, draft["expectedRevision"])
        required = draft["required"]
        if required == before.required:
            raise SettingsValidationError("No MFA policy change remains.")
        if required and not before.enrolled:
            raise SettingsValidationError("An account must complete enrollment before MFA can become required.")
        ready = self._readiness(actor, subject, "set_requirement")
        if not (
            self._privileged_ready(ready)
            and ready.policy_change_ready
            and ready.last_admin_recovery_ready
        ):
            raise SettingsPermissionError("MFA policy change requires current privileged recovery and last-admin safeguards.")
        event = self._event(actor.subject, subject, "mfa.requirement.changed")

        def build(current: MfaSnapshot) -> MfaMutation:
            self._require(actor, "mfa.requirement.manage")
            if current != before:
                raise SettingsRevisionConflict("MFA state changed before policy update.")
            return MfaMutation(
                replace(
                    current,
                    required=required,
                    session_epoch=current.session_epoch + 1,
                ),
                event,
            )

        after = self.store.transact(subject, before.revision, build)
        observed = self._snapshot(subject, after.revision)
        if observed.required is not required or observed.session_epoch != before.session_epoch + 1:
            raise MfaVerificationUnverified("MFA policy/session invalidation was not independently verified.")
        return self._public(observed)
