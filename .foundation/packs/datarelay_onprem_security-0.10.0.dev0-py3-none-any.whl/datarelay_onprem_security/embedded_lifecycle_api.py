"""Privileged-by-auth (not root) Foundation Admin backup and retention API.

All disk paths are configured at startup, never selected by HTTP callers.
A separate systemd timer executes the same Foundation library as its own
unprivileged service account; no arbitrary OS command endpoint exists.
"""
from __future__ import annotations

import json
import sqlite3
from typing import Any

from .embedded_lifecycle import DEFAULT_KEEP_LAST, POLICY_KEY
from .host_sqlite_backup import NativeBackupError


def dispatch_lifecycle(svc, c: sqlite3.Connection, method: str, path: str,
                       body: dict[str, Any], headers: dict[str, str],
                       session: sqlite3.Row | None, now: int):
    from .embedded_runtime import HttpFailure

    if session is None:
        raise HttpFailure(401, "Authentication is required for encrypted backups.")
    owner = svc._user(c, session["user_name"])
    if owner["status"] != "ACTIVE" or owner["role"] != "ADMINISTRATOR":
        raise HttpFailure(403, "Only an administrator can manage host backup and retention.")
    if method != "GET":
        svc._csrf(session, headers)
    lifecycle = svc.native_lifecycle
    if lifecycle is None:
        raise HttpFailure(503, "A native encrypted backup repository is not installed.")

    row = c.execute("SELECT value,revision FROM policies WHERE key=?",
                    (POLICY_KEY,)).fetchone()
    settings = json.loads(row["value"]) if row else {"keepLast": lifecycle.default_keep_last}
    count = settings.get("keepLast")
    if type(count) is not int or not 1 <= count <= 365:
        raise HttpFailure(503, "Unsafe persisted backup policy.")
    revision = "host-retention-"+str(row["revision"] if row else 0)

    try:
        if method == "GET" and path == "/api/foundation/host/backup":
            current = lifecycle.read(count)
            return 200, dict(current, retentionRevision=revision), None
        if method == "GET" and path == "/api/foundation/host/retention":
            return 200, dict(keepLast=count, revision=revision, enabled=True), None
        if method == "POST" and path == "/api/foundation/host/backup/create":
            if body != {"confirm": True}:
                raise HttpFailure(400, "Explicit encrypted backup creation confirmation required.")
            result = lifecycle.create()
            svc._audit(c, owner["name"], "host.backup.created",
                       {"reference": result["reference"]})
            return 200, result, None
        if method == "POST" and path == "/api/foundation/host/backup/verify":
            if set(body) != {"reference"} or not isinstance(body["reference"], str):
                raise HttpFailure(400, "An immutable backup reference is required.")
            result = lifecycle.verify(body["reference"])
            svc._audit(c, owner["name"], "host.backup.verified",
                       {"reference": result["reference"]})
            return 200, result, None
        if method == "POST" and path == "/api/foundation/host/backup/restore-drill":
            if set(body) != {"reference", "confirm"} or body["confirm"] is not True:
                raise HttpFailure(400, "A confirmed, isolated recovery reference is required.")
            result = lifecycle.restore_drill(body["reference"])
            svc._audit(c, owner["name"], "host.backup.restore.drilled",
                       {"reference": result["reference"]})
            return 200, result, None
        if method == "POST" and path == "/api/foundation/host/retention/preview":
            if set(body) != {"keepLast"} or type(body["keepLast"]) is not int:
                raise HttpFailure(400, "Provide an integer retention count.")
            return 200, lifecycle.preview(body["keepLast"]), None
        if method == "POST" and path == "/api/foundation/host/retention/configure":
            if (set(body) != {"keepLast", "expectedRevision", "confirm"} or
                    body["confirm"] is not True or
                    type(body["keepLast"]) is not int or
                    not 1 <= body["keepLast"] <= 365):
                raise HttpFailure(400, "Confirmed retention policy and 1–365 backups are required.")
            svc._require_revision(revision, body["expectedRevision"])
            replacement = json.dumps({"keepLast": body["keepLast"]})
            if row is None:
                c.execute("INSERT INTO policies(key,value,revision) VALUES(?,?,1)",
                          (POLICY_KEY, replacement))
            else:
                c.execute("UPDATE policies SET value=?, revision=revision+1 WHERE key=?",
                          (replacement, POLICY_KEY))
            svc._audit(c, owner["name"], "host.backup.retention.configured",
                       {"keepLast": body["keepLast"]})
            updated = c.execute("SELECT revision FROM policies WHERE key=?", (POLICY_KEY,)).fetchone()[0]
            return 200, dict(keepLast=body["keepLast"],
                             revision="host-retention-"+str(updated), enabled=True), None
        if method == "POST" and path == "/api/foundation/host/retention/run":
            if (set(body) != {"keepLast", "expectedRevision", "confirm"} or
                    body["confirm"] is not True or body["keepLast"] != count):
                raise HttpFailure(400, "Confirmed current retention inventory is required.")
            result = lifecycle.apply(count, body["expectedRevision"])
            svc._audit(c, owner["name"], "host.backup.retention.applied",
                       {"deletedEncryptedSnapshots": result["deletedEncryptedSnapshots"]})
            return 200, result, None
    except HttpFailure:
        raise
    except ValueError as exc:
        raise HttpFailure(400, "Invalid encrypted backup or retention request.") from exc
    except NativeBackupError as exc:
        raise HttpFailure(503, "Encrypted backup store is unavailable or unverified.") from exc
    raise HttpFailure(404, "Unknown native backup or retention endpoint.")
