"""Common scoped, read-only Audit Explorer queries over native indexed storage.

This module owns query semantics, bounds, public metadata and native-result
validation. It does not install a database, expose raw audit payloads or change
access policy. Products translate the immutable query plan to their existing
parameterized index/query API within a consistent authorized read transaction.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
import unicodedata

from .audit import AdminAuditEvent, AuditOutcome, canonical_event
from .timezone_service import SettingsActor, SettingsPermissionError, SettingsValidationError, SettingsRevisionConflict


class AuditQueryUnavailable(RuntimeError):
    """Native audit read failed without exposing database or credential details."""


def _text(value: object, cap: int, *, required: bool = True) -> str:
    if (not isinstance(value, str) or len(value) > cap or (required and not value)
            or any(unicodedata.category(c).startswith('C') for c in value)):
        raise SettingsValidationError('Invalid audit query or native metadata.')
    return value


def _stamp(value: object) -> datetime:
    _text(value, 64)
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError('timezone required')
        return parsed.astimezone(timezone.utc)
    except (ValueError, TypeError, OverflowError):
        raise SettingsValidationError('Audit timestamps must have an explicit valid timezone.') from None


@dataclass(frozen=True)
class AuditReadScope:
    """Native grant, derived only from the current authenticated authority.

    scope_ref identifies an already authorized native audit partition/view, not
    a client-selected tenant. authority_revision changes with role/session/MFA
    or scope changes and is checked again before any record reaches the caller.
    """
    subject: str
    scope_ref: str
    authority_revision: str

    def __post_init__(self) -> None:
        for value in vars(self).values():
            _text(value, 256)


@dataclass(frozen=True)
class AuditExplorerRecord:
    id: str
    timestamp: str
    action: str
    result: str
    scope_ref: str
    actor: str | None = None
    entity_type: str | None = None
    entity_id: str | None = None
    summary: str | None = None

    def __post_init__(self) -> None:
        for value in (self.id, self.action, self.scope_ref):
            _text(value, 256)
        _text(self.result, 100); _stamp(self.timestamp)
        for value in (self.actor, self.entity_type, self.entity_id):
            if value is not None:
                _text(value, 256, required=False)
        if self.summary is not None:
            _text(self.summary, 2048, required=False)

    def public(self) -> dict[str, Any]:
        # Explicit projection: never vars(native record), raw JSON or event details.
        stamp = _stamp(self.timestamp).isoformat().replace('+00:00', 'Z')
        return {'id': self.id, 'timestamp': stamp, 'action': self.action, 'result': self.result,
                'actor': self.actor, 'entityType': self.entity_type, 'entityId': self.entity_id, 'summary': self.summary}

    @classmethod
    def from_admin_event(cls, event: AdminAuditEvent, *, scope_ref: str) -> AuditExplorerRecord:
        native = canonical_event(event)
        return cls(id=native['event_id'], timestamp=native['occurred_at'], actor=native['actor_id'],
                   action=native['action'], result='success' if event.outcome is AuditOutcome.SUCCESS else 'failure',
                   entity_type=native['resource_kind'], entity_id=native['resource_id'], scope_ref=scope_ref)


@dataclass(frozen=True)
class AuditQueryPlan:
    limit: int
    offset: int
    action: str | None = None
    entity_type: str | None = None
    result: str | None = None

    def __post_init__(self) -> None:
        if type(self.limit) is not int or not 1 <= self.limit <= 100 or type(self.offset) is not int or not 0 <= self.offset <= 1000000:
            raise SettingsValidationError('Audit pages require a limit of 1–100 and an offset of 0–1000000.')
        for value in (self.action, self.entity_type):
            if value is not None:
                _text(value, 120)
        if self.result not in (None, 'success', 'failure'):
            raise SettingsValidationError('Audit result filter must be success or failure.')

    @classmethod
    def from_request(cls, request: Mapping[str, Any]) -> AuditQueryPlan:
        if (not isinstance(request, Mapping) or not {'offset', 'limit'} <= set(request)
                or not set(request) <= {'offset', 'limit', 'action', 'entityType', 'result'}):
            raise SettingsValidationError('Submit only audit filters, limit and offset.')
        for key in ('action', 'entityType', 'result'):
            if key in request:
                _text(request[key], 120)
        return cls(limit=request['limit'], offset=request['offset'], action=request.get('action'),
                   entity_type=request.get('entityType'), result=request.get('result'))

    def matches(self, row: AuditExplorerRecord) -> bool:
        return ((self.action is None or row.action == self.action)
                and (self.entity_type is None or row.entity_type == self.entity_type)
                and (self.result is None or row.result == self.result))

    @staticmethod
    def order_key(row: AuditExplorerRecord) -> tuple[datetime, str]:
        """Newest first, then native event ID descending as deterministic tie-break."""
        return _stamp(row.timestamp), row.id


@dataclass(frozen=True)
class AuditSelection:
    snapshot_ref: str
    scope: AuditReadScope
    query: AuditQueryPlan
    items: tuple[AuditExplorerRecord, ...]
    total: int
    redaction_verified: bool = False


class AuditQueryStore(Protocol):
    """Execute the common immutable query against a native authorized snapshot.

    Use current scope/authority and parameterized exact comparisons, never
    concatenate query text into SQL or accept client scope hints. Scope and all
    filters apply BEFORE counting/pagination. Count and row read share one native
    snapshot; sort by query.order_key descending, then offset/limit. Project only
    secret-free metadata and verify native redaction before returning its proof.
    An index may implement those semantics without reading all audit rows. Each
    row is tagged with the same verified scope. No raw payload fields are carried
    by AuditExplorerRecord. This read never adds, deletes or exports audit events.
    """
    def select(self, scope: AuditReadScope, query: AuditQueryPlan) -> AuditSelection: ...


class MemoryAuditQueryStore:
    """Isolated reference semantics, not an unbounded production audit index."""
    def __init__(self, records: list[AuditExplorerRecord]) -> None:
        if (not isinstance(records, list) or len(records) > 50000
                or any(not isinstance(row, AuditExplorerRecord) for row in records)
                or len({(row.scope_ref, row.id) for row in records}) != len(records)):
            raise SettingsValidationError('Invalid synthetic audit records.')
        self._records = tuple(records); self._lock = RLock()

    def select(self, scope: AuditReadScope, query: AuditQueryPlan) -> AuditSelection:
        with self._lock:
            matches = sorted((r for r in self._records if r.scope_ref == scope.scope_ref and query.matches(r)),
                             key=query.order_key, reverse=True)
            return AuditSelection('synthetic-audit-snapshot-1', scope, query,
                tuple(matches[query.offset:query.offset + query.limit]), len(matches), True)


class AuditExplorerService:
    def __init__(self, store: AuditQueryStore, *, authorize: Callable[[SettingsActor, str], bool],
                 scope_for: Callable[[SettingsActor], AuditReadScope]) -> None:
        if not callable(authorize) or not callable(scope_for):
            raise SettingsValidationError('Current native audit authority and scope are required.')
        self.store = store; self.authorize = authorize; self.scope_for = scope_for

    def _grant(self, actor: SettingsActor) -> AuditReadScope:
        try:
            allowed = isinstance(actor, SettingsActor) and 'audit.read' in actor.capabilities and self.authorize(actor, 'audit.read') is True
            scope = self.scope_for(actor) if allowed else None
        except Exception:
            raise SettingsPermissionError('Current native audit authority is unavailable.') from None
        if not isinstance(scope, AuditReadScope) or scope.subject != actor.subject:
            raise SettingsPermissionError('The current actor is not authorized for this audit scope.')
        return scope

    def query(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        scope = self._grant(actor); plan = AuditQueryPlan.from_request(request)
        try:
            selected = self.store.select(scope, plan)
        except Exception:
            raise AuditQueryUnavailable('Native audit query failed. Retry or contact the product administrator.') from None
        if self._grant(actor) != scope:
            raise SettingsPermissionError('Audit authority changed during the query; no records were returned.')
        if (not isinstance(selected, AuditSelection) or selected.scope != scope or selected.query != plan
                or selected.redaction_verified is not True):
            raise SettingsValidationError('Native audit result lacks matching scope, query or redaction evidence.')
        _text(selected.snapshot_ref, 256)
        if (type(selected.total) is not int or not 0 <= selected.total <= 2**53 - 1
                or not isinstance(selected.items, tuple)):
            raise SettingsValidationError('Invalid native audit count or page.')
        if plan.offset > selected.total:
            raise SettingsRevisionConflict('Audit entries changed. Reset filters to return to the first page.')
        if len(selected.items) != min(plan.limit, selected.total - plan.offset):
            raise SettingsValidationError('Native audit page and total do not describe the same snapshot.')
        identifiers: set[str] = set(); previous_key: tuple[datetime, str] | None = None
        public = []
        for row in selected.items:
            if not isinstance(row, AuditExplorerRecord) or row.scope_ref != scope.scope_ref:
                raise SettingsPermissionError('Native audit result contains an unauthorized record scope.')
            if row.id in identifiers or not plan.matches(row):
                raise SettingsValidationError('Native audit result duplicates a row or violates its exact filters.')
            key = plan.order_key(row)
            if previous_key is not None and key > previous_key:
                raise SettingsValidationError('Native audit result is not in stable newest-first order.')
            identifiers.add(row.id); previous_key = key; public.append(row.public())
        return {'items': public, 'total': selected.total, 'offset': plan.offset, 'limit': plan.limit}
