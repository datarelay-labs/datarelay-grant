"""Limited non-root ASGI → root-owned Foundation ingress gateway.

There is no arbitrary nginx, systemctl, shell, certificate or path parameter.
Opt-in only; a missing fixed executable leaves the Admin HTTPS/Network PUT
and POST routes unavailable (503) without an unsafe fallback.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any


class IngressGatewayUnavailable(RuntimeError):
    pass


_OPERATION = re.compile(r"ing-[0-9a-f]{20}\Z")


class HostIngressBridge:
    def __init__(self, helper: str | Path):
        binary = Path(helper)
        if not binary.is_absolute() or binary.is_symlink() or not binary.is_file():
            raise ValueError("An explicit installed native ingress helper is required.")
        info = binary.stat()
        if info.st_uid != 0 or info.st_mode & 0o022 or info.st_mode & 0o111 == 0:
            raise ValueError("Ingress helper must be root-owned and executable, non-writable by users.")
        self.helper = str(binary)

    def _call(self, action: str, *, operation: str | None = None,
              target: dict | None = None) -> dict[str, Any]:
        if action not in ("status", "stage", "confirm", "rollback"):
            raise ValueError("Unsupported native ingress operation.")
        if action != "status" and (not isinstance(operation, str) or not _OPERATION.fullmatch(operation)):
            raise ValueError("Invalid native operation identifier.")
        if action == "stage":
            if not isinstance(target, dict) or set(target) != {"http_port", "https_port", "redirect"}:
                raise ValueError("Unexpected ingress target payload.")
        elif target is not None:
            raise ValueError("Only staged ingress changes accept target settings.")
        command = ["sudo", "-n", self.helper, action]
        if operation:
            command.extend(["--operation", operation])
        try:
            result = subprocess.run(command, capture_output=True,
                                    input=json.dumps(target) if target is not None else None,
                                    text=True, check=False, timeout=14,
                                    env={"PATH": "/usr/sbin:/usr/bin:/bin", "LANG": "C"})
            if result.returncode != 0 or len(result.stdout) > 8192:
                raise IngressGatewayUnavailable("The installed native ingress gateway refused the operation.")
            response = json.loads(result.stdout)
            if not isinstance(response, dict):
                raise IngressGatewayUnavailable("Native ingress readback was not structured JSON.")
            return response
        except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
            raise IngressGatewayUnavailable("The installed native ingress gateway is unavailable.") from exc

    def status(self):
        return self._call("status")

    def stage(self, operation: str, target: dict):
        return self._call("stage", operation=operation, target=target)

    def confirm(self, operation: str):
        return self._call("confirm", operation=operation)

    def rollback(self, operation: str):
        return self._call("rollback", operation=operation)
