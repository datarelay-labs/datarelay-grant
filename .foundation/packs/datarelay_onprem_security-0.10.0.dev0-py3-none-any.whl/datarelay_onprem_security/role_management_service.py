"""Product-neutral role registry projection and account-role mutation service.

The role/capability registry and account bindings remain product-owned. Foundation
provides strict validation, revision-bound previews, last-administrator safety,
MFA/approval/rollback gates, atomic audit construction and read-back verification.
No role, capability or authorization can be invented from browser input.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from threading import RLock
from typing import Any, Callable, Mapping, Protocol
from uuid import uuid4
import math
import re
import time
import unicodedata

from .role_policy import (
    RoleCapabilities,
    RoleChangeEvidence,
    preview_role_change,
)
from .timezone_service import (
    SettingsActor,
    SettingsPermissionError,
    SettingsRevisionConflict,
    SettingsValidationError,
)

_ID = re.compile(r"[a-z][a-z0-9_.-]{0,95}\Z", re.ASCII)


def _id(value: object, label: str) -> str:
    if not isinstance(value, str) or _ID.fullmatch(value) is None:
        raise SettingsValidationError("Invalid " + label + ".")
    return value


def _label(value: object) -> str:
    if (
        not isinstance(value, str)
        or not 0 < len(value) <= 256
        or value != value.strip()
        or any(unicodedata.category(char).startswith("C") for char in value)
    ):
        raise SettingsValidationError("Invalid role label.")
    return value


def _time(value: object) -> float:
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 253402300799:
        raise SettingsValidationError("Invalid native role-management clock.")
    return float(value)


def _directory(value: object) -> dict[str, Any]:
    if not isinstance(value, Mapping) or set(value) != {
        "registryCapabilities",
        "roles",
        "accounts",
    }:
        raise SettingsValidationError("A complete native role directory is required.")
    capabilities = value["registryCapabilities"]
    roles = value["roles"]
    accounts = value["accounts"]
    if (
        not isinstance(capabilities, list)
        or not capabilities
        or len(capabilities) > 2048
        or len(set(capabilities)) != len(capabilities)
    ):
        raise SettingsValidationError("Invalid native capability registry.")
    capability_set: set[str] = set()
    for capability in capabilities:
        capability_set.add(_id(capability, "capability"))

    if not isinstance(roles, list) or not roles or len(roles) > 256:
        raise SettingsValidationError("Invalid native role registry.")
    role_refs: set[str] = set()
    for role in roles:
        if not isinstance(role, Mapping) or set(role) != {
            "ref",
            "label",
            "administrator",
            "capabilities",
        }:
            raise SettingsValidationError("Invalid native role.")
        ref = _id(role["ref"], "role reference")
        _label(role["label"])
        if ref in role_refs or type(role["administrator"]) is not bool:
            raise SettingsValidationError("Invalid native role registry.")
        role_refs.add(ref)
        role_caps = role["capabilities"]
        if (
            not isinstance(role_caps, list)
            or len(role_caps) > len(capability_set)
            or len(set(role_caps)) != len(role_caps)
        ):
            raise SettingsValidationError("Invalid role capabilities.")
        for capability in role_caps:
            if _id(capability, "role capability") not in capability_set:
                raise SettingsValidationError("Role capability is not in the native registry.")

    if not isinstance(accounts, list) or not accounts or len(accounts) > 10000:
        raise SettingsValidationError("Invalid role account bindings.")
    identities: set[str] = set()
    for account in accounts:
        if not isinstance(account, Mapping) or set(account) != {"id", "roleRef", "status"}:
            raise SettingsValidationError("Invalid role account binding.")
        identity = _id(account["id"], "account reference")
        role_ref = _id(account["roleRef"], "role reference")
        if (
            identity in identities
            or role_ref not in role_refs
            or account["status"] not in ("active", "disabled")
        ):
            raise SettingsValidationError("Invalid role account binding.")
        identities.add(identity)
    role_map = {role["ref"]: role for role in roles}
    if not any(
        account["status"] == "active" and role_map[account["roleRef"]]["administrator"]
        for account in accounts
    ):
        raise SettingsValidationError("At least one active administrator must remain.")
    return deepcopy(dict(value))


@dataclass(frozen=True)
class RoleManagementReadiness:
    backend_write_supported: bool = False
    recent_mfa_verified: bool = False
    audit_ready: bool = False
    rollback_ready: bool = False
    external_approval_granted: bool = False

    def __post_init__(self) -> None:
        if any(type(value) is not bool for value in vars(self).values()):
            raise SettingsValidationError("Role readiness requires actual native Boolean evidence.")


@dataclass(frozen=True)
class RoleDirectorySnapshot:
    revision: str
    value: dict[str, Any]


@dataclass(frozen=True)
class RoleAssignmentPreview:
    token: str
    actor: str
    draft: dict[str, str]
    created_at: float
    expires_at: float
    allowed: bool
    blockers: tuple[str, ...]
    gained: tuple[str, ...]
    lost: tuple[str, ...]


@dataclass(frozen=True)
class RoleDirectoryMutation:
    value: dict[str, Any]
    event: dict[str, Any]


class RoleManagementDriver(Protocol):
    def readiness(
        self,
        actor: SettingsActor,
        subject_ref: str,
        from_role_ref: str,
        to_role_ref: str,
    ) -> RoleManagementReadiness: ...


class RoleManagementStore(Protocol):
    def read(self) -> RoleDirectorySnapshot: ...
    def register_preview(self, preview: RoleAssignmentPreview) -> None: ...
    def preview(self, token: str) -> RoleAssignmentPreview | None: ...

    def transact(
        self,
        expected_revision: str,
        build: Callable[[RoleDirectorySnapshot, Mapping[str, RoleAssignmentPreview]], RoleDirectoryMutation],
    ) -> RoleDirectorySnapshot: ...


class MemoryRoleManagementStore:
    """Development-only atomic reference; no production identity persistence."""

    def __init__(self, value: Mapping[str, Any]) -> None:
        self._value = _directory(value)
        self._version = 1
        self._lock = RLock()
        self._previews: dict[str, RoleAssignmentPreview] = {}
        self._audit: list[dict[str, Any]] = []

    def read(self) -> RoleDirectorySnapshot:
        with self._lock:
            return RoleDirectorySnapshot("roles-" + str(self._version), deepcopy(self._value))

    def register_preview(self, preview: RoleAssignmentPreview) -> None:
        with self._lock:
            if not isinstance(preview, RoleAssignmentPreview):
                raise SettingsValidationError("Invalid role assignment preview.")
            if preview.draft["expectedRevision"] != self.read().revision:
                raise SettingsRevisionConflict("Role directory changed.")
            self._previews = {
                token: item
                for token, item in self._previews.items()
                if item.expires_at > preview.created_at
            }
            if len(self._previews) >= 1024:
                raise SettingsValidationError("Role preview capacity exceeded.")
            self._previews[preview.token] = deepcopy(preview)

    def preview(self, token: str) -> RoleAssignmentPreview | None:
        with self._lock:
            return deepcopy(self._previews.get(token))

    def transact(
        self,
        expected_revision: str,
        build: Callable[[RoleDirectorySnapshot, Mapping[str, RoleAssignmentPreview]], RoleDirectoryMutation],
    ) -> RoleDirectorySnapshot:
        with self._lock:
            before = self.read()
            if before.revision != _id(expected_revision, "role revision"):
                raise SettingsRevisionConflict("Role directory changed.")
            mutation = build(before, deepcopy(self._previews))
            if not isinstance(mutation, RoleDirectoryMutation):
                raise SettingsValidationError("Invalid atomic role mutation.")
            next_value = _directory(mutation.value)
            event = deepcopy(dict(mutation.event))
            _id(event.get("id"), "audit reference")
            if (
                not isinstance(event.get("action"), str)
                or event.get("subject") not in {account["id"] for account in next_value["accounts"]}
            ):
                raise SettingsValidationError("Invalid role audit event.")
            self._value = next_value
            self._version += 1
            self._audit.append(event)
            self._previews.clear()
            return self.read()

    def bump_for_test(self) -> None:
        with self._lock:
            self._version += 1

    @property
    def audit_events(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self._audit)


class RoleManagementService:
    def __init__(
        self,
        store: RoleManagementStore,
        driver: RoleManagementDriver,
        *,
        authorize: Callable[[SettingsActor, str], bool],
        clock: Callable[[], float] = time.time,
    ) -> None:
        if not callable(authorize):
            raise SettingsValidationError("Current native role authority is required.")
        self.store = store
        self.driver = driver
        self.authorize = authorize
        self.clock = clock

    def _now(self) -> float:
        return _time(self.clock())

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            allowed = (
                isinstance(actor, SettingsActor)
                and permission in actor.capabilities
                and self.authorize(actor, permission) is True
            )
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError("Current native authority does not allow this role operation.")

    def _snapshot(self, expected: str | None = None) -> RoleDirectorySnapshot:
        value = self.store.read()
        if not isinstance(value, RoleDirectorySnapshot):
            raise SettingsValidationError("Invalid native role directory snapshot.")
        _id(value.revision, "role revision")
        validated = RoleDirectorySnapshot(value.revision, _directory(value.value))
        if expected is not None and validated.revision != _id(expected, "role revision"):
            raise SettingsRevisionConflict("Role directory changed. Refresh and retry.")
        return validated

    @staticmethod
    def _account(snapshot: RoleDirectorySnapshot, subject: str) -> dict[str, Any]:
        found = next((account for account in snapshot.value["accounts"] if account["id"] == subject), None)
        if found is None:
            raise SettingsValidationError("Selected account is not current.")
        return found

    @staticmethod
    def _role(snapshot: RoleDirectorySnapshot, ref: str) -> dict[str, Any]:
        found = next((role for role in snapshot.value["roles"] if role["ref"] == ref), None)
        if found is None:
            raise SettingsValidationError("Selected role is not current.")
        return found

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, "roles.read")
        snapshot = self._snapshot()
        self._account(snapshot, actor.subject)
        self._require(actor, "roles.read")
        return {
            "revision": snapshot.revision,
            "currentUserId": actor.subject,
            "complete": True,
            "registryCapabilities": list(snapshot.value["registryCapabilities"]),
            "roles": deepcopy(snapshot.value["roles"]),
            "accounts": deepcopy(snapshot.value["accounts"]),
        }

    @staticmethod
    def _draft(request: Mapping[str, Any]) -> dict[str, str]:
        if not isinstance(request, Mapping) or set(request) != {
            "subjectRef",
            "toRoleRef",
            "expectedRevision",
        }:
            raise SettingsValidationError("Submit only account, target role and current revision.")
        return {
            "subjectRef": _id(request["subjectRef"], "account reference"),
            "toRoleRef": _id(request["toRoleRef"], "role reference"),
            "expectedRevision": _id(request["expectedRevision"], "role revision"),
        }

    @staticmethod
    def _last_admin_preserved(
        snapshot: RoleDirectorySnapshot,
        subject: dict[str, Any],
        target_role: dict[str, Any],
    ) -> bool:
        if subject["status"] != "active":
            return True
        current_role = RoleManagementService._role(snapshot, subject["roleRef"])
        if not current_role["administrator"] or target_role["administrator"]:
            return True
        role_map = {role["ref"]: role for role in snapshot.value["roles"]}
        active_admins = sum(
            account["status"] == "active" and role_map[account["roleRef"]]["administrator"]
            for account in snapshot.value["accounts"]
        )
        return active_admins > 1

    def _review(
        self,
        actor: SettingsActor,
        snapshot: RoleDirectorySnapshot,
        draft: dict[str, str],
    ) -> tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]:
        self._require(actor, "roles.read")
        self._require(actor, "roles.assign")
        subject = self._account(snapshot, draft["subjectRef"])
        if subject["status"] not in ("active", "disabled"):
            raise SettingsValidationError("Selected account state is not supported.")
        current_role = self._role(snapshot, subject["roleRef"])
        target_role = self._role(snapshot, draft["toRoleRef"])
        self._require(actor, "roles.assign." + target_role["ref"])
        if current_role["ref"] == target_role["ref"]:
            return ("no_change",), (), ()
        readiness = self.driver.readiness(
            actor,
            subject["id"],
            current_role["ref"],
            target_role["ref"],
        )
        if not isinstance(readiness, RoleManagementReadiness):
            raise SettingsValidationError("Current native role readiness is required.")
        actor_can_manage = (
            "roles.assign" in actor.capabilities
            and self.authorize(actor, "roles.assign") is True
        )
        evidence = RoleChangeEvidence(
            actor_ref=actor.subject,
            subject_ref=subject["id"],
            expected_current_revision=snapshot.revision,
            actor_can_manage_roles=actor_can_manage,
            recent_mfa_verified=readiness.recent_mfa_verified,
            product_role_write_supported=readiness.backend_write_supported,
            audit_ready=readiness.audit_ready,
            rollback_ready=readiness.rollback_ready,
            last_admin_preserved=self._last_admin_preserved(snapshot, subject, target_role),
            external_approval_granted=readiness.external_approval_granted,
        )
        current = RoleCapabilities(
            current_role["ref"],
            snapshot.revision,
            frozenset(current_role["capabilities"]),
        )
        proposed = RoleCapabilities(
            target_role["ref"],
            snapshot.revision,
            frozenset(target_role["capabilities"]),
        )
        result = preview_role_change(
            current,
            proposed,
            registry_capabilities=frozenset(snapshot.value["registryCapabilities"]),
            evidence=evidence,
        )
        return (
            tuple(blocker.value for blocker in result.blockers),
            result.gained,
            result.lost,
        )

    def preview_assignment(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        draft = self._draft(request)
        snapshot = self._snapshot(draft["expectedRevision"])
        blockers, gained, lost = self._review(actor, snapshot, draft)
        now = self._now()
        token = "role-preview-" + uuid4().hex
        preview = RoleAssignmentPreview(
            token,
            actor.subject,
            draft,
            now,
            now + 300,
            not blockers,
            blockers,
            gained,
            lost,
        )
        self.store.register_preview(preview)
        return {
            "allowed": preview.allowed,
            "blockers": list(blockers),
            "gained": list(gained),
            "lost": list(lost),
            "draft": deepcopy(draft),
            "previewToken": token,
            "expiresAt": preview.expires_at * 1000,
        }

    def _plan(
        self,
        plan: RoleAssignmentPreview | None,
        actor: SettingsActor,
        draft: dict[str, str],
    ) -> RoleAssignmentPreview:
        now = self._now()
        if (
            not isinstance(plan, RoleAssignmentPreview)
            or plan.actor != actor.subject
            or plan.draft != draft
            or not plan.created_at <= now < plan.expires_at
        ):
            raise SettingsValidationError("A current matching role assignment preview is required.")
        if not plan.allowed or plan.blockers:
            raise SettingsPermissionError("Role assignment safety was not established.")
        return plan

    def apply_assignment(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        if (
            not isinstance(request, Mapping)
            or set(request) != {"draft", "previewToken", "confirm"}
            or request["confirm"] is not True
        ):
            raise SettingsValidationError("Exact reviewed role intent and explicit confirmation are required.")
        draft = self._draft(request["draft"])
        token = _id(request["previewToken"], "role preview reference")
        before = self._snapshot(draft["expectedRevision"])
        plan = self._plan(self.store.preview(token), actor, draft)
        blockers, gained, lost = self._review(actor, before, draft)
        if blockers or tuple(gained) != plan.gained or tuple(lost) != plan.lost:
            raise SettingsPermissionError("Current role safety no longer matches the reviewed plan.")
        event = {
            "id": "role-audit-" + uuid4().hex,
            "actor": actor.subject,
            "subject": draft["subjectRef"],
            "action": "roles.assignment.changed",
            "fromRoleRef": self._account(before, draft["subjectRef"])["roleRef"],
            "toRoleRef": draft["toRoleRef"],
            "timestamp": self._now(),
        }
        expected_value: dict[str, Any] = {}

        def build(
            current: RoleDirectorySnapshot,
            plans: Mapping[str, RoleAssignmentPreview],
        ) -> RoleDirectoryMutation:
            nonlocal expected_value
            current = RoleDirectorySnapshot(current.revision, _directory(current.value))
            if current.value != before.value or current.revision != before.revision:
                raise SettingsRevisionConflict("Native role directory changed without a matching revision.")
            self._plan(plans.get(token), actor, draft)
            current_blockers, current_gained, current_lost = self._review(actor, current, draft)
            if (
                current_blockers
                or tuple(current_gained) != plan.gained
                or tuple(current_lost) != plan.lost
            ):
                raise SettingsPermissionError("Current role safety changed during atomic apply.")
            expected_value = deepcopy(current.value)
            account = next(
                account
                for account in expected_value["accounts"]
                if account["id"] == draft["subjectRef"]
            )
            account["roleRef"] = draft["toRoleRef"]
            return RoleDirectoryMutation(expected_value, event)

        returned = self.store.transact(before.revision, build)
        observed = self._snapshot()
        if (
            not isinstance(returned, RoleDirectorySnapshot)
            or returned.revision == before.revision
            or returned.revision != observed.revision
            or returned.value != expected_value
            or observed.value != expected_value
        ):
            raise RuntimeError("Native role assignment was not independently verified.")
        return {
            "revision": observed.revision,
            "currentUserId": actor.subject,
            "complete": True,
            "registryCapabilities": list(observed.value["registryCapabilities"]),
            "roles": deepcopy(observed.value["roles"]),
            "accounts": deepcopy(observed.value["accounts"]),
            "auditReference": event["id"],
        }


class RolePermissionsDriver(Protocol):
    """Current product-native proof for changing a role's capability set.

    Product implementations must check actual MFA/approval, audit and rollback,
    and cannot derive these assurances from the caller's JSON payload.
    """
    def readiness(
        self,
        actor: SettingsActor,
        role_ref: str,
        before: frozenset[str],
        after: frozenset[str],
    ) -> RoleManagementReadiness: ...


class RolePermissionsService:
    """Revision-bound, audited role-permissions management using the native role store.

    Complements RoleManagementService's account-role assignments. The same
    product-owned atomic RoleManagementStore persists both operations; no
    Foundation-owned production identity database is introduced.
    """

    def __init__(
        self,
        store: RoleManagementStore,
        driver: RolePermissionsDriver,
        *,
        authorize: Callable[[SettingsActor, str], bool],
        clock: Callable[[], float] = time.time,
    ) -> None:
        if not callable(authorize):
            raise SettingsValidationError("Native role authority is required.")
        self.store = store
        self.driver = driver
        self.authorize = authorize
        self.clock = clock

    def _require(self, actor: SettingsActor, permission: str) -> None:
        try:
            allowed = (
                isinstance(actor, SettingsActor)
                and permission in actor.capabilities
                and self.authorize(actor, permission) is True
            )
        except Exception:
            allowed = False
        if not allowed:
            raise SettingsPermissionError("Native role permission is unavailable.")

    def _snapshot(self, expected: str | None = None) -> RoleDirectorySnapshot:
        value = self.store.read()
        if not isinstance(value, RoleDirectorySnapshot):
            raise SettingsValidationError("Native role directory is unavailable.")
        snapshot = RoleDirectorySnapshot(_id(value.revision, "revision"), _directory(value.value))
        if expected is not None and snapshot.revision != _id(expected, "revision"):
            raise SettingsRevisionConflict("Role directory revision changed.")
        return snapshot

    def read(self, actor: SettingsActor) -> dict[str, Any]:
        self._require(actor, "roles.read")
        snapshot = self._snapshot()
        if not any(account["id"] == actor.subject and account["status"] == "active"
                   for account in snapshot.value["accounts"]):
            raise SettingsPermissionError("Authenticated actor is not active.")
        self._require(actor, "roles.read")
        return self._projection(snapshot, actor)

    @staticmethod
    def _projection(snapshot: RoleDirectorySnapshot, actor: SettingsActor) -> dict[str, Any]:
        return {
            "revision": snapshot.revision,
            "availablePermissions": list(snapshot.value["registryCapabilities"]),
            "roles": [
                {
                    "id": role["ref"],
                    "label": role["label"],
                    "permissions": list(role["capabilities"]),
                    "mutable": not role["administrator"],
                }
                for role in snapshot.value["roles"]
            ],
        }

    @staticmethod
    def _draft(request: Mapping[str, Any], snapshot: RoleDirectorySnapshot) -> dict[str, Any]:
        if not isinstance(request, Mapping) or set(request) != {
            "expectedRevision", "roleId", "permissions"
        }:
            raise SettingsValidationError("Only role, revision and permission list are accepted.")
        expected = _id(request["expectedRevision"], "revision")
        if snapshot.revision != expected:
            raise SettingsRevisionConflict("Role directory revision changed.")
        role_id = _id(request["roleId"], "role identifier")
        permitted = request["permissions"]
        if not isinstance(permitted, list) or len(permitted) > 2048:
            raise SettingsValidationError("Invalid role permission list.")
        requested = [_id(item, "permission") for item in permitted]
        registry = snapshot.value["registryCapabilities"]
        if len(requested) != len(set(requested)) or any(cap not in registry for cap in requested):
            raise SettingsValidationError("Only unique native registry permissions are accepted.")
        return {"expectedRevision": expected, "roleId": role_id,
                "permissions": sorted(requested)}

    def _review(
        self, actor: SettingsActor, snapshot: RoleDirectorySnapshot, draft: dict[str, Any]
    ) -> tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]:
        self._require(actor, "roles.read")
        self._require(actor, "roles.manage")
        if not any(account["id"] == actor.subject and account["status"] == "active"
                   for account in snapshot.value["accounts"]):
            raise SettingsPermissionError("Authenticated actor is no longer active.")
        role = RoleManagementService._role(snapshot, draft["roleId"])
        if role["administrator"]:
            return ("protected_administrator_role",), (), ()
        previous = frozenset(role["capabilities"])
        requested = frozenset(draft["permissions"])
        gained = tuple(sorted(requested - previous))
        lost = tuple(sorted(previous - requested))
        if not gained and not lost:
            return ("no_change",), gained, lost
        evidence = self.driver.readiness(actor, role["ref"], previous, requested)
        if not isinstance(evidence, RoleManagementReadiness):
            raise SettingsValidationError("Native role-permission evidence is required.")
        blockers: list[str] = []
        for flag in ("backend_write_supported", "recent_mfa_verified", "audit_ready", "rollback_ready"):
            if getattr(evidence, flag) is not True:
                blockers.append(flag)
        # Newly granted privileges and changes to the actor's own role are
        # never implicitly authorized by a browser-supplied role directory.
        actor_role = next(account["roleRef"] for account in snapshot.value["accounts"]
                          if account["id"] == actor.subject)
        if (gained or actor_role == role["ref"]) and not evidence.external_approval_granted:
            blockers.append("elevation_approval_required")
        return tuple(blockers), gained, lost

    def preview(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        self._require(actor, "roles.read")
        self._require(actor, "roles.manage")
        snapshot = self._snapshot()
        draft = self._draft(request, snapshot)
        blockers, gained, lost = self._review(actor, snapshot, draft)
        now = _time(self.clock())
        encoded = {"expectedRevision": draft["expectedRevision"],
                   "roleId": draft["roleId"],
                   "permissions": ",".join(draft["permissions"])}
        preview = RoleAssignmentPreview(
            "role-preview-" + uuid4().hex, actor.subject, encoded,
            now, now + 300.0, not blockers, blockers, gained, lost
        )
        self.store.register_preview(preview)
        return {
            "previewRef": preview.token,
            "expectedRevision": snapshot.revision,
            "safe": preview.allowed,
            "expiresAt": int(preview.expires_at * 1000),
            "blockers": list(blockers),
            "gained": list(gained),
            "lost": list(lost),
        }

    def apply(self, actor: SettingsActor, request: Mapping[str, Any]) -> dict[str, Any]:
        if (not isinstance(request, Mapping) or set(request) != {
            "expectedRevision", "previewRef", "confirm"
        } or request["confirm"] is not True):
            raise SettingsValidationError("Exact reviewed policy and explicit confirmation required.")
        revision = _id(request["expectedRevision"], "revision")
        token = _id(request["previewRef"], "preview token")
        self._require(actor, "roles.read")
        self._require(actor, "roles.manage")
        baseline = self._snapshot(revision)
        preview = self.store.preview(token)
        now = _time(self.clock())
        if (not isinstance(preview, RoleAssignmentPreview) or not preview.allowed
            or preview.blockers or preview.actor != actor.subject
            or preview.draft.get("expectedRevision") != revision
            or not preview.created_at <= now < preview.expires_at):
            raise SettingsPermissionError("Current role permission preview is missing or unsafe.")
        draft = self._draft({
            "expectedRevision": revision,
            "roleId": preview.draft.get("roleId"),
            "permissions": preview.draft.get("permissions", "").split(",")
                if preview.draft.get("permissions") else [],
        }, baseline)
        blockers, gained, lost = self._review(actor, baseline, draft)
        if blockers or gained != preview.gained or lost != preview.lost:
            raise SettingsPermissionError("Role safety evidence changed since preview.")
        audit = {
            "id": "role-audit-" + uuid4().hex,
            "actor": actor.subject,
            "subject": actor.subject,
            "action": "roles.permissions.changed",
            "roleId": draft["roleId"],
            "gained": list(gained),
            "lost": list(lost),
            "timestamp": now,
        }
        expected_value: dict[str, Any] = {}

        def build(current: RoleDirectorySnapshot,
                  previews: Mapping[str, RoleAssignmentPreview]) -> RoleDirectoryMutation:
            nonlocal expected_value
            if current.revision != baseline.revision or current.value != baseline.value:
                raise SettingsRevisionConflict("Role policy changed before atomic apply.")
            plan = previews.get(token)
            if plan != preview or not preview.created_at <= _time(self.clock()) < preview.expires_at:
                raise SettingsPermissionError("Role preview expired before atomic apply.")
            current_blockers, current_gained, current_lost = self._review(actor, current, draft)
            if current_blockers or current_gained != gained or current_lost != lost:
                raise SettingsPermissionError("Role policy authority changed during atomic apply.")
            expected_value = deepcopy(current.value)
            role = next(item for item in expected_value["roles"] if item["ref"] == draft["roleId"])
            role["capabilities"] = list(draft["permissions"])
            return RoleDirectoryMutation(expected_value, audit)

        returned = self.store.transact(revision, build)
        observed = self._snapshot()
        if (not isinstance(returned, RoleDirectorySnapshot)
            or returned.revision == revision
            or observed.revision != returned.revision
            or returned.value != expected_value or observed.value != expected_value):
            raise RuntimeError("Role permission apply is unverified; refresh authoritative state.")
        return {**self._projection(observed, actor), "auditReference": audit["id"]}
