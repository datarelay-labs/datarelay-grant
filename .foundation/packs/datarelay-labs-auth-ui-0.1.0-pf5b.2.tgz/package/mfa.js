import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { Button, TextField } from "@datarelay-labs/ui";
import { AuthErrorNotice } from "./auth-error-notice.js";
const DEFAULT_MFA_METHODS = ["totp", "recovery_code"];
const FALLBACK_MFA_METHODS = ["totp"];
export function MfaChallengeForm({ onSubmit, methods = DEFAULT_MFA_METHODS, challengeRef, busy = false, errorCategory, errorMessage }) {
    const availableMethods = methods.length > 0 ? methods : FALLBACK_MFA_METHODS;
    const [method, setMethod] = useState(availableMethods[0]);
    const [value, setValue] = useState("");
    const [localError, setLocalError] = useState("");
    const selectedMethod = availableMethods.includes(method) ? method : availableMethods[0];
    useEffect(() => {
        if (method !== selectedMethod) {
            setMethod(selectedMethod);
            setValue("");
            setLocalError("");
        }
    }, [method, selectedMethod]);
    function submit(event) {
        event.preventDefault();
        const normalized = value.trim();
        if (!normalized) {
            setLocalError(selectedMethod === "totp" ? "Enter your authentication code." : "Enter a recovery code.");
            return;
        }
        setLocalError("");
        void onSubmit({
            method: selectedMethod,
            value: normalized,
            ...(challengeRef ? { challengeRef } : {})
        });
    }
    return (_jsxs("form", { className: "dr-auth-form", onSubmit: submit, children: [availableMethods.length > 1 ? (_jsxs("fieldset", { className: "dr-auth-methods", children: [_jsx("legend", { children: "Verification method" }), availableMethods.map((candidate) => (_jsxs("label", { children: [_jsx("input", { type: "radio", name: "mfa-method", value: candidate, checked: selectedMethod === candidate, onChange: () => {
                                    setMethod(candidate);
                                    setValue("");
                                    setLocalError("");
                                } }), candidate === "totp" ? "Authenticator code" : "Recovery code"] }, candidate)))] })) : null, _jsx(TextField, { label: selectedMethod === "totp" ? "Authentication code" : "Recovery code", ...(selectedMethod === "totp" ? { inputMode: "numeric", autoComplete: "one-time-code" } : { autoComplete: "off" }), value: value, onChange: (event) => setValue(event.target.value), disabled: busy }), localError ? _jsx(AuthErrorNotice, { category: "validation", message: localError }) : null, errorCategory ? _jsx(AuthErrorNotice, { category: errorCategory, ...(errorMessage ? { message: errorMessage } : {}) }) : null, _jsx(Button, { type: "submit", disabled: busy, children: busy ? "Verifying…" : "Verify" })] }));
}
export function MfaEnrollmentPanel({ material, onConfirm, busy = false, errorCategory, errorMessage }) {
    const [code, setCode] = useState("");
    const [localError, setLocalError] = useState("");
    function submit(event) {
        event.preventDefault();
        const normalized = code.trim();
        if (!normalized) {
            setLocalError("Enter the code from your authenticator app.");
            return;
        }
        setLocalError("");
        void onConfirm(normalized);
    }
    return (_jsxs("div", { className: "dr-auth-stack", children: [_jsxs("div", { className: "dr-auth-enrollment", children: [material.qrCode ? _jsx("div", { className: "dr-auth-enrollment__qr", children: material.qrCode }) : null, _jsxs("dl", { className: "dr-auth-enrollment__facts", children: [_jsxs("div", { children: [_jsx("dt", { children: "Account" }), _jsx("dd", { children: material.accountLabel })] }), material.issuer ? _jsxs("div", { children: [_jsx("dt", { children: "Issuer" }), _jsx("dd", { children: material.issuer })] }) : null] }), material.secret ? (_jsxs("div", { children: [_jsx("div", { className: "dr-auth-label", children: "Manual entry key" }), _jsx("code", { className: "dr-auth-secret", children: material.secret })] })) : null, material.otpauthUri ? (_jsxs("div", { children: [_jsx("div", { className: "dr-auth-label", children: "Authenticator URI" }), _jsx("code", { className: "dr-auth-secret", children: material.otpauthUri })] })) : null] }), _jsxs("form", { className: "dr-auth-form", onSubmit: submit, children: [_jsx(TextField, { label: "Confirm authentication code", inputMode: "numeric", autoComplete: "one-time-code", value: code, onChange: (event) => setCode(event.target.value), disabled: busy }), localError ? _jsx(AuthErrorNotice, { category: "validation", message: localError }) : null, errorCategory ? _jsx(AuthErrorNotice, { category: errorCategory, ...(errorMessage ? { message: errorMessage } : {}) }) : null, _jsx(Button, { type: "submit", disabled: busy, children: busy ? "Confirming…" : "Confirm MFA" })] })] }));
}
export function RecoveryCodesPanel({ codes, onContinue, onCopyRequested }) {
    return (_jsxs("section", { className: "dr-auth-recovery", "aria-labelledby": "dr-auth-recovery-heading", children: [_jsx("h2", { id: "dr-auth-recovery-heading", children: "Recovery codes" }), _jsx("p", { children: "Store these codes using the product's approved secure process. Usage and replacement rules remain product-owned." }), _jsx("ul", { "aria-label": "Recovery codes", children: codes.map((code) => _jsx("li", { children: _jsx("code", { children: code }) }, code)) }), (onCopyRequested || onContinue) ? (_jsxs("div", { className: "dr-auth-methods", children: [onCopyRequested ? _jsx(Button, { variant: "secondary", type: "button", onClick: onCopyRequested, children: "Copy codes" }) : null, onContinue ? _jsx(Button, { type: "button", onClick: onContinue, children: "I stored the codes" }) : null] })) : null] }));
}
