import type { ReactNode } from "react";
export type AuthCapabilityGateProps = {
    available: boolean;
    children: ReactNode;
    fallback?: ReactNode;
};
export declare function AuthCapabilityGate({ available, children, fallback }: AuthCapabilityGateProps): import("react").JSX.Element;
