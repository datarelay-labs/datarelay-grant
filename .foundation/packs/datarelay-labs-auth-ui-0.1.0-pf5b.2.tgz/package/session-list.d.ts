import type { AuthSessionSummary } from "./types";
export type SessionListProps = {
    sessions: readonly AuthSessionSummary[];
    onRevoke?: (sessionId: string) => void | Promise<void>;
    revokingSessionId?: string;
};
export declare function SessionList({ sessions, onRevoke, revokingSessionId }: SessionListProps): import("react").JSX.Element;
