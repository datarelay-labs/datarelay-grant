import { jsx as _jsx } from "react/jsx-runtime";
import { Alert } from "@datarelay-labs/ui";
const titles = {
    validation: "Check the entered information",
    unauthenticated: "Authentication required",
    forbidden: "Action not permitted",
    conflict: "State changed",
    stale_state: "Refresh required",
    unavailable: "Authentication service unavailable",
    interrupted: "Authentication was interrupted",
    failed: "Authentication failed"
};
export function AuthErrorNotice({ category, message }) {
    const tone = category === "failed" || category === "unauthenticated" || category === "validation" ? "critical" : "warning";
    return (_jsx(Alert, { tone: tone, title: titles[category], children: message ?? "Review the current state and try again." }));
}
