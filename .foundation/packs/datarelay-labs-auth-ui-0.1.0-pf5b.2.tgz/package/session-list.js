import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, EmptyState, StatusBadge } from "@datarelay-labs/ui";
export function SessionList({ sessions, onRevoke, revokingSessionId }) {
    if (!sessions.length) {
        return _jsx(EmptyState, { title: "No active sessions", description: "No sessions are available from the product adapter." });
    }
    return (_jsx("ul", { className: "dr-auth-sessions", "aria-label": "Active sessions", children: sessions.map((session) => {
            const canRevoke = session.revocable === true && !session.revoked && Boolean(onRevoke);
            return (_jsxs("li", { className: "dr-auth-session", children: [_jsxs("div", { className: "dr-auth-session__summary", children: [_jsxs("div", { className: "dr-auth-session__title", children: [_jsx("strong", { children: session.deviceLabel ?? "Browser session" }), session.current ? _jsx(StatusBadge, { tone: "info", children: "Current" }) : null, session.revoked ? _jsx(StatusBadge, { tone: "neutral", children: "Revoked" }) : null] }), session.source ? _jsx("p", { children: session.source }) : null, _jsxs("dl", { children: [_jsxs("div", { children: [_jsx("dt", { children: "Created" }), _jsx("dd", { children: session.createdAt })] }), session.lastSeenAt ? _jsxs("div", { children: [_jsx("dt", { children: "Last seen" }), _jsx("dd", { children: session.lastSeenAt })] }) : null, session.expiresAt ? _jsxs("div", { children: [_jsx("dt", { children: "Expires" }), _jsx("dd", { children: session.expiresAt })] }) : null] })] }), canRevoke ? (_jsx(Button, { variant: "danger", size: "sm", disabled: revokingSessionId === session.id, onClick: () => void onRevoke?.(session.id), "aria-label": "Revoke session " + (session.deviceLabel ?? session.id), children: revokingSessionId === session.id ? "Revoking…" : "Revoke" })) : null] }, session.id));
        }) }));
}
