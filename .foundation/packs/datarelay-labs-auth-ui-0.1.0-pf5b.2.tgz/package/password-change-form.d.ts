import type { AuthErrorCategory, PasswordChangeSubmission } from "./types";
export type PasswordChangeFormProps = {
    onSubmit: (submission: PasswordChangeSubmission) => void | Promise<void>;
    busy?: boolean;
    requireCurrentPassword?: boolean;
    errorCategory?: AuthErrorCategory;
    errorMessage?: string;
    guidance?: string;
};
export declare function PasswordChangeForm({ onSubmit, busy, requireCurrentPassword, errorCategory, errorMessage, guidance }: PasswordChangeFormProps): import("react").JSX.Element;
