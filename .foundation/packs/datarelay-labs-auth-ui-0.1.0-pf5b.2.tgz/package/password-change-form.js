import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Button, TextField } from "@datarelay-labs/ui";
import { AuthErrorNotice } from "./auth-error-notice.js";
export function PasswordChangeForm({ onSubmit, busy = false, requireCurrentPassword = true, errorCategory, errorMessage, guidance }) {
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [localError, setLocalError] = useState("");
    function submit(event) {
        event.preventDefault();
        if (requireCurrentPassword && !currentPassword) {
            setLocalError("Enter your current password.");
            return;
        }
        if (!newPassword || !confirmPassword) {
            setLocalError("Enter and confirm the new password.");
            return;
        }
        if (newPassword !== confirmPassword) {
            setLocalError("New password and confirmation do not match.");
            return;
        }
        setLocalError("");
        void onSubmit({
            ...(requireCurrentPassword ? { currentPassword } : {}),
            newPassword,
            confirmPassword
        });
    }
    return (_jsxs("form", { className: "dr-auth-form", onSubmit: submit, children: [guidance ? _jsx("p", { className: "dr-auth-form__guidance", children: guidance }) : null, requireCurrentPassword ? (_jsx(TextField, { label: "Current password", type: "password", autoComplete: "current-password", value: currentPassword, onChange: (event) => setCurrentPassword(event.target.value), disabled: busy })) : null, _jsx(TextField, { label: "New password", type: "password", autoComplete: "new-password", value: newPassword, onChange: (event) => setNewPassword(event.target.value), disabled: busy }), _jsx(TextField, { label: "Confirm new password", type: "password", autoComplete: "new-password", value: confirmPassword, onChange: (event) => setConfirmPassword(event.target.value), disabled: busy }), localError ? _jsx(AuthErrorNotice, { category: "validation", message: localError }) : null, errorCategory ? _jsx(AuthErrorNotice, { category: errorCategory, ...(errorMessage ? { message: errorMessage } : {}) }) : null, _jsx(Button, { type: "submit", disabled: busy, children: busy ? "Updating…" : "Update password" })] }));
}
