import type { AuthErrorCategory } from "./types";
export type AuthErrorNoticeProps = {
    category: AuthErrorCategory;
    message?: string;
};
export declare function AuthErrorNotice({ category, message }: AuthErrorNoticeProps): import("react").JSX.Element;
