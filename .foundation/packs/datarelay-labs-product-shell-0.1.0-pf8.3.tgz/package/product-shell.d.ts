import { type ReactNode } from "react";
import type { NavigationActiveResolver, ProductCapabilityMap, ProductIdentity, ProductNavigationItem, ProductNavigationEntry, ProductShellPrincipal, ProductRuntimeEnvironment, ProductAccountAction } from "./types";
export type ProductShellProps = {
    product: ProductIdentity;
    navigation: readonly ProductNavigationEntry[];
    currentPath: string;
    onNavigate: (path: string, item?: ProductNavigationItem) => void;
    capabilities?: ProductCapabilityMap;
    isNavigationItemActive?: NavigationActiveResolver;
    pageTitle: string;
    pageSubtitle?: string;
    principal?: ProductShellPrincipal;
    /** Optional, authoritative consumer-reported environment; absent means no badge. */
    environment?: ProductRuntimeEnvironment;
    /** Product-owned account/menu actions that remain accessible when collapsed. */
    accountActions?: readonly ProductAccountAction[];
    headerActions?: ReactNode;
    sidebarTopSlot?: ReactNode;
    sidebarFooterSlot?: ReactNode;
    userActions?: ReactNode;
    children: ReactNode;
    contentId?: string;
    collapsed?: boolean;
    defaultCollapsed?: boolean;
    onCollapsedChange?: (collapsed: boolean) => void;
    mobileOpen?: boolean;
    defaultMobileOpen?: boolean;
    onMobileOpenChange?: (open: boolean) => void;
};
export declare function ProductEnvironmentStatus({ environment, compact }: {
    environment: ProductRuntimeEnvironment;
    compact?: boolean;
}): import("react").JSX.Element;
export declare function DataRelayWordmark({ collapsed }: {
    collapsed?: boolean;
}): import("react").JSX.Element;
export declare function ProductShell({ product, navigation, currentPath, onNavigate, capabilities, isNavigationItemActive, pageTitle, pageSubtitle, principal, environment, accountActions, headerActions, sidebarTopSlot, sidebarFooterSlot, userActions, children, contentId, collapsed: controlledCollapsed, defaultCollapsed, onCollapsedChange, mobileOpen: controlledMobileOpen, defaultMobileOpen, onMobileOpenChange }: ProductShellProps): import("react").JSX.Element;
