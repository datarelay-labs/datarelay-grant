import type { ReactNode } from "react";
import type { DataRelayIconName } from "@datarelay-labs/icons";
export type ProductIdentity = {
    name: string;
    shortName?: string;
    subtitle?: string;
    homePath: string;
    mark?: ReactNode;
};
export type ProductNavigationSectionRef = {
    id: string;
    label: string;
    icon?: DataRelayIconName;
    defaultExpanded?: boolean;
    requiredCapability?: string;
};
export type ProductNavigationItem = {
    id: string;
    label: string;
    path: string;
    icon?: DataRelayIconName;
    group?: string;
    requiredCapability?: string;
    disabled?: boolean;
    /** Optional grouping metadata. The item stays flat for route/title lookup. */
    section?: ProductNavigationSectionRef;
};
/** A non-navigating, accessible two-level section. Only leaves own routes.
    Existing flat ProductNavigationItem consumers remain unchanged. */
export type ProductNavigationParent = {
    id: string;
    label: string;
    /** Parent itself never routes; all paths belong to typed children. */
    path?: never;
    icon?: DataRelayIconName;
    group?: string;
    requiredCapability?: string;
    disabled?: boolean;
    defaultExpanded?: boolean;
    children: readonly ProductNavigationItem[];
};
export type ProductNavigationEntry = ProductNavigationItem | ProductNavigationParent;
export type ProductShellPrincipal = {
    displayName: string;
    detail?: string;
};
/** Product-reported environment, never inferred by the Foundation. */
export type ProductRuntimeEnvironment = "production" | "development" | "staging" | "test" | "unknown";
/** Consumer-owned actions; Foundation supplies only their common presentation. */
export type ProductAccountAction = {
    id: string;
    label: string;
    icon: DataRelayIconName;
    onSelect: () => void;
    disabled?: boolean;
    tone?: "default" | "danger";
};
export type ProductCapabilityAvailability = boolean | "supported" | "read_only" | "unavailable";
export type ProductCapabilityMap = Readonly<Record<string, ProductCapabilityAvailability>>;
export type NavigationActiveResolver = (item: ProductNavigationItem, currentPath: string) => boolean;
