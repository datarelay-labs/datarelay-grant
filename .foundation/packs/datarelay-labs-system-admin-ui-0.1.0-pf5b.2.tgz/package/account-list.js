import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { EmptyState, StatusBadge } from "@datarelay-labs/ui";
export function AccountList({ accounts, actions }) {
    if (accounts.length === 0) {
        return _jsx(EmptyState, { title: "No accounts", description: "No accounts are available from the product adapter." });
    }
    return (_jsx("ul", { className: "dr-admin__account-list", "aria-label": "Accounts", children: accounts.map((account) => (_jsxs("li", { className: "dr-admin__account", children: [_jsxs("div", { children: [_jsxs("div", { className: "dr-admin__account-title", children: [_jsx("strong", { children: account.displayName }), account.status ? _jsx(StatusBadge, { tone: "neutral", children: account.status }) : null] }), account.role ? _jsxs("p", { children: ["Role: ", account.role.label] }) : null, account.detail ? _jsx("p", { children: account.detail }) : null, account.capabilities?.length ? (_jsxs("p", { className: "dr-admin__muted", children: ["Capabilities: ", account.capabilities.join(", ")] })) : null] }), actions ? _jsx("div", { className: "dr-admin__account-actions", children: actions(account) }) : null] }, account.id))) }));
}
