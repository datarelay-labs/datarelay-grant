import { type ReactNode } from "react";
import { type OperationPreview } from "@datarelay-labs/system-contracts";
export type MutationReviewProps = {
    title: string;
    preview?: OperationPreview;
    onConfirm: () => void | Promise<void>;
    busy?: boolean;
    confirmLabel?: string;
    requireAcknowledgement?: boolean;
    unsupportedPreviewMessage?: string;
    children?: ReactNode;
};
export declare function MutationReview({ title, preview, onConfirm, busy, confirmLabel, requireAcknowledgement, unsupportedPreviewMessage, children }: MutationReviewProps): import("react").JSX.Element;
