import { type CapabilityProjection } from "@datarelay-labs/system-contracts";
export type AdminTask = CapabilityProjection & {
    description?: string;
    group?: string;
};
export type AdminTaskCatalogProps = {
    tasks: readonly AdminTask[];
    onOpen?: (task: AdminTask) => void;
    showUnavailable?: boolean;
    /** Opt in to task-qualified accessible names without changing legacy consumer selectors. */
    taskSpecificActionNames?: boolean;
};
export declare function AdminTaskCatalog({ tasks, onOpen, showUnavailable, taskSpecificActionNames }: AdminTaskCatalogProps): import("react").JSX.Element;
