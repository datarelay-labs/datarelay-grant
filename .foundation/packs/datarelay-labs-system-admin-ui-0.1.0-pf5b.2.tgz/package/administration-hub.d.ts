import { type ReactNode } from "react";
import type { CapabilityAvailability } from "@datarelay-labs/system-contracts";
import { type AdminTask } from "./admin-task-catalog";
/** Control-reference grouping is presentation metadata, not product configuration authority. */
export declare const ADMINISTRATION_CORE_GROUPS: readonly [{
    readonly id: "access-security";
    readonly title: "Access & security";
    readonly description: "TLS, platform accounts, and credential changes.";
}, {
    readonly id: "platform-network";
    readonly title: "Platform & network";
    readonly description: "Display timezone, published ports, and reverse-proxy apply workflow.";
}, {
    readonly id: "lifecycle-recovery";
    readonly title: "Lifecycle & recovery";
    readonly description: "Retention policy and portable workspace snapshots.";
}, {
    readonly id: "operations-audit";
    readonly title: "Operations & audit";
    readonly description: "Configuration history and operational health evidence.";
}];
export type AdministrationCoreGroupId = (typeof ADMINISTRATION_CORE_GROUPS)[number]["id"];
export type AdministrationTaskAccess = "manage" | "view" | "none";
export type AdministrationTaskTarget = {
    kind: "path";
    path: string;
} | {
    kind: "action";
    actionId: string;
};
/**
 * Availability says what a product implements. Access says what this actor may do.
 * Both are consumer-owned authoritative projections; neither replaces API authorization.
 */
export type AdministrationHubTask = Omit<AdminTask, "group"> & {
    access: AdministrationTaskAccess;
    target?: AdministrationTaskTarget;
};
export type AdministrationCoreTask = AdministrationHubTask & {
    groupId: AdministrationCoreGroupId;
};
export type AdministrationExtensionGroup = {
    id: string;
    title: string;
    description: string;
    after?: AdministrationCoreGroupId;
    tasks: readonly AdministrationHubTask[];
};
export type AdministrationHubComposition = {
    productId: string;
    tasks: readonly AdministrationCoreTask[];
    extensionGroups?: readonly AdministrationExtensionGroup[];
};
export type AdministrationHubProps = AdministrationHubComposition & {
    onOpen?: (task: AdministrationHubTask) => void;
    showUnavailable?: boolean;
    /** Set false when the consuming application shell already owns the page H1. */
    showHeader?: boolean;
    intro?: ReactNode;
    headerActions?: ReactNode;
};
export declare function effectiveAdministrationAvailability(task: AdministrationHubTask): CapabilityAvailability;
/** Fail closed on malformed or conflicting product-defined task/extension composition. */
export declare function validateAdministrationHub({ productId, tasks, extensionGroups }: AdministrationHubComposition): void;
export declare function AdministrationHub({ productId, tasks, extensionGroups, showUnavailable, showHeader, onOpen, intro, headerActions }: AdministrationHubProps): import("react").JSX.Element;
