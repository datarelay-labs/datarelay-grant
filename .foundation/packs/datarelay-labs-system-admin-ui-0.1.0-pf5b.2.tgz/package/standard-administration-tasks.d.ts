import type { CapabilityAvailability, OperationEffect } from "@datarelay-labs/system-contracts";
import { type AdministrationCoreTask, type AdministrationTaskAccess, type AdministrationTaskTarget } from "./administration-hub";
/**
 * One versioned Control-reference task vocabulary. These are display/task IDs,
 * NOT authorization/capability identifiers or product API routes.
 */
export declare const STANDARD_ADMINISTRATION_TASKS: readonly [{
    readonly id: "core.https";
    readonly groupId: "access-security";
    readonly label: "HTTPS";
    readonly description: "TLS listener, certificate SANs, and HTTP-to-HTTPS redirect.";
}, {
    readonly id: "core.users";
    readonly groupId: "access-security";
    readonly label: "User Management";
    readonly description: "Platform accounts, roles, and access status.";
}, {
    readonly id: "core.password";
    readonly groupId: "access-security";
    readonly label: "Password Management";
    readonly description: "Change operator passwords and credential policy.";
}, {
    readonly id: "core.timezone";
    readonly groupId: "platform-network";
    readonly label: "Display timezone";
    readonly description: "Effective display timezone, personal override, and platform default.";
}, {
    readonly id: "core.network";
    readonly groupId: "platform-network";
    readonly label: "Network";
    readonly description: "Published HTTP/HTTPS ports and reverse-proxy apply workflow.";
}, {
    readonly id: "core.retention";
    readonly groupId: "lifecycle-recovery";
    readonly label: "Retention";
    readonly description: "Cleanup scheduler and per-category retention policy.";
}, {
    readonly id: "core.backup-import";
    readonly groupId: "lifecycle-recovery";
    readonly label: "Backup & Import";
    readonly description: "Export and import portable workspace configuration snapshots.";
}, {
    readonly id: "core.audit";
    readonly groupId: "operations-audit";
    readonly label: "Audit";
    readonly description: "Platform audit trail and configuration change history.";
}, {
    readonly id: "core.health";
    readonly groupId: "operations-audit";
    readonly label: "System Health";
    readonly description: "Operational health signals, maintenance readiness, and alerts.";
}];
export type StandardAdministrationTaskId = (typeof STANDARD_ADMINISTRATION_TASKS)[number]["id"];
export type StandardAdministrationTaskBinding = {
    availability: CapabilityAvailability;
    access: AdministrationTaskAccess;
    target?: AdministrationTaskTarget;
    effects?: readonly OperationEffect[];
    permission?: string;
    notes?: string;
};
export type StandardAdministrationTaskBindings = Partial<Record<StandardAdministrationTaskId, StandardAdministrationTaskBinding>>;
/**
 * Products supply explicit binding/authority projections, never labels, grouping
 * or a made-up default availability. Missing tasks do not appear.
 */
export declare function createStandardAdministrationTasks(bindings: StandardAdministrationTaskBindings): readonly AdministrationCoreTask[];
