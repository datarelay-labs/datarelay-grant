import type { RevisionProjection } from "@datarelay-labs/system-contracts";
export type RevisionListProps = {
    revisions: readonly RevisionProjection[];
};
export declare function RevisionList({ revisions }: RevisionListProps): import("react").JSX.Element;
