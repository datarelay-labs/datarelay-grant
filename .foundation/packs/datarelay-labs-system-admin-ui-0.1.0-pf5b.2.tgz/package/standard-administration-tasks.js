import { validateAdministrationHub } from "./administration-hub.js";
/**
 * One versioned Control-reference task vocabulary. These are display/task IDs,
 * NOT authorization/capability identifiers or product API routes.
 */
export const STANDARD_ADMINISTRATION_TASKS = [
    {
        id: "core.https",
        groupId: "access-security",
        label: "HTTPS",
        description: "TLS listener, certificate SANs, and HTTP-to-HTTPS redirect."
    },
    {
        id: "core.users",
        groupId: "access-security",
        label: "User Management",
        description: "Platform accounts, roles, and access status."
    },
    {
        id: "core.password",
        groupId: "access-security",
        label: "Password Management",
        description: "Change operator passwords and credential policy."
    },
    {
        id: "core.timezone",
        groupId: "platform-network",
        label: "Display timezone",
        description: "Effective display timezone, personal override, and platform default."
    },
    {
        id: "core.network",
        groupId: "platform-network",
        label: "Network",
        description: "Published HTTP/HTTPS ports and reverse-proxy apply workflow."
    },
    {
        id: "core.retention",
        groupId: "lifecycle-recovery",
        label: "Retention",
        description: "Cleanup scheduler and per-category retention policy."
    },
    {
        id: "core.backup-import",
        groupId: "lifecycle-recovery",
        label: "Backup & Import",
        description: "Export and import portable workspace configuration snapshots."
    },
    {
        id: "core.audit",
        groupId: "operations-audit",
        label: "Audit",
        description: "Platform audit trail and configuration change history."
    },
    {
        id: "core.health",
        groupId: "operations-audit",
        label: "System Health",
        description: "Operational health signals, maintenance readiness, and alerts."
    }
];
/**
 * Products supply explicit binding/authority projections, never labels, grouping
 * or a made-up default availability. Missing tasks do not appear.
 */
export function createStandardAdministrationTasks(bindings) {
    if (!bindings || typeof bindings !== "object" || Array.isArray(bindings)) {
        throw new Error("ADMINISTRATION_STANDARD_INVALID=bindings");
    }
    const known = new Set(STANDARD_ADMINISTRATION_TASKS.map((task) => task.id));
    const allowed = new Set(["availability", "access", "target", "effects", "permission", "notes"]);
    for (const [id, binding] of Object.entries(bindings)) {
        if (!known.has(id))
            throw new Error("ADMINISTRATION_STANDARD_INVALID=unknown-task:" + id);
        if (!binding || typeof binding !== "object" || Array.isArray(binding)) {
            throw new Error("ADMINISTRATION_STANDARD_INVALID=invalid-binding:" + id);
        }
        for (const key of Object.keys(binding)) {
            if (!allowed.has(key)) {
                throw new Error("ADMINISTRATION_STANDARD_INVALID=immutable-metadata:" + id + ":" + key);
            }
        }
    }
    const tasks = [];
    for (const definition of STANDARD_ADMINISTRATION_TASKS) {
        // Only explicit, validated own bindings may make a shared task visible.
        // Prototype defaults must never silently advertise product capabilities.
        if (!Object.hasOwn(bindings, definition.id))
            continue;
        const binding = bindings[definition.id];
        if (!binding)
            continue;
        tasks.push({
            ...definition,
            availability: binding.availability,
            access: binding.access,
            ...(binding.target !== undefined ? { target: binding.target } : {}),
            ...(binding.effects !== undefined ? { effects: binding.effects } : {}),
            ...(binding.permission !== undefined ? { permission: binding.permission } : {}),
            ...(binding.notes !== undefined ? { notes: binding.notes } : {})
        });
    }
    validateAdministrationHub({ productId: "foundation", tasks });
    return tasks;
}
