import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { EmptyState, StatusBadge } from "@datarelay-labs/ui";
export function RevisionList({ revisions }) {
    if (!revisions.length) {
        return _jsx(EmptyState, { title: "No revisions", description: "No revision history is available from the product adapter." });
    }
    return (_jsx("ol", { className: "dr-admin__revision-list", "aria-label": "Revision history", children: revisions.map((revision) => (_jsxs("li", { className: "dr-admin__revision", children: [_jsxs("div", { className: "dr-admin__revision-title", children: [_jsx("strong", { children: revision.label ?? revision.id }), revision.current ? _jsx(StatusBadge, { tone: "success", children: "Current" }) : null] }), _jsxs("dl", { children: [_jsxs("div", { children: [_jsx("dt", { children: "Time" }), _jsx("dd", { children: revision.timestamp })] }), revision.actor ? _jsxs("div", { children: [_jsx("dt", { children: "Actor" }), _jsx("dd", { children: revision.actor })] }) : null, revision.audit ? _jsxs("div", { children: [_jsx("dt", { children: "Audit" }), _jsx("dd", { children: revision.audit.label ?? revision.audit.id })] }) : null] }), revision.summary ? _jsx("p", { children: revision.summary }) : null] }, revision.id))) }));
}
