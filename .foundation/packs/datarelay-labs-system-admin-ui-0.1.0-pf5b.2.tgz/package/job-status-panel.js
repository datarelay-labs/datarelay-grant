import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Card, StatusBadge } from "@datarelay-labs/ui";
function tone(state) {
    if (state === "SUCCEEDED")
        return "success";
    if (state === "FAILED")
        return "critical";
    if (state === "CANCELLED")
        return "neutral";
    return "info";
}
export function JobStatusPanel({ job, onCancel, renderResult }) {
    const progress = typeof job.progressPercent === "number"
        ? Math.min(100, Math.max(0, job.progressPercent))
        : undefined;
    return (_jsx(Card, { title: job.label ?? "Operation", actions: _jsx(StatusBadge, { tone: tone(job.state), children: job.state }), children: _jsxs("div", { className: "dr-admin__job", children: [progress !== undefined ? (_jsxs("div", { children: [_jsxs("div", { className: "dr-admin__progress-label", children: [_jsx("span", { children: "Progress" }), _jsxs("span", { children: [progress, "%"] })] }), _jsxs("progress", { max: 100, value: progress, children: [progress, "%"] })] })) : null, job.statusMessage ? _jsx("p", { children: job.statusMessage }) : null, job.error ? _jsx("p", { className: "dr-admin__job-error", role: "alert", children: job.error.message }) : null, job.state === "SUCCEEDED" && job.result !== undefined && renderResult ? (_jsx("div", { className: "dr-admin__job-result", "aria-label": "Operation result", children: renderResult(job.result) })) : null, job.auditReference ? _jsxs("p", { className: "dr-admin__muted", children: ["Reference: ", job.auditReference] }) : null, onCancel && job.cancellable ? (_jsx(Button, { variant: "secondary", onClick: () => void onCancel(job.id), children: "Cancel operation" })) : null] }) }));
}
