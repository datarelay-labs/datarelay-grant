import type { HealthProjection, SystemInfoProjection } from "@datarelay-labs/system-contracts";
export type SystemStatusProps = {
    health?: HealthProjection;
    info?: SystemInfoProjection;
};
export declare function SystemStatus({ health, info }: SystemStatusProps): import("react").JSX.Element;
