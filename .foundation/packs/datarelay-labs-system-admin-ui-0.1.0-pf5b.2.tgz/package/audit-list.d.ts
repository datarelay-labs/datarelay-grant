import type { AuditEventProjection } from "@datarelay-labs/system-contracts";
export type AuditListProps = {
    events: readonly AuditEventProjection[];
};
export declare function AuditList({ events }: AuditListProps): import("react").JSX.Element;
