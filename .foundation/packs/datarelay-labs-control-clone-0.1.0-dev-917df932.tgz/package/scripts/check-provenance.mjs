import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { resolve, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const packageRoot=resolve(dirname(fileURLToPath(import.meta.url)),'..')
const manifest=JSON.parse(readFileSync(join(packageRoot,'control-source-manifest.json'),'utf8'))
if(!/^([a-f0-9]{40})$/.test(manifest.pinned_commit) || manifest.source_file_count!==manifest.source_files.length)
  throw Error('Invalid Control provenance manifest.')
for(const item of manifest.source_files) {
  if(!/^[a-zA-Z0-9_./-]+$/.test(item.path)||item.path.includes('..'))throw Error('Unsafe path in manifest.')
  const source=readFileSync(join(packageRoot,'src/control',item.path))
  const actual=createHash('sha256').update(source).digest('hex')
  if(actual!==item.local_sha256)throw Error('Control source changed without pinned provenance update: '+item.path)
  if(item.identical_to_control && actual!==item.upstream_sha256)throw Error('Control original unexpectedly changed: '+item.path)
}
console.log('Control pinned source manifest PASS:',manifest.source_file_count,'files,',
  manifest.source_files.filter(x=>x.identical_to_control).length,'byte-identical,',
  manifest.native_adapter_only_diffs.length,'controlled integration differences.')
