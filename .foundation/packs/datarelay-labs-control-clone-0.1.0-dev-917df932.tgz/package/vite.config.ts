import { defineConfig } from 'vite'
export default defineConfig({
  build: {
    lib: { entry: 'src/index.ts', formats: ['es'], fileName: 'index' },
    emptyOutDir: true,
    rollupOptions: {
      external: ['react', 'react-dom', 'react/jsx-runtime', 'lucide-react', 'react-router-dom', 'clsx', 'tailwind-merge']
    }
  }
})
