import type { ReactNode } from "react";
import type { AuthResourceLink } from "./types";

export type AuthLayoutProps = {
  productName: string;
  productSubtitle?: string;
  description?: string;
  title: string;
  subtitle?: string;
  resources?: readonly AuthResourceLink[];
  brandMark?: ReactNode;
  className?: string;
  showWordmark?: boolean;
  children: ReactNode;
};

export function AuthLayout({
  productName,
  productSubtitle,
  description,
  title,
  subtitle,
  resources = [],
  brandMark,
  className,
  showWordmark = true,
  children
}: AuthLayoutProps) {
  return (
    <main className={["dr-auth-layout", className].filter(Boolean).join(" ")}>
      <section className="dr-auth-layout__identity" aria-label="Product information">
        {brandMark ? <div className="dr-auth-layout__mark">{brandMark}</div> : null}
        {showWordmark ? (
          <div className="dr-auth-layout__wordmark" aria-label="DataRelay">
            <span>Data</span><span>Relay</span>
          </div>
        ) : null}
        <div className="dr-auth-layout__product">{productName}</div>
        {productSubtitle ? <p className="dr-auth-layout__product-subtitle">{productSubtitle}</p> : null}
        {description ? <p className="dr-auth-layout__description">{description}</p> : null}
        {resources.length ? (
          <nav aria-label="Resources" className="dr-auth-layout__resources">
            {resources.map((resource) => (
              <a
                key={resource.href}
                href={resource.href}
                {...(resource.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              >
                <span>{resource.title}</span>
                {resource.description ? <small>{resource.description}</small> : null}
              </a>
            ))}
          </nav>
        ) : null}
      </section>

      <section className="dr-auth-card" aria-labelledby="dr-auth-title">
        <header className="dr-auth-card__header">
          <h1 id="dr-auth-title">{title}</h1>
          {subtitle ? <p>{subtitle}</p> : null}
        </header>
        {children}
      </section>
    </main>
  );
}
