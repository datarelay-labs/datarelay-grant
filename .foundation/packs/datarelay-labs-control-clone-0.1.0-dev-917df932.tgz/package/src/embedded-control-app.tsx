import { useEffect, useMemo, useState } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { PlatformLoginPage } from './platform-login-page'
import { ControlSecurityProvider } from './security/provider'
import { DisplayTimezoneProvider } from './control/contexts/display-timezone-context'
import { AppShellLayout } from './control/components/layout/app-shell-layout'
import { AdminSettingsPage } from './control/components/settings/admin-settings-page'
import { installControlNativeSessionAdapter } from './runtime/session-bridge'
import { installControlHttpTransport } from './runtime/transport'
import { createEmbeddedFoundationClient } from './runtime/embedded-client'

/** Ready-to-mount Control-first shell with the real Foundation embedded service.
 * Uses server-managed HttpOnly session cookies and native server-side policies.
 * No credential or policy is trusted from localStorage.
 */
export function EmbeddedControlApp() {
  const client = useMemo(() => createEmbeddedFoundationClient(), [])
  const [ready, setReady] = useState(false)
  const [, bump] = useState(0)
  useEffect(() => {
    const offSession = installControlNativeSessionAdapter({
      read: client.readNativeSession,
      onChange: client.onChange,
      clearLocal: () => { void client.logout() }
    })
    const offTransport = installControlHttpTransport((url, init) => {
      // The original Control DTO endpoints are product-dependent. In standalone
      // mode no installed native API owns them, so return an explicit non-2xx
      // JSON error. Never fetch the SPA fallback page as a successful API result.
      // This also prevents a localStorage base-URL override from calling a
      // different origin with session credentials.
      const requested = new URL(url, window.location.href)
      if (requested.origin !== window.location.origin ||
          !(/^\/api\/(foundation|v1)\//.test(requested.pathname))) {
        return Promise.resolve(new Response(JSON.stringify({
          detail: 'This Control API is unavailable in the embedded runtime.'
        }), { status: 503, headers: { 'content-type': 'application/json' } }))
      }
      const headers = new Headers(init.headers)
      if ((init.method ?? 'GET').toUpperCase() !== 'GET') {
        const csrf = client.readCsrf()
        if (!csrf) return Promise.resolve(new Response(
          JSON.stringify({ detail: 'Authenticated CSRF token required.' }),
          { status: 403, headers: { 'content-type': 'application/json' } }
        ))
        headers.set('X-Foundation-CSRF', csrf)
      }
      return fetch(requested, { ...init, headers, credentials: 'same-origin', redirect: 'error' })
    })
    const offChange = client.onChange(() => bump(n => n + 1))
    void client.refresh().finally(() => setReady(true))
    return () => { offChange(); offTransport(); offSession() }
  }, [client])
  if (!ready) return <div className="dark min-h-screen bg-gdc-background p-6 text-gdc-foreground" data-dr-theme="dark" role="status">Checking session…</div>
  if (!client.isAuthenticated()) return (
    <div className="dark" data-dr-theme="dark">
      <PlatformLoginPage adapter={client.login} onAuthenticated={() => bump(n => n + 1)} />
    </div>
  )
  return (
    <BrowserRouter>
      <DisplayTimezoneProvider>
        <ControlSecurityProvider adapters={client.adapters}>
          <Routes>
            <Route element={<AppShellLayout />}>
              <Route path="/settings" element={<AdminSettingsPage />} />
              <Route path="/admin" element={<AdminSettingsPage />} />
              <Route path="*" element={<Navigate to="/settings" replace />} />
            </Route>
          </Routes>
        </ControlSecurityProvider>
      </DisplayTimezoneProvider>
    </BrowserRouter>
  )
}
