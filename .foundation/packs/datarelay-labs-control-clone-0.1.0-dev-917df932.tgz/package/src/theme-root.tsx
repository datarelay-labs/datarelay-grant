import type { HTMLAttributes, ReactNode } from "react";
import { cx } from "./utils";

export type DataRelayThemeName = "light" | "dark";

export type ThemeRootProps = HTMLAttributes<HTMLDivElement> & {
  theme: DataRelayThemeName;
  children: ReactNode;
};

export function ThemeRoot({ theme, className, children, ...props }: ThemeRootProps) {
  return (
    <div {...props} data-dr-theme={theme} className={cx("dr-theme", className)}>
      {children}
    </div>
  );
}
