import { useEffect, useState, type FormEvent } from 'react'
import { AuthLayout } from './auth-layout'
import { BookOpen, Eye, EyeOff, Globe, Lock, Mail, Rocket, ScrollText, User } from 'lucide-react'
import type { ControlLoginAdapter } from './types'
import { DataRelayLogoMark } from './datarelay-logo'

const RESOURCES: readonly {
  title: string
  subtitle: string
  href: string
  icon: typeof BookOpen
}[] = [
  { title: 'Documentation', subtitle: 'datarelay.run/docs', href: 'https://datarelay.run/docs', icon: BookOpen },
  { title: 'Quick Start Guide', subtitle: 'datarelay.run/quickstart', href: 'https://datarelay.run/quickstart', icon: Rocket },
  { title: 'Release Notes', subtitle: 'datarelay.run/releases', href: 'https://datarelay.run/releases', icon: ScrollText },
  { title: 'DataRelay Website', subtitle: 'datarelay.run', href: 'https://datarelay.run', icon: Globe },
  { title: 'Support', subtitle: 'support@datarelay.run', href: 'mailto:support@datarelay.run', icon: Mail },
]

type PlatformLoginPageProps = {
  onAuthenticated: () => void
  adapter: ControlLoginAdapter
}

export function PlatformLoginPage({ onAuthenticated, adapter }: PlatformLoginPageProps) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [info, setInfo] = useState<string | null>(null)
  const [challengeRef, setChallengeRef] = useState<string | null>(null)
  const [otp, setOtp] = useState('')
  const [recoveryAvailable, setRecoveryAvailable] = useState(false)
  const [useRecovery, setUseRecovery] = useState(false)

  useEffect(() => {
    try {
      if (sessionStorage.getItem('gdc_post_password_change') === '1') {
        sessionStorage.removeItem('gdc_post_password_change')
        setInfo('Password updated. Sign in with your new password.')
      }
    } catch {
      /* ignore */
    }
  }, [])

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    const u = username.trim()
    if (!u || !password) {
      setError('Enter your username and password.')
      return
    }
    setBusy(true)
    try {
      const outcome = await adapter.signIn({ username: u, password })
      if (outcome?.state === 'authenticated') {
        setPassword('')
        onAuthenticated()
      } else if (outcome?.state === 'mfa_required' &&
                 typeof outcome.challengeRef === 'string' &&
                 outcome.challengeRef.length > 0 && outcome.challengeRef.length <= 256 &&
                 Array.isArray(outcome.methods) && (outcome.methods.includes('totp') || outcome.methods.includes('recovery'))) {
        setPassword('')
        setOtp('')
        setRecoveryAvailable(outcome.methods.includes('recovery'))
        setUseRecovery(!outcome.methods.includes('totp'))
        setChallengeRef(outcome.challengeRef)
      } else {
        throw new Error('The sign-in server returned an invalid authentication result.')
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign-in failed.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="gdc-login-centered" data-testid="gdc-login-centered">
      <AuthLayout
      productName="DataRelay"
      productSubtitle="Operational Data Connector Platform"
      description="Collect. Transform. Deliver. Connect to any source, transform and enrich your data, then deliver it to multiple destinations reliably and securely."
      title="Welcome to DataRelay"
      subtitle="Please sign in to continue."
      brandMark={<DataRelayLogoMark className="h-12 w-auto" aria-label="DataRelay logo" />}
      resources={RESOURCES.map(({ title, subtitle, href }) => ({
        title,
        description: subtitle,
        href,
        external: href.startsWith('http'),
      }))}
    >
      {challengeRef ? (
        <form onSubmit={(e) => {
          e.preventDefault()
          if (busy) return
          setError(null)
          if (!(useRecovery ? /^[a-f0-9]{24}$/i.test(otp) : /^\d{6}$/.test(otp))) {
            setError(useRecovery ? 'Enter one of your saved 24-character recovery codes.' :
              'Enter the six-digit code from your authenticator.')
            return
          }
          setBusy(true)
          void (async () => {
            try {
              const result = await adapter.verifyOtp({ challengeRef, code: otp })
              if (result?.state !== 'authenticated') throw new Error('OTP verification was not accepted.')
              setOtp('')
              setChallengeRef(null)
              onAuthenticated()
            } catch (err) {
              setError(err instanceof Error ? err.message : 'OTP verification failed.')
            } finally {
              setBusy(false)
            }
          })()
        }} className="space-y-4">
          <div>
            <label htmlFor="platform-login-otp" className="mb-1.5 block text-xs font-medium text-gdc-mutedStrong">
              {useRecovery ? 'Recovery code' : 'Authenticator code'}
            </label>
            <input
              id="platform-login-otp"
              name="otp"
              type="text"
              inputMode={useRecovery ? 'text' : 'numeric'}
              pattern={useRecovery ? '[0-9a-fA-F]{24}' : '[0-9]{6}'}
              maxLength={useRecovery ? 24 : 6}
              autoComplete="one-time-code"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="h-9 w-full rounded-lg border border-gdc-inputBorder bg-gdc-input px-3 py-2 text-sm text-gdc-foreground focus:border-gdc-primary focus:outline-none focus:ring-2 focus:ring-violet-400/30"
            />
          </div>
          {error ? <p role="alert" className="text-sm text-rose-500">{error}</p> : null}
          <button type="submit" disabled={busy} className="mt-2 flex h-9 w-full items-center justify-center rounded-lg bg-gdc-primary text-sm font-semibold text-white hover:bg-violet-700 disabled:opacity-50">
            {busy ? 'Verifying…' : useRecovery ? 'Verify recovery code' : 'Verify code'}
          </button>
          {recoveryAvailable && <button type="button" disabled={busy} onClick={() => {
            setUseRecovery(value => !value)
            setOtp('')
            setError(null)
          }} className="w-full text-sm text-gdc-mutedStrong hover:underline">
            {useRecovery ? 'Use authenticator code' : 'Use a recovery code'}
          </button>}
          <button type="button" disabled={busy} onClick={() => {
            setChallengeRef(null)
            setOtp('')
            setUseRecovery(false)
            setRecoveryAvailable(false)
            setError(null)
            setPassword('')
          }} className="w-full text-sm text-gdc-mutedStrong hover:underline">Back to sign in</button>
        </form>
      ) : (
      <form onSubmit={(e) => void onSubmit(e)} className="space-y-4">
        <div>
          <label htmlFor="platform-login-username" className="mb-1.5 block text-xs font-medium text-gdc-mutedStrong">
            Username
          </label>
          <div className="relative">
            <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gdc-placeholder" aria-hidden />
            <input
              id="platform-login-username"
              name="username"
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your username"
              className="h-9 w-full rounded-lg border border-gdc-inputBorder bg-gdc-input py-2 pl-10 pr-3 text-sm text-gdc-foreground placeholder:text-gdc-placeholder focus:border-gdc-primary focus:outline-none focus:ring-2 focus:ring-violet-400/30"
            />
          </div>
        </div>

        <div>
          <label htmlFor="platform-login-password" className="mb-1.5 block text-xs font-medium text-gdc-mutedStrong">
            Password
          </label>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gdc-placeholder" aria-hidden />
            <input
              id="platform-login-password"
              name="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="h-9 w-full rounded-lg border border-gdc-inputBorder bg-gdc-input py-2 pl-10 pr-11 text-sm text-gdc-foreground placeholder:text-gdc-placeholder focus:border-gdc-primary focus:outline-none focus:ring-2 focus:ring-violet-400/30"
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-gdc-muted hover:bg-gdc-rowHover hover:text-gdc-foreground"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {info ? (
          <p className="rounded-md border border-emerald-500/30 bg-emerald-950/40 px-3 py-2 text-xs text-emerald-100" role="status">
            {info}
          </p>
        ) : null}

        {error ? (
          <p className="rounded-md border border-rose-500/30 bg-rose-950/40 px-3 py-2 text-xs text-rose-200" role="alert">
            {error}
          </p>
        ) : null}

        <button
          type="submit"
          disabled={busy}
          className="mt-2 flex h-9 w-full items-center justify-center rounded-lg bg-gdc-primary text-sm font-semibold text-white hover:bg-violet-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/60 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy ? 'Signing in…' : 'Sign In'}
        </button>

        <p className="pt-1 text-center text-xs leading-relaxed text-gdc-muted">
          Accounts are created by an administrator. Self-service registration is not available.
        </p>
      </form>
      )}
      </AuthLayout>
    </div>
  )
}
