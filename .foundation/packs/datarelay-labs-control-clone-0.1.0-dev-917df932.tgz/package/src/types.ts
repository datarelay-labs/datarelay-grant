/**
 * Consumer's authentication service establishes the verified session on success.
 * A password-accepted MFA challenge is NOT an authenticated session.
 */
export type ControlLoginOutcome =
  | { state: 'authenticated' }
  | { state: 'mfa_required'; challengeRef: string; methods: readonly ('totp' | 'recovery')[] }

export type ControlLoginAdapter = {
  signIn(credentials: { username: string; password: string }): Promise<ControlLoginOutcome>
  verifyOtp(request: { challengeRef: string; code: string }): Promise<{ state: 'authenticated' }>
}

export type AuthResourceLink = {
  title: string
  description?: string
  href: string
  external?: boolean
}
