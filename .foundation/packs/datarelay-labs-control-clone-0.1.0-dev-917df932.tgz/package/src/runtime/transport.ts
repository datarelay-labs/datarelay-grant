/**
 * Consumer-supplied native transport boundary for the cloned Control UI.
 *
 * No request is sent to Control's original API host unless the consumer
 * explicitly installs a transport. Consumers translate URLs into their own
 * authenticated, role-enforced API/host/DB operations; UI is never authority.
 */
export type ControlHttpTransport = (url: string, init: RequestInit) => Promise<Response>
let registered: ControlHttpTransport | null = null

/** One Control shell is supported per browser realm. Do not share across SSR requests. */
export function installControlHttpTransport(transport: ControlHttpTransport): () => void {
  if (typeof transport !== 'function') throw new Error('An authenticated Control transport is required.')
  if (registered !== null) throw new Error('A Control transport is already installed.')
  registered = transport
  return () => { if (registered === transport) registered = null }
}

export function controlHttpRequest(url: string, init: RequestInit = {}): Promise<Response> {
  if (registered === null) return Promise.reject(new Error('Control native transport is not installed.'))
  return registered(url, init)
}
