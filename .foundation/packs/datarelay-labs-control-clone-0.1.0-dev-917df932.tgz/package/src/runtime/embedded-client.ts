import type { ControlLoginAdapter } from '../types'
import type { ControlSecurityAdapters } from '../security/types'
import type { NativeControlSession } from './session-bridge'

type SessionResponse = { authenticated: boolean; csrf?: string; expiresAt?: string; user?: NativeControlSession['user'] }

type Result<T> = Promise<T>

/** Same-origin HttpOnly-cookie client for Foundation's concrete SQLite-backed service.
 * No product-auth adapter implementation is required: mount EmbeddedControlApp
 * and run the matching Python Foundation service behind the same-origin /api proxy.
 */
export function createEmbeddedFoundationClient() {
  let session: SessionResponse = { authenticated: false }
  const listeners = new Set<() => void>()
  const emit = () => { for (const callback of listeners) callback() }
  const call = async <T>(path: string, body?: object, hasSession = true): Result<T> => {
    const headers: Record<string, string> = { Accept: 'application/json' }
    if (body !== undefined) {
      headers['Content-Type'] = 'application/json'
      if (hasSession) {
        if (!session.csrf) throw new Error('A fresh authenticated session is required.')
        headers['X-Foundation-CSRF'] = session.csrf
      }
    }
    const response = await fetch('/api/foundation/' + path, {
      method: body === undefined ? 'GET' : 'POST',
      credentials: 'same-origin', redirect: 'error', cache: 'no-store',
      headers, ...(body === undefined ? {} : { body: JSON.stringify(body) })
    })
    const value = await response.json().catch(() => null) as (T & { error?: string }) | null
    if (!response.ok) {
      if (response.status === 401 && hasSession) {
        session = { authenticated: false }
        emit()
      }
      throw new Error(value?.error ?? 'Security service request failed (' + response.status + ').')
    }
    if (value == null) throw new Error('Security service returned an invalid response.')
    return value
  }
  const refresh = async () => {
    try { session = await call<SessionResponse>('session') }
    catch { session = { authenticated: false } }
    emit()
    return session
  }
  const login: ControlLoginAdapter = {
    signIn: async ({ username, password }) => {
      const result = await call<Awaited<ReturnType<ControlLoginAdapter['signIn']>>>(
        'auth/login', { username, password }, false
      )
      if (result.state === 'authenticated') await refresh()
      return result
    },
    verifyOtp: async ({ challengeRef, code }) => {
      const result = await call<Awaited<ReturnType<ControlLoginAdapter['verifyOtp']>>>(
        'auth/otp', { challengeRef, code }, false
      )
      if (result.state === 'authenticated') await refresh()
      return result
    }
  }
  const accessFor = (read: string, manage: string) => ({
    get canRead() { return session.authenticated === true && session.user?.capabilities?.[read] === true },
    get canManage() { return session.authenticated === true && session.user?.capabilities?.[manage] === true }
  })
  const adapters: ControlSecurityAdapters = {
    mfa: {
      access: accessFor('mfa.read', 'mfa.manage'),
      read: () => call('mfa'),
      begin: (expectedRevision) => call('mfa/begin', { expectedRevision }),
      confirm: (request) => call('mfa/confirm', request),
      disable: (request) => call('mfa/disable', request)
    },
    acl: {
      access: accessFor('acl.read', 'acl.manage'),
      read: () => call('acl'),
      preview: (request) => call('acl/preview', request),
      apply: (request) => call('acl/apply', request),
      confirmSsh: (request) => call('acl/confirm', request)
    },
    roles: {
      access: accessFor('roles.read', 'roles.manage'),
      read: () => call('roles'),
      preview: (request) => call('roles/preview', request),
      apply: (request) => call('roles/apply', request)
    },
    sessions: {
      access: accessFor('sessions.read', 'sessions.manage'),
      read: () => call('sessions'),
      revoke: (request) => call('sessions/revoke', request)
    }
  }
  return {
    login, adapters, refresh,
    isAuthenticated: () => session.authenticated === true && Boolean(session.user),
    readNativeSession: (): NativeControlSession | null => session.authenticated && session.user &&
      typeof session.expiresAt === 'string' ? { expiresAt: session.expiresAt, user: session.user } : null,
    onChange: (callback: () => void) => {
      listeners.add(callback)
      return () => { listeners.delete(callback) }
    },
    readCsrf: () => session.authenticated === true ? session.csrf ?? null : null,
    logout: async () => {
      try { await call('auth/logout', {}) }
      finally { session = { authenticated: false }; emit() }
    }
  }
}

export type EmbeddedFoundationClient = ReturnType<typeof createEmbeddedFoundationClient>
