import type { SessionUser, StoredSession } from '../control/auth/session'

/**
 * Native session identity is product-owned: an authenticated server principal,
 * never an unauthenticated password/TOTP challenge. Bearer/refresh tokens are
 * intentionally not required when the product uses an HttpOnly cookie transport.
 */
export type NativeControlSession = {
  expiresAt: string
  user: SessionUser
}
export type ControlNativeSessionAdapter = {
  read(): NativeControlSession | null
  onChange?(callback: () => void): () => void
  clearLocal?(): void
}
let current: ControlNativeSessionAdapter | null = null
export function installControlNativeSessionAdapter(adapter: ControlNativeSessionAdapter): () => void {
  if (!adapter || typeof adapter.read !== 'function') throw Error('A native session reader is required.')
  if (current) throw Error('A Control native session adapter is already installed.')
  current = adapter
  return () => { if (current === adapter) current = null }
}
export function readNativeControlSession(): StoredSession | null {
  if (!current) return null
  try {
    const value=current.read()
    if (!value || typeof value.expiresAt !== 'string' ||
      !Number.isFinite(Date.parse(value.expiresAt)) || Date.parse(value.expiresAt) <= Date.now() ||
      !value.user || typeof value.user.username !== 'string' || value.user.username.length<1 ||
      !['ADMINISTRATOR','OPERATOR','CONNECTOR_OPERATOR','GOVERNANCE_OPERATOR',
         'GOVERNANCE_REVIEWER','GOVERNANCE_APPROVER','GOVERNANCE_AUDITOR','VIEWER']
        .includes(value.user.role) || typeof value.user.status !== 'string') return null
    return {
      access_token: '',
      refresh_token: '',
      expires_at: value.expiresAt,
      user: value.user
    }
  } catch { return null }
}
export function clearNativeControlSession(): void { current?.clearLocal?.() }
export function onNativeControlSessionChange(callback: () => void): () => void {
  return current?.onChange?.(callback) ?? (() => {})
}
