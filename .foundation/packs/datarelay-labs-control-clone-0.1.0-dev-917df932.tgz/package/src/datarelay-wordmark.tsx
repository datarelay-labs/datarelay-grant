export function DataRelayWordmark({ collapsed = false }: { collapsed?: boolean }) {
  if (collapsed) {
    return (
      <span className="dr-shell__mark" aria-hidden>
        <span>D</span>
        <span>R</span>
      </span>
    );
  }
  return (
    <span className="dr-shell__wordmark" aria-hidden>
      <span>Data</span>
      <span className="dr-shell__wordmark-relay">Relay</span>
    </span>
  );
}
