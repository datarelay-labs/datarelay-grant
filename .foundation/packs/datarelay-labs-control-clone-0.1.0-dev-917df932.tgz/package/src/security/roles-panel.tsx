import { useEffect, useRef, useState } from 'react'
import { SecuritySection, Unavailable, Message, actionClass, secondaryClass, validRevision, validPreview } from './common'
import type { RolesAdapter, RolePolicy, RoleChangePreview, RoleDefinition } from './types'
const eq=(a:readonly string[],b:readonly string[])=>a.length===b.length&&a.every(x=>b.includes(x))
export function ControlRolesPanel({adapter}:{adapter?:RolesAdapter}) {
  const live=useRef({adapter,epoch:0})
  if(live.current.adapter!==adapter)live.current={adapter,epoch:live.current.epoch+1}
  const [policy,setPolicy]=useState<RolePolicy|null>(null)
  const [roleId,setRoleId]=useState(''),[chosen,setChosen]=useState<readonly string[]>([])
  const [preview,setPreview]=useState<RoleChangePreview|null>(null)
  const [confirmed,setConfirmed]=useState(false)
  const [busy,setBusy]=useState(false),[uncertain,setUncertain]=useState(false)
  const [error,setError]=useState(''),[notice,setNotice]=useState('')
  const readable=!!adapter?.access.canRead,editable=readable&&!!adapter?.access.canManage
  useEffect(()=>{
    let alive=true
    setPolicy(null);setRoleId('');setChosen([]);setPreview(null);setConfirmed(false);setError('');setNotice('');setUncertain(false)
    if(!adapter||!readable)return()=>{alive=false}
    setBusy(true)
    void adapter.read().then(p=>{
      if(!alive)return
      if(!validRevision(p?.revision)||!Array.isArray(p.roles)||!Array.isArray(p.availablePermissions))
        throw new Error('Invalid roles')
      setPolicy(p)
      const role=p.roles[0]
      if(role){setRoleId(role.id);setChosen(role.permissions)}
    }).catch(()=>{if(alive)setError('Unable to read roles and permissions.')})
      .finally(()=>{if(alive)setBusy(false)})
    return()=>{alive=false;live.current.epoch++}
  },[adapter,readable])
  const selected=policy?.roles.find(r=>r.id===roleId)
  function pick(role:RoleDefinition) {setRoleId(role.id);setChosen(role.permissions);setPreview(null);setConfirmed(false)}
  function toggle(perm:string,enabled:boolean){
    if(!editable||!selected?.mutable)return
    setChosen(current=>enabled?[...current,perm]:current.filter(p=>p!==perm))
    setPreview(null);setConfirmed(false);setNotice('');setError('')
  }
  async function prepare(){
    if(!adapter||!editable||!policy||!selected?.mutable||busy||uncertain||eq(selected.permissions,chosen))return
    const epoch=live.current.epoch,revision=policy.revision,id=selected.id
    setBusy(true);setPreview(null);setConfirmed(false);setNotice('');setError('')
    try{
      const p=await adapter.preview({expectedRevision:revision,roleId:id,permissions:chosen})
      if(epoch!==live.current.epoch)return
      if(!validPreview(p,revision)){setError('Unsafe or stale role change.');return}
      setPreview(p)
    }catch{if(epoch===live.current.epoch)setError('Role changes cannot be previewed safely.')}
    finally{if(epoch===live.current.epoch)setBusy(false)}
  }
  async function apply(){
    if(!adapter||!editable||!policy||!selected?.mutable||!preview||!confirmed||
      !validPreview(preview,policy.revision)||busy||uncertain)return
    const epoch=live.current.epoch,id=selected.id,perms=[...chosen],revision=policy.revision,ref=preview.previewRef
    setPreview(null);setConfirmed(false);setUncertain(true);setBusy(true);setError('');setNotice('')
    try{
      const accepted=await adapter.apply({expectedRevision:revision,previewRef:ref,confirm:true})
      if(epoch!==live.current.epoch)return
      if(!validRevision(accepted?.revision)||accepted.revision===revision||!eq(accepted.roles.find(r=>r.id===id)?.permissions??[],perms))
        throw new Error('Invalid role write receipt')
      const current=await adapter.read()
      if(epoch!==live.current.epoch)return
      if(current.revision!==accepted.revision||!eq(current.roles.find(r=>r.id===id)?.permissions??[],perms))
        throw new Error('Role write readback mismatch')
      setPolicy(current);setUncertain(false);setNotice('Role permissions updated and verified.')
    }catch{if(epoch===live.current.epoch)setError('Role write may have completed. Refresh state before retrying.')}
    finally{if(epoch===live.current.epoch)setBusy(false)}
  }
  async function refresh(){
    if(!adapter||!readable||busy)return
    const epoch=++live.current.epoch
    setPolicy(null);setPreview(null);setConfirmed(false);setBusy(true);setError('');setNotice('')
    try{
      const p=await adapter.read()
      if(epoch!==live.current.epoch)return
      if(!validRevision(p?.revision)||!Array.isArray(p.roles)||!Array.isArray(p.availablePermissions))throw Error('Invalid')
      setPolicy(p)
      const r=p.roles.find(r=>r.id===roleId)??p.roles[0]
      if(r){setRoleId(r.id);setChosen(r.permissions)}
      setUncertain(false)
    }catch{if(epoch===live.current.epoch)setError('Unable to verify current role policy.')}
    finally{if(epoch===live.current.epoch)setBusy(false)}
  }
  return <SecuritySection id="admin-roles-heading" title="Roles & Permissions"
    description="Review roles and apply only server-authorized permission changes. Protected roles and last administrators are enforced by the native service.">
    {!adapter?<Unavailable feature="roles and permissions"/>:!readable?<p role="status">Roles require authorized access.</p>:<>
      <Message error={error} notice={notice}/>
      <label htmlFor="control-role-select" className="block">Role</label>
      <select id="control-role-select" value={roleId} className="w-full rounded-lg border p-2 dark:bg-gdc-input"
        disabled={busy||uncertain||!policy} onChange={e=>{const role=policy?.roles.find(r=>r.id===e.target.value);if(role)pick(role)}}>
        {policy?.roles.map(r=><option key={r.id} value={r.id}>{r.label}</option>)}
      </select>
      {selected&&<fieldset disabled={!editable||!selected.mutable||busy||uncertain} className="space-y-2">
        <legend className="font-semibold">Permissions</legend>
        {policy?.availablePermissions.map(p=><label key={p} className="flex gap-2">
          <input type="checkbox" checked={chosen.includes(p)} onChange={e=>toggle(p,e.target.checked)}/>{p}</label>)}
        {!selected.mutable&&<p>This role is protected and cannot be changed.</p>}
      </fieldset>}
      {editable&&<button type="button" className={actionClass} disabled={!selected?.mutable||!policy||busy||uncertain||eq(chosen,selected.permissions)}
        onClick={()=>void prepare()}>Preview role changes</button>}
      {preview&&policy&&validPreview(preview,policy.revision)&&editable&&<>
        <p role="status">The native service returned a valid safety preview for this role edit.</p>
        <label className="flex gap-2"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/>Confirm permission change</label>
        <button className={actionClass} type="button" disabled={!confirmed||busy} onClick={()=>void apply()}>Apply permission change</button>
      </>}
      <button type="button" className={secondaryClass} disabled={busy} onClick={()=>void refresh()}>Refresh role policy</button>
    </>}
  </SecuritySection>
}
