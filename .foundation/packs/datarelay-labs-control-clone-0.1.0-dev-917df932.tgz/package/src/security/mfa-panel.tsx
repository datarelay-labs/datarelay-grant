import { useEffect, useRef, useState } from 'react'
import { SecuritySection, Unavailable, Message, actionClass, secondaryClass, fieldClass, validRevision } from './common'
import type { MfaAdapter, MfaConfirmation, MfaEnrollment, MfaStatus } from './types'

export function ControlMfaPanel({ adapter }: { adapter?: MfaAdapter }) {
  const live = useRef({ adapter, epoch: 0 })
  if (live.current.adapter !== adapter) live.current = { adapter, epoch: live.current.epoch + 1 }
  const [status, setStatus] = useState<MfaStatus | null>(null)
  const [enrollment, setEnrollment] = useState<MfaEnrollment | null>(null)
  const [code, setCode] = useState('')
  const [codes, setCodes] = useState<readonly string[]>([])
  const [confirmDisable, setConfirmDisable] = useState(false)
  const [busy, setBusy] = useState(false)
  const [uncertain, setUncertain] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const accessible = !!adapter?.access.canRead
  const editable = !!adapter?.access.canRead && !!adapter?.access.canManage
  useEffect(() => {
    let alive = true
    setStatus(null); setEnrollment(null); setCode(''); setCodes([])
    setBusy(false); setUncertain(false); setError(''); setNotice('')
    if (!adapter?.access.canRead) return () => { alive = false }
    setBusy(true)
    void adapter.read().then(s => {
      if (!alive) return
      if (!validRevision(s?.revision) || typeof s.enrolled !== 'boolean' ||
          typeof s.required !== 'boolean' || !Number.isSafeInteger(s.recoveryCodesRemaining) ||
          s.recoveryCodesRemaining < 0) throw new Error('Invalid MFA response')
      setStatus(s)
    }).catch(() => { if (alive) setError('Unable to read MFA configuration.') })
      .finally(() => { if (alive) setBusy(false) })
    return () => { alive = false; live.current.epoch++ }
  }, [adapter, accessible])
  async function begin() {
    if (!adapter || !editable || busy || uncertain || !status || status.enrolled) return
    const epoch=live.current.epoch
    setBusy(true); setError(''); setNotice(''); setCodes([])
    try {
      const e = await adapter.begin(status.revision)
      if (epoch !== live.current.epoch) return
      if (!validRevision(e?.enrollmentRef) || e.expectedRevision !== status.revision ||
          !e.secret || !e.otpauthUri?.startsWith('otpauth://totp/')) throw new Error('Invalid enrollment')
      setEnrollment(e)
    } catch { if (epoch === live.current.epoch) setError('Could not securely start MFA enrollment.') }
    finally { if (epoch === live.current.epoch) setBusy(false) }
  }
  async function complete() {
    if (!adapter || !editable || busy || uncertain || !enrollment || !/^\d{6}$/.test(code)) return
    const epoch=live.current.epoch
    setBusy(true); setUncertain(true); setError(''); setNotice('')
    try {
      const result: MfaConfirmation = await adapter.confirm({
        expectedRevision: enrollment.expectedRevision, enrollmentRef: enrollment.enrollmentRef, code
      })
      if (epoch !== live.current.epoch) return
      if (!validRevision(result?.revision) || result.revision === enrollment.expectedRevision ||
          !result.enrolled || !Array.isArray(result.recoveryCodes) || !result.recoveryCodes.length)
        throw new Error('Unverified enrollment')
      const authoritative = await adapter.read()
      if (epoch !== live.current.epoch) return
      if (authoritative.revision !== result.revision || !authoritative.enrolled)
        throw new Error('MFA enrollment readback mismatch')
      setStatus(authoritative); setEnrollment(null); setCode('')
      setCodes(result.recoveryCodes)
      setUncertain(false); setNotice('MFA enrollment confirmed by the authentication service.')
    } catch {
      if (epoch === live.current.epoch) {
        setEnrollment(null); setCode(''); setCodes([])
        setError('MFA enrollment result is uncertain. Reload before retrying.')
      }
    } finally { if (epoch === live.current.epoch) setBusy(false) }
  }
  async function disable() {
    if (!adapter || !editable || !confirmDisable || busy || uncertain || !status?.enrolled || status.required) return
    const epoch=live.current.epoch
    setBusy(true); setUncertain(true); setError(''); setNotice(''); setCodes([])
    try {
      const result=await adapter.disable({expectedRevision:status.revision,confirm:true})
      if (epoch!==live.current.epoch) return
      if (!validRevision(result?.revision) || result.revision===status.revision || result.enrolled)
        throw new Error('Unverified disable')
      const authoritative=await adapter.read()
      if (epoch!==live.current.epoch) return
      if (authoritative.revision!==result.revision || authoritative.enrolled)
        throw new Error('Readback mismatch')
      setStatus(authoritative); setUncertain(false); setNotice('MFA disabled and verified.')
    } catch {
      if (epoch===live.current.epoch) setError('MFA status unknown. Reload before retrying.')
    } finally { if (epoch===live.current.epoch) { setBusy(false); setConfirmDisable(false) } }
  }
  return <SecuritySection id="admin-mfa-heading" title="Multi-factor authentication (MFA)"
    description="Protect sign-in with a time-based one-time password after your username and password.">
    {!adapter ? <Unavailable feature="MFA"/> :
      !accessible ? <p role="status">MFA information requires authorized access.</p> :
      <>
        <Message error={error} notice={notice}/>
        {status && <div>
          <p>Authenticator: <strong>{status.enrolled?'Enrolled':'Not enrolled'}</strong>
            {status.required?' · Required by policy':''}</p>
          <p>Recovery codes remaining: {status.recoveryCodesRemaining}</p>
        </div>}
        {enrollment && <>
          <p role="status">Register the authenticator using the following URI. Treat it as a secret.</p>
          <code className="block break-all rounded-lg border border-gdc-border p-3">{enrollment.otpauthUri}</code>
          <label htmlFor="control-mfa-code" className="block">Six-digit authenticator code</label>
          <input id="control-mfa-code" className={fieldClass} inputMode="numeric" autoComplete="one-time-code"
            pattern="[0-9]{6}" maxLength={6} value={code} onChange={e=>setCode(e.target.value)} />
          <button className={actionClass} type="button" disabled={!editable||busy||uncertain||!/^\d{6}$/.test(code)}
            onClick={()=>void complete()}>Confirm MFA enrollment</button>
          <button className={secondaryClass} type="button" disabled={busy} onClick={()=>{setEnrollment(null);setCode('')}}>Cancel enrollment</button>
        </>}
        {codes.length>0 && <div role="status" className="break-all rounded-lg border border-amber-500 p-3">
          Save these single-use recovery codes now. They will not be shown again.
          <ul>{codes.map(c=><li key={c}><code>{c}</code></li>)}</ul>
          <button type="button" className={secondaryClass} onClick={()=>setCodes([])}>I have saved these codes</button>
        </div>}
        {editable && status && !busy && !uncertain && !enrollment && <>
          {!status.enrolled && <button className={actionClass} type="button" onClick={()=>void begin()}>Set up MFA</button>}
          {status.enrolled && !status.required && <>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={confirmDisable} onChange={e=>setConfirmDisable(e.target.checked)}/>
              Confirm disable MFA for this account
            </label>
            <button type="button" disabled={!confirmDisable} className={actionClass} onClick={()=>void disable()}>Disable MFA</button>
          </>}
        </>}
        {editable && <button type="button" className={secondaryClass} disabled={busy} onClick={()=>{live.current.epoch++;setUncertain(false);setEnrollment(null);setCodes([]);setStatus(null);setBusy(true);setError('');void adapter.read().then(v=>{if(validRevision(v.revision))setStatus(v);else setError('Invalid MFA state')}).catch(()=>setError('Cannot refresh MFA state')).finally(()=>setBusy(false))}}>Refresh MFA status</button>}
      </>}
  </SecuritySection>
}
