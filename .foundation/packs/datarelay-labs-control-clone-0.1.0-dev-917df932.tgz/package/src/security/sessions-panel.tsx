import { useEffect, useRef, useState } from 'react'
import { SecuritySection, Unavailable, Message, actionClass, secondaryClass, validRevision } from './common'
import type { SessionsAdapter, SessionsSnapshot } from './types'

function validSessions(s:SessionsSnapshot):boolean {
  return !!s&&validRevision(s.revision)&&Array.isArray(s.sessions)&&s.sessions.length<=10000&&
    s.sessions.every(entry=>typeof entry.id==='string'&&entry.id.length>0&&entry.id.length<=256&&
      typeof entry.principal==='string'&&typeof entry.revocable==='boolean'&&
      typeof entry.current==='boolean'&&typeof entry.createdAt==='string'&&typeof entry.lastSeenAt==='string')
}
export function ControlSessionsPanel({adapter}:{adapter?:SessionsAdapter}) {
  const live=useRef({adapter,epoch:0})
  if(live.current.adapter!==adapter)live.current={adapter,epoch:live.current.epoch+1}
  const [snapshot,setSnapshot]=useState<SessionsSnapshot|null>(null)
  const [pending,setPending]=useState<string|null>(null),[confirmed,setConfirmed]=useState(false)
  const [busy,setBusy]=useState(false),[uncertain,setUncertain]=useState(false)
  const [error,setError]=useState(''),[notice,setNotice]=useState('')
  const readable=!!adapter?.access.canRead,editable=readable&&!!adapter?.access.canManage
  useEffect(()=>{
    let alive=true
    setSnapshot(null);setPending(null);setConfirmed(false);setError('');setNotice('');setUncertain(false)
    if(!adapter||!readable)return()=>{alive=false}
    setBusy(true)
    void adapter.read().then(result=>{
      if(!alive)return
      if(!validSessions(result))throw Error('Invalid session snapshot')
      setSnapshot(result)
    }).catch(()=>{if(alive)setError('Unable to read current sessions.')})
      .finally(()=>{if(alive)setBusy(false)})
    return()=>{alive=false;live.current.epoch++}
  },[adapter,readable])
  async function refresh(){
    if(!adapter||!readable||busy)return
    const epoch=++live.current.epoch
    setBusy(true);setSnapshot(null);setPending(null);setConfirmed(false);setError('');setNotice('')
    try{
      const current=await adapter.read()
      if(epoch!==live.current.epoch)return
      if(!validSessions(current))throw Error('Invalid')
      setSnapshot(current);setUncertain(false)
    }catch{if(epoch===live.current.epoch)setError('Unable to verify current sessions.')}
    finally{if(epoch===live.current.epoch)setBusy(false)}
  }
  async function revoke(){
    if(!adapter||!editable||!snapshot||!pending||!confirmed||busy||uncertain)return
    const selected=snapshot.sessions.find(s=>s.id===pending)
    if(!selected?.revocable||selected.current)return // never revoke current session through this UI.
    const epoch=live.current.epoch,id=selected.id,revision=snapshot.revision
    setBusy(true);setUncertain(true);setError('');setNotice('');setPending(null);setConfirmed(false)
    try{
      const receipt=await adapter.revoke({expectedRevision:revision,sessionId:id,confirm:true})
      if(epoch!==live.current.epoch)return
      if(!validRevision(receipt?.revision)||receipt.revision===revision)throw Error('Bad receipt')
      const authoritative=await adapter.read()
      if(epoch!==live.current.epoch)return
      if(!validSessions(authoritative)||authoritative.revision!==receipt.revision||
        authoritative.sessions.some(s=>s.id===id))throw Error('Session readback mismatch')
      setSnapshot(authoritative);setUncertain(false);setNotice('Session revoked and verified by the service.')
    }catch{if(epoch===live.current.epoch)setError('Session state is uncertain. Refresh before attempting another revoke.')}
    finally{if(epoch===live.current.epoch)setBusy(false)}
  }
  return <SecuritySection id="admin-sessions-heading" title="Active Sessions"
    description="Review authenticated sessions and explicitly revoke an eligible remote session. The current session is protected.">
    {!adapter?<Unavailable feature="sessions"/>:!readable?<p role="status">Session management requires authorized access.</p>:<>
      <Message error={error} notice={notice}/>
      <ul className="divide-y divide-slate-200 dark:divide-gdc-border">
        {snapshot?.sessions.map(s=><li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
          <div><strong>{s.principal}</strong>{s.current?' · Current session':''}
            <p className="text-xs text-slate-600 dark:text-gdc-muted">Created: {s.createdAt}</p>
            <p className="text-xs text-slate-600 dark:text-gdc-muted">Last activity: {s.lastSeenAt}</p>
          </div>
          {editable&&s.revocable&&!s.current&&
            <button type="button" className={secondaryClass} disabled={busy||uncertain}
              onClick={()=>{setPending(s.id);setConfirmed(false);setError('');setNotice('')}}>Revoke session</button>}
        </li>)}
      </ul>
      {snapshot?.sessions.length===0&&<p>No active sessions.</p>}
      {pending&&snapshot?.sessions.some(s=>s.id===pending&&!s.current&&s.revocable)&&editable&&<>
        <p role="status">Revoking this session immediately signs out the selected user session.</p>
        <label className="flex gap-2"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/>Confirm revoke this session</label>
        <button type="button" className={actionClass} disabled={!confirmed||busy||uncertain}
          onClick={()=>void revoke()}>Confirm session revocation</button>
        <button type="button" className={secondaryClass} onClick={()=>{setPending(null);setConfirmed(false)}}>Cancel</button>
      </>}
      <button type="button" className={secondaryClass} disabled={busy} onClick={()=>void refresh()}>Refresh active sessions</button>
    </>}
  </SecuritySection>
}
