import { useEffect, useRef, useState } from 'react'
import { SecuritySection, Unavailable, Message, actionClass, secondaryClass, fieldClass, validRevision, validPreview } from './common'
import type { ManagementAccessAdapter, ManagementAccessPolicy, ManagementAccessPreview } from './types'

const lines=(text:string):string[]=>text.split(/[\n,]/).map(s=>s.trim()).filter(Boolean)
const same=(a:readonly string[], b:readonly string[])=>a.length===b.length&&a.every((s,i)=>s===b[i])

export function ControlAclPanel({adapter}:{adapter?:ManagementAccessAdapter}) {
  const live=useRef({adapter,epoch:0})
  if(live.current.adapter!==adapter)live.current={adapter,epoch:live.current.epoch+1}
  const [policy,setPolicy]=useState<ManagementAccessPolicy|null>(null)
  const [web,setWeb]=useState(''),[ssh,setSsh]=useState('')
  const [preview,setPreview]=useState<ManagementAccessPreview|null>(null)
  const [confirmed,setConfirmed]=useState(false)
  const [busy,setBusy]=useState(false),[uncertain,setUncertain]=useState(false)
  const [error,setError]=useState(''),[notice,setNotice]=useState('')
  const readable=!!adapter?.access.canRead, editable=readable&&!!adapter?.access.canManage
  useEffect(()=>{
    let alive=true
    setPolicy(null);setPreview(null);setWeb('');setSsh('');setConfirmed(false);setError('');setNotice('');setUncertain(false)
    if(!readable||!adapter)return()=>{alive=false}
    setBusy(true)
    void adapter.read().then(p=>{
      if(!alive)return
      if(!validRevision(p?.revision)||!Array.isArray(p.webCidrs)||!Array.isArray(p.sshCidrs))
        throw Error('Invalid management ACL')
      setPolicy(p);setWeb(p.webCidrs.join('\n'));setSsh(p.sshCidrs.join('\n'))
    }).catch(()=>{if(alive)setError('Could not retrieve management access policy.')})
      .finally(()=>{if(alive)setBusy(false)})
    return ()=>{alive=false;live.current.epoch++}
  },[adapter,readable])
  function changed(kind:'web'|'ssh',value:string){
    if(!editable)return
    if(kind==='web')setWeb(value);else setSsh(value)
    setPreview(null);setConfirmed(false);setNotice('');setError('')
  }
  async function prepare(){
    if(!adapter||!editable||!policy||busy||uncertain||lines(web).length===0)return
    const epoch=live.current.epoch
    setBusy(true);setPreview(null);setConfirmed(false);setError('');setNotice('')
    try {
      const result=await adapter.preview({expectedRevision:policy.revision,webCidrs:lines(web),sshCidrs:lines(ssh)})
      if(epoch!==live.current.epoch)return
      if(!validPreview(result,policy.revision)||result.lockoutRisk!==false){
        setError('Policy is unsafe, stale, or could lock out management access.')
        return
      }
      setPreview(result)
    }catch { if(epoch===live.current.epoch)setError('Cannot preview management access change.') }
    finally {if(epoch===live.current.epoch)setBusy(false)}
  }
  async function apply(){
    if(!adapter||!editable||!confirmed||!policy||!preview||!validPreview(preview,policy.revision)||preview.lockoutRisk!==false||busy||uncertain)return
    const expectedWeb=lines(web),expectedSsh=lines(ssh),epoch=live.current.epoch,previewRef=preview.previewRef
    setPreview(null);setConfirmed(false);setBusy(true);setUncertain(true);setError('');setNotice('')
    try{
      const applied=await adapter.apply({expectedRevision:policy.revision,previewRef,confirm:true})
      if(epoch!==live.current.epoch)return
      if(!validRevision(applied?.revision)||applied.revision===policy.revision||
        !same(applied.webCidrs,expectedWeb)||!same(applied.sshCidrs,expectedSsh))throw Error('Apply mismatch')
      const authoritative=await adapter.read()
      if(epoch!==live.current.epoch)return
      if(authoritative.revision!==applied.revision||!same(authoritative.webCidrs,expectedWeb)||
        !same(authoritative.sshCidrs,expectedSsh))throw Error('Policy read-back mismatch')
      setPolicy(authoritative);setUncertain(false)
      setNotice(authoritative.sshPending
        ? 'SSH ACL staged. Open a NEW SSH connection and confirm it before the rollback timer expires; otherwise the host reverts automatically.'
        : 'Management access policy applied and verified by the service.')
    }catch{if(epoch===live.current.epoch)setError('Management access result is uncertain. Recover/re-read before retrying.')}
    finally{if(epoch===live.current.epoch)setBusy(false)}
  }
  async function confirmNativeSsh(){
    if(!adapter?.confirmSsh||!editable||busy||!policy?.sshPending)return
    const epoch=live.current.epoch
    setBusy(true);setError('');setNotice('')
    try{
      const updated=await adapter.confirmSsh({
        expectedRevision:policy.revision,operation:policy.sshPending.operation,confirm:true
      })
      if(epoch!==live.current.epoch)return
      if(updated.sshPending||!same(updated.sshCidrs,policy.sshCidrs))
        throw Error('Native SSH confirmation did not match')
      const authoritative=await adapter.read()
      if(authoritative.sshPending||!same(authoritative.sshCidrs,updated.sshCidrs))
        throw Error('Native SSH readback mismatch')
      setPolicy(authoritative);setSsh(authoritative.sshCidrs.join('\n'))
      setNotice('SSH ACL confirmed by the native kernel authority and stored for reboot.')
    }catch{
      if(epoch===live.current.epoch)setError('SSH confirmation failed or timed out. Refresh to check native rollback.')
    }finally{if(epoch===live.current.epoch)setBusy(false)}
  }
  async function refresh(){
    if(!adapter||!readable||busy)return
    const epoch=live.current.epoch+1
    live.current.epoch=epoch
    setBusy(true);setPolicy(null);setPreview(null);setConfirmed(false);setError('');setNotice('')
    try {
      const p=await adapter.read()
      if(epoch!==live.current.epoch)return
      if(!validRevision(p?.revision)||!Array.isArray(p.webCidrs)||!Array.isArray(p.sshCidrs))throw Error('Invalid')
      setPolicy(p);setWeb(p.webCidrs.join('\n'));setSsh(p.sshCidrs.join('\n'));setUncertain(false)
    }catch {if(epoch===live.current.epoch)setError('Unable to verify current policy.')}
    finally {if(epoch===live.current.epoch)setBusy(false)}
  }
  return <SecuritySection id="admin-acl-heading" title="Management Access (ACL)"
    description="Restrict access to the Web UI/API and SSH using IP and CIDR allowlists. Changes require backend safety preview and confirmation.">
    {!adapter?<Unavailable feature="management access"/>:!readable?<p role="status">Management access policy requires authorization.</p>:<>
      <Message error={error} notice={notice}/>
      <label className="block" htmlFor="control-acl-web">Web UI / API allowed IP addresses and CIDRs (one per line)</label>
      <textarea id="control-acl-web" className={fieldClass} rows={3} value={web} readOnly={!editable||!policy||busy||uncertain}
        onChange={e=>changed('web',e.target.value)}/>
      <label className="block" htmlFor="control-acl-ssh">SSH allowed IP addresses and CIDRs (one per line)</label>
      <textarea id="control-acl-ssh" className={fieldClass} rows={3} value={ssh} readOnly={!editable||!policy||busy||uncertain}
        onChange={e=>changed('ssh',e.target.value)}/>
      {policy&&<p className="text-xs">Current policy revision: <code>{policy.revision}</code></p>}
      {policy?.sshPending&&<p role="status">SSH policy pending native confirmation; it will automatically roll back unless confirmed before the deadline. First verify a NEW SSH connection to the host.</p>}
      {editable&&policy?.sshPending&&adapter?.confirmSsh&&<button type="button" className={actionClass}
        disabled={busy||uncertain} onClick={()=>void confirmNativeSsh()}>Confirm verified SSH access</button>}
      {editable&&<button className={actionClass} type="button" disabled={!policy||!!policy.sshPending||busy||uncertain||lines(web).length===0||
        (same(lines(web),policy.webCidrs)&&same(lines(ssh),policy.sshCidrs))}
        onClick={()=>void prepare()}>Preview management access</button>}
      {preview&&policy&&validPreview(preview,policy.revision)&&preview.lockoutRisk===false&&editable&&<>
        <p role="status">Backend safety preview passed. Verify you will retain Web access before applying.</p>
        <label className="flex items-center gap-2"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/>
          Confirm the Web/SSH access changes</label>
        <button type="button" className={actionClass} disabled={!confirmed||busy} onClick={()=>void apply()}>
          Apply access policy</button>
      </>}
      <button type="button" className={secondaryClass} disabled={busy} onClick={()=>void refresh()}>Refresh authoritative policy</button>
    </>}
  </SecuritySection>
}
