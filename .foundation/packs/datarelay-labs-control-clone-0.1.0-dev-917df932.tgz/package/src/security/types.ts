import type { ReactNode } from 'react'

/** All writes must be reauthorized and committed by a native, auditable service. */
export type SecurityAccess = { canRead: boolean; canManage: boolean }
export type Revisioned = { revision: string }
export type MfaStatus = Revisioned & {
  enrolled: boolean
  required: boolean
  recoveryCodesRemaining: number
}
export type MfaEnrollment = {
  enrollmentRef: string
  expectedRevision: string
  secret: string
  otpauthUri: string
}
export type MfaConfirmation = MfaStatus & { recoveryCodes: readonly string[] }
export type MfaAdapter = {
  access: SecurityAccess
  read(): Promise<MfaStatus>
  begin(expectedRevision: string): Promise<MfaEnrollment>
  confirm(request: { expectedRevision: string; enrollmentRef: string; code: string }): Promise<MfaConfirmation>
  disable(request: { expectedRevision: string; confirm: true }): Promise<MfaStatus>
}
export type ManagementAccessPolicy = Revisioned & {
  webCidrs: readonly string[]
  sshCidrs: readonly string[]
  sshPending?: { operation: string; expiresAt: number }
}
export type ManagementAccessPreview = {
  previewRef: string
  expectedRevision: string
  safe: boolean
  lockoutRisk: boolean
  expiresAt: number
}
export type ManagementAccessAdapter = {
  access: SecurityAccess
  read(): Promise<ManagementAccessPolicy>
  preview(request: { expectedRevision: string; webCidrs: readonly string[]; sshCidrs: readonly string[] }): Promise<ManagementAccessPreview>
  apply(request: { expectedRevision: string; previewRef: string; confirm: true }): Promise<ManagementAccessPolicy>
  confirmSsh?(request: { expectedRevision: string; operation: string; confirm: true }): Promise<ManagementAccessPolicy>
}
export type RoleDefinition = { id: string; label: string; permissions: readonly string[]; mutable: boolean }
export type RolePolicy = Revisioned & {
  roles: readonly RoleDefinition[]
  availablePermissions: readonly string[]
}
export type RoleChangePreview = {
  previewRef: string
  expectedRevision: string
  safe: boolean
  expiresAt: number
}
export type RolesAdapter = {
  access: SecurityAccess
  read(): Promise<RolePolicy>
  preview(request: { expectedRevision: string; roleId: string; permissions: readonly string[] }): Promise<RoleChangePreview>
  apply(request: { expectedRevision: string; previewRef: string; confirm: true }): Promise<RolePolicy>
}
export type SessionSummary = {
  id: string
  principal: string
  createdAt: string
  lastSeenAt: string
  current: boolean
  revocable: boolean
}
export type SessionsSnapshot = Revisioned & { sessions: readonly SessionSummary[] }
export type SessionsAdapter = {
  access: SecurityAccess
  read(): Promise<SessionsSnapshot>
  revoke(request: { expectedRevision: string; sessionId: string; confirm: true }): Promise<Revisioned>
}
export type ControlSecurityAdapters = {
  mfa?: MfaAdapter
  acl?: ManagementAccessAdapter
  roles?: RolesAdapter
  sessions?: SessionsAdapter
}
export type ControlSecurityProviderProps = {
  adapters: ControlSecurityAdapters
  children: ReactNode
}
