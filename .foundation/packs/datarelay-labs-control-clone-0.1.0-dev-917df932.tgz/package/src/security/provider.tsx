import { createContext, useContext, type ReactNode } from 'react'
import type { ControlSecurityAdapters } from './types'
const Context = createContext<ControlSecurityAdapters>({})
export function ControlSecurityProvider({ adapters, children }: { adapters: ControlSecurityAdapters; children: ReactNode }) {
  return <Context.Provider value={adapters}>{children}</Context.Provider>
}
export function useControlSecurityAdapters(): ControlSecurityAdapters { return useContext(Context) }
