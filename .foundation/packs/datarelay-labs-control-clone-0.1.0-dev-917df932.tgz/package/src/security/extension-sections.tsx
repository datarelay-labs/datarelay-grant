import { ControlMfaPanel } from './mfa-panel'
import { ControlAclPanel } from './acl-panel'
import { ControlRolesPanel } from './roles-panel'
import { ControlSessionsPanel } from './sessions-panel'
import { useControlSecurityAdapters } from './provider'
/** The only four additive sections in Control's existing settings page. */
export function ControlSecurityExtensionSections() {
  const adapters=useControlSecurityAdapters()
  return <>
    <ControlMfaPanel adapter={adapters.mfa}/>
    <ControlAclPanel adapter={adapters.acl}/>
    <ControlRolesPanel adapter={adapters.roles}/>
    <ControlSessionsPanel adapter={adapters.sessions}/>
  </>
}
