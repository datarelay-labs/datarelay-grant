import type { ReactNode } from 'react'
import { gdcUi } from '../control/lib/gdc-ui-tokens'

export function SecuritySection({ id, title, description, children }: {
  id: string; title: string; description: string; children: ReactNode
}) {
  return (
    <section className={[gdcUi.cardShell, 'overflow-hidden'].join(' ')} aria-labelledby={id} data-testid={id}>
      <div className="border-b border-slate-100 px-4 py-5 dark:border-gdc-border md:px-6">
        <h3 id={id} className="text-base font-semibold text-slate-900 dark:text-slate-50">{title}</h3>
        <p className="mt-1 text-sm leading-relaxed text-slate-600 dark:text-gdc-muted">{description}</p>
      </div>
      <div className="space-y-4 px-4 py-5 text-sm text-slate-800 dark:text-slate-200 md:px-6 md:py-6">{children}</div>
    </section>
  )
}

export function Unavailable({ feature }: { feature: string }) {
  return <p role="status">The {feature} adapter is not configured. This feature is unavailable; no changes will be made.</p>
}

export function Message({ error, notice }: { error?: string; notice?: string }) {
  return <>
    {error ? <p role="alert" className="rounded-lg border border-rose-500/30 p-3 text-rose-600 dark:text-rose-300">{error}</p> : null}
    {notice ? <p role="status" className="rounded-lg border border-emerald-500/30 p-3 text-emerald-700 dark:text-emerald-300">{notice}</p> : null}
  </>
}

export const actionClass = 'rounded-lg bg-gdc-primary px-4 py-2 text-sm font-semibold text-white hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-50'
export const secondaryClass = 'rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold dark:border-gdc-border'
export const fieldClass = 'min-h-9 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 dark:border-gdc-inputBorder dark:bg-gdc-input dark:text-gdc-foreground'
export function validRevision(revision: unknown): revision is string {
  return typeof revision === 'string' && revision.length > 0 && revision.length <= 128 && !/[\u0000-\u001f\u007f]/.test(revision)
}
export function validPreview(preview: { previewRef: string; expectedRevision: string; safe: boolean; expiresAt: number } | null, expected: string): boolean {
  return !!preview && validRevision(preview.previewRef) && preview.expectedRevision === expected &&
    preview.safe === true && Number.isFinite(preview.expiresAt) && preview.expiresAt > Date.now()
}
