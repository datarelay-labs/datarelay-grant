import { useCallback, useEffect, useState } from 'react'
import { DatabaseBackup, ShieldCheck } from 'lucide-react'
import { gdcUi } from '../../lib/gdc-ui-tokens'

type NativeBackup = {
  keepLast: number
  revision: string
  retentionRevision: string
  retain: string[]
  remove: string[]
  configured: boolean
}
type Retention = { keepLast: number; revision: string; enabled: boolean }
type RetentionPreview = {
  keepLast: number; revision: string; retain: string[]; remove: string[]
}
type Receipt = { reference: string; encrypted?: boolean; verified?: boolean;
  restoredToIsolatedDirectory?: boolean }

async function nativeRequest<T>(path: string, body?: object): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' }
  if (body !== undefined) {
    const session = await fetch('/api/foundation/session', {
      credentials: 'same-origin', cache: 'no-store',
    })
    if (!session.ok) throw Error('The authenticated management session has expired.')
    const state = await session.json() as { authenticated?: boolean; csrf?: string }
    if (!state.authenticated || !state.csrf) throw Error('Management authentication is required.')
    headers['Content-Type'] = 'application/json'
    headers['X-Foundation-CSRF'] = state.csrf
  }
  const response = await fetch('/api/foundation/host/' + path, {
    method: body === undefined ? 'GET' : 'POST',
    credentials: 'same-origin', cache: 'no-store', redirect: 'error',
    headers, ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  })
  const payload = await response.json().catch(() => null) as (T & { error?: string }) | null
  if (!response.ok) {
    throw Error(payload?.error ?? ('Native host service rejected request ('+response.status+').'))
  }
  if (!payload) throw Error('Native backup did not return authoritative readback.')
  return payload
}

export function AdminNativeBackupPanel({isAdmin}:{isAdmin:boolean}) {
  const [backup,setBackup] = useState<NativeBackup|null>(null)
  const [retention,setRetention] = useState<Retention|null>(null)
  const [keepLast,setKeepLast] = useState(7)
  const [preview,setPreview] = useState<RetentionPreview|null>(null)
  const [confirmation,setConfirmation] = useState(false)
  const [busy,setBusy] = useState(false)
  const [unavailable,setUnavailable] = useState(false)
  const [message,setMessage] = useState('')
  const [error,setError] = useState('')

  const refresh=useCallback(async()=>{
    if (!isAdmin) return
    const [snap, policy] = await Promise.all([
      nativeRequest<NativeBackup>('backup'),
      nativeRequest<Retention>('retention'),
    ])
    setBackup(snap);setRetention(policy);setKeepLast(policy.keepLast)
    setUnavailable(false)
  },[isAdmin])

  useEffect(()=>{
    let active=true
    if (!isAdmin) return
    void refresh().catch(()=>{if(active)setUnavailable(true)})
    return ()=>{active=false}
  },[isAdmin,refresh])

  async function action(fn:()=>Promise<string>, options?:{preservePreview?:boolean}) {
    if (busy||!isAdmin)return
    setBusy(true);setError('');setMessage('')
    try{
      const result=await fn()
      await refresh()
      if (!options?.preservePreview) {setPreview(null);setConfirmation(false)}
      setMessage(result)
    }catch(e){
      setError(e instanceof Error?e.message:'Native host operation was not verified.')
    }finally{setBusy(false)}
  }

  function setDays(value:number){
    setKeepLast(value);setPreview(null);setConfirmation(false);setMessage('')
  }

  return <section className={gdcUi.cardShell+' overflow-hidden'} aria-labelledby="admin-native-backup-heading"
    data-testid="admin-native-backup">
    <div className="flex items-start gap-3 border-b border-slate-100 px-4 py-5 dark:border-gdc-border md:px-6">
      <DatabaseBackup className="mt-1 h-5 w-5 shrink-0 text-violet-600" aria-hidden />
      <div className="min-w-0">
        <h3 id="admin-native-backup-heading" className="text-base font-semibold">
          Encrypted SQLite backups &amp; retention
        </h3>
        <p className="mt-1 text-sm text-slate-600 dark:text-gdc-muted">
          Create AES-256-GCM snapshots, verify source integrity, and rehearse recovery
          in an isolated folder. Live database replacement is never performed here.
        </p>
      </div>
    </div>
    <div className="space-y-4 px-4 py-5 md:px-6">
      {!isAdmin?<p role="status">Administrator access is required for native host recovery.</p>:
       unavailable?<p role="status">Native encrypted backup is unavailable. Install the
         standalone private SQLite repository and backup key on the host.</p>:<>
        {error&&<p role="alert" className="text-sm text-red-700 dark:text-red-300">{error}</p>}
        {message&&<p role="status" className="text-sm text-emerald-700 dark:text-emerald-300">{message}</p>}
        <p className="text-sm text-slate-600 dark:text-gdc-muted" data-testid="native-backup-count">
          Verified repository: {backup?.retain.length??0} retained;
          {backup?.remove.length??0} older than current policy
        </p>
        <div className="flex flex-wrap gap-2">
          <button type="button" className={gdcUi.primaryBtn} disabled={busy||!backup}
            onClick={()=>void action(async()=>{
              const saved=await nativeRequest<Receipt>('backup/create',{confirm:true})
              return 'Encrypted backup created: '+saved.reference
            })}>Create encrypted backup</button>
          <button type="button" className={gdcUi.secondaryBtn} disabled={busy||!backup?.retain[0]}
            onClick={()=>void action(async()=>{
              const ref=backup!.retain[0]
              await nativeRequest<Receipt>('backup/verify',{reference:ref})
              return 'SHA-256 and encrypted SQLite backup verified: '+ref
            })}>Verify newest</button>
          <button type="button" className={gdcUi.secondaryBtn} disabled={busy||!backup?.retain[0]}
            onClick={()=>void action(async()=>{
              const ref=backup!.retain[0]
              const test=await nativeRequest<Receipt>('backup/restore-drill',
                {reference:ref,confirm:true})
              if(!test.restoredToIsolatedDirectory)throw Error('Recovery drill is unverified.')
              return 'Isolated restore successful: '+ref
            })}>Test isolated restore</button>
        </div>
        <div className="space-y-3 border-t border-slate-200 pt-4 dark:border-gdc-border">
          <label className="block text-sm" htmlFor="native-keep-last">
            Keep the latest encrypted backups (1–365)
          </label>
          <input id="native-keep-last" type="number" min={1} max={365}
            value={keepLast} disabled={busy||!retention}
            className={gdcUi.input+' max-w-40'}
            onChange={event=>setDays(Number(event.target.value))}/>
          <div className="flex flex-wrap gap-2">
            <button type="button" className={gdcUi.secondaryBtn}
              disabled={busy||!retention||!Number.isInteger(keepLast)||keepLast<1||keepLast>365||
                        retention.keepLast===keepLast}
              onClick={()=>void action(async()=>{
                await nativeRequest('retention/configure',{
                  expectedRevision:retention!.revision,keepLast,confirm:true
                })
                return 'Retention policy saved for subsequent systemd cleanup.'
              })}>Save policy</button>
            <button type="button" className={gdcUi.secondaryBtn}
              disabled={busy||!retention||keepLast!==retention.keepLast}
              onClick={()=>void action(async()=>{
                const p=await nativeRequest<RetentionPreview>('retention/preview',{keepLast})
                setPreview(p)
                return 'Previewed '+p.remove.length+' removable encrypted snapshot(s).'
              },{preservePreview:true})}>Preview cleanup</button>
          </div>
          {preview&&<div className="space-y-2" data-testid="native-backup-retention-preview">
            <p className="text-sm">Delete {preview.remove.length} older snapshots;
              preserve {preview.retain.length} newest snapshots.</p>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={confirmation}
                onChange={e=>setConfirmation(e.target.checked)}/>
              Confirm deletion of reviewed encrypted backups
            </label>
            <button type="button" disabled={busy||!confirmation} className={gdcUi.primaryBtn}
              onClick={()=>void action(async()=>{
                const applied=await nativeRequest<{verified:boolean;deletedEncryptedSnapshots:number}>(
                  'retention/run',{keepLast,expectedRevision:preview.revision,confirm:true})
                if(!applied.verified)throw Error('Native retention did not verify disk changes.')
                return 'Deleted '+applied.deletedEncryptedSnapshots+' older encrypted backups.'
              })}>Apply reviewed cleanup</button>
          </div>}
        </div>
        <p className="flex items-center gap-2 text-xs text-slate-500 dark:text-gdc-muted">
          <ShieldCheck className="h-4 w-4" aria-hidden />
          Scheduled backups require a separately installed persistent systemd timer.
          Decryption keys never leave the host.
        </p>
      </>}
    </div>
  </section>
}
