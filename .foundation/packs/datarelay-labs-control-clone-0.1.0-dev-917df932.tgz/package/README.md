# Control-first DataRelay Product Foundation

The actual DataRelay Control source is the canonical UI authority, not the
historical Foundation UI packages. Upstream pin:
`datarelay-labs/datarelay-control@fc89dadcb01a262ef7881a6bca94dd4989a8b496`.

**Source fidelity:** 96 Control source modules, 90 byte-identical, 6 documented
integration differences. Original Control semantic colors, Tailwind, fonts,
login layout, sidebar/header, System Management and logos are retained.
`npm run check:control-presentation` compares original HTML, favicon, sidebar
logo and CSS source blobs. An accessible mobile drawer close control was added
to fix an actual overlay interaction defect.

## Ready-to-mount portable security application

Consumers that do **not** want to develop their own common authentication
or management APIs use `EmbeddedControlApp` and the matching Python
`datarelay_onprem_security.embedded_runtime`. It provides:

- Persistent credential validation and real password → TOTP / one-time
  recovery-code login with a challenge-bound, server-authorized session;
- Web UI, static assets and API ACL enforcement, real CIDR storage, source
  trust/lockout safety;
- Role and permission policy, administrative user/password CRUD and
  last-admin safeguards;
- Audited session issuance/list/revoke, timezone, system information,
  security changes and access checks.

Backend: private SQLite, transactional writes and audit, HttpOnly
SameSite=Strict cookies, Origin + CSRF checks. The React runtime is
`packages/control-clone/src/embedded-control-app.tsx`. The Python ASGI
server can serve the Vite `control-clone-reference` static bundle itself,
with both Web UI and API under one authoritative Web ACL. No prewired demo
credentials or client-trusted policy is shipped.

**Not native host enforcement:** product SSH ACL, host firewall, real nginx
TLS/certificate/port, retention schedulers, backup/restore and external
operations monitoring still need independently qualified native host
capability/installation. Those calls fail closed; SSH mutations are refused.
No host configuration is modified by Foundation tests.

## Build, test and independent browser E2E

From the Foundation repository:

```bash
npm ci
npm run build:control-clone
npm run check:control-presentation
npm run test:control-clone
npm run test:control-first-e2e
PYTHONPATH=python/onprem-security/src python3 -m unittest discover -s python/onprem-security/tests
```

Browser E2E uses a temporary, private SQLite database; a local pinned
`uvicorn` must be installed (or specify `FOUNDATION_E2E_UVICORN`).
It exercises Control login, sidebar/menu/dark-light presentation, Users,
MFA/enrollment/TOTP/recovery, ACL, Roles, Sessions, session revocation and
375/320px mobile flows. No production credentials/host policy are touched.

## Distribution and integration

The canonical `@datarelay-labs/foundation` npm entry exports:

```tsx
import {
  EmbeddedControlApp,
  PlatformLoginPage,
  ControlAppShellLayout,
  ControlAdminSettingsPage,
  ControlDisplayTimezoneProvider,
  ControlSecurityProvider,
  createEmbeddedFoundationClient,
  installControlHttpTransport,
  installControlNativeSessionAdapter
} from '@datarelay-labs/foundation'
import '@datarelay-labs/foundation/styles.css'
```

Deploy `EmbeddedControlApp` and the Python ASGI entrypoint for ready-made
portable management. Or opt out of the embedded service and use the original
`ControlLoginAdapter`, `ControlSecurityAdapters`, native transport and
session adapter interfaces with an existing identity/host backend.

The unpublished private candidate contains compiled npm archives, the real
Python service Wheel and a ready-to-host `web-dist` (HTML, JS, CSS,
favicon, original Control sidebar SVG logo). Distribution does **not**
publish, merge, deploy, modify consumer repos, or prove the Control/Link/Grant
installed product and privileged host effects.

See `docs/CONTROL_FIRST_FOUNDATION_HANDOFF_2026-10-16.md` for the complete
installation process, trust boundary and acceptance evidence.
